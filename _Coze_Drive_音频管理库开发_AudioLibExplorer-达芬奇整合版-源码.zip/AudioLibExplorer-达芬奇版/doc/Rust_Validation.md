# Rust 验证报告

## 1.0.2 发布前 IPC／OpenAI 补修（2026-11-16）

对 beta `944bdf3` 相对 main 的独立审查发现：显式 IPC Load 当前选中素材会取消在途 Waveform，而状态观察因素材仍被选中跳过替代渲染。补修保留过期任务取消，并按新的音频 generation 补发渲染；真实解码、Slint 排队发布回归同时检查同素材重载和异素材旧结果拒绝。

用户报告官方 OpenAI URL 下的通用配置错误。该 URL 本身有效；密钥尾随换行的本地拒绝路径已由隔离 HTTP 夹具复现并修复，内部控制字符继续拒绝。官方 Chat 请求按其 API 使用 `max_completion_tokens`，其他兼容供应商保持 `max_tokens`；新增固定字段诊断，不含输入值或密钥。未持有原失败草稿／密钥、未执行真实付费 API，不能将可复现路径认定为用户当时唯一原因。

Windows 新源码为 `87a994edd6158ae3ac45145613b00f4fb2978a38`，Rust 1.97.1 MSVC；desktop 使用 ASIO SDK 2.3.4，remote/server 使用 no-default-features。格式检查通过；desktop/AI ASIO 与 remote/server no-default-features 的 all-targets strict Clippy 均通过。外部依赖、工具链和 feature 选择未变，Cargo.lock 只更新 11 个工作区 package 的版本。

| 本次定向测试 | passed | ignored |
| --- | ---: | ---: |
| audiolib-ai lib | 55 | 0 |
| desktop `controller::ipc_load_tests` | 4 | 2 |
| desktop `controller::search_tasks::tests::ai_search` | 37 | 37 |
| remote AI relay lib | 9 | 0 |
| server `ai_relay` integration | 9 | 0 |
| 合计（不重复计算子进程） | 114 | 39 |

ignored 均保留原含义，不计为通过。桌面新回归覆盖无模型发现、剪贴板密钥、失败保存不落盘、有效保存和跨端点凭据隔离。原始检查证据在本次隔离源码目录的 `.rust-validation/local-checks/` 与 `.rust-validation/release-102/`；严格 Clippy 的单阶段报告仍标记 format/tests 为 not-requested，格式与测试通过由上述独立记录证明。

下两节 `e19f4d0`／`b8b3e22` 开发验证的原身份继续适用于未改变的 core/db/audio、扫描／Metadata／库管理和 UI 布局实现；本次没有改变其写入顺序、租约、存储或关闭契约。UI 布局原组合为 192 passed、2 ignored，保留失败后的修复记录；未为了新版本重复全工作区、ASIO 硬件或旧库 fixture 验收。新公共 AI 错误类型的实际消费者已经重新检查。Mac/Linux 原生检查、beta 环境、最终 main/tag 产物验收及固定安装仍按 [1.0.2 发布记录](https://github.com/Freedragonlancer/AudioLib-Explorer/blob/main/doc/Rust_Release_1.0.2.md) 分别完成和记录；本节不是已发布证明。

## 主界面与主题审查（2026-11-16，1.0.1 开发工作区）

基于 `e19f4d0` 的开发工作区，修复九项布局、控件输入及辅助功能问题，见 [审查修复记录](Rust_Review_Fixes.md#主界面与主题边缘情况2026-11-16开发工作区)。本轮没有打包、发布或更新 `local_release/`，所有窗口、合成音频展示及设置均来自隔离测试，未使用工作库或源 WAV。

Windows Rust 1.97.1 MSVC、Slint 1.17.1、已校验 Steinberg ASIO SDK 2.3.4。最终 `cargo fmt --all -- --check`、桌面包 ASIO all-targets strict Clippy 和定向 UI 回归通过。UI 组合证据为 **192 passed、2 ignored**：`final-ui.log` 中 191 项通过，最后一项 Studio 大字号用例修正夹具后在 `dock-fixed.log` 单独通过，没有重复计数或将原失败报告改成成功。最终静态检查日志为 `.rust-validation/local-checks/8eb72c801729459aa396e828ee8485d6/`；UI 命令、原失败、定向诊断和软件渲染截图保留于 `.rust-validation/gui-review-20261116/`。

实际范围包含主题/字体与通用控件、响应布局和窗口宽度偏好、面板拖动、原生重复键适配、菜单/模态与结果行输入、搜索任务及 AI 面板、Studio 切换/试听和 Waveform 选择等现有 UI 测试。覆盖 Default、Studio、Default v2、中英文、1080×700 与常规窗口、100%～200% 应用内缩放，以及 10/13/24 等字号；新的 Studio 可达性用例逐一检查 150%/200% 与 13/24 字号组合，最右操作实际可点击，Tab 可显示并激活左侧播放按钮。已检查三个主题的代表性主界面和小窗口加载/错误状态截图。

首轮回归暴露隐藏侧栏仍保留布局宽度，已改为零宽度并保留原生列表；滚动位置保留回归通过。另有旧结果行测试误点独立收藏格，以及拖动状态测试仍查询旧可访问标签，现改为实际行主体和状态栏可访问描述，并增加收藏不能选中/试听行的独立检查。最终唯一失败是 Studio 夹具在主题的两阶段视口恢复结束前请求最大滚动，被旧位置覆盖；有界等待恢复后，保留原边界、点击与键盘断言并通过。此前的 GNU 宿主 `dlltool` 缺失和新测试浮点类型推断错误均未计为通过；仅在本次检查进程中选择 MSVC，没有改全局 Rustup 或仓库工具链配置。

两项 ignored 分别为需要交互式 Windows 桌面的连接编辑器入口和显式 Waveform 指针 PNG 导出入口，均未计为通过。原生重复键适配覆盖映射和真实 Slint 控件合成交互，未声称已执行物理键盘/不同系统 DPI 或 macOS/Linux 原生 GUI 验收；Ctrl+Alt/AltGr 特殊组合继续保留后端路径，不在适配器修正范围。

本轮只改变桌面呈现、UI 偏好宽度换算及窗口输入适配，未改变配置写入 worker、Metadata 保存、数据库/迁移、音频引擎或 IPC 协议。未变化模块沿用下节全面审查的原通过基线及原身份，未重跑 CLI、core/db/audio/server/remote 功能套件、百万记录基准或发布验收；桌面相关调用及交互已纳入上述检查。

全部检查与截图检查结束后，统一执行一次受管 `Intermediate -MaxGiB 0` 清理，通过并删除 `29,785,315,401` 逻辑字节（约 **27.74 GiB**），保留 `2,919,562,257` 字节（约 2.72 GiB）的 profile-root 最终产物等非候选内容。没有终止进程或触及 SDK、安装和应用数据；逻辑大小不表示精确物理空闲增量。清理证据为 `.rust-validation/gui-review-20261116/cleanup.log`，未对已完成清理重复扫描。

## 全面审查修复的开发验证（2026-11-16，1.0.1）

基于 `a5a587d` 的开发工作区修复，问题与实现见 [审查修复记录](Rust_Review_Fixes.md#全面审查修复2026-11-16101-开发工作区)。本轮为源码修复验证，不是发布、打包或固定安装验收。Windows Rust 1.97.1 MSVC；客户端/audio 使用已校验 ASIO SDK 2.3.4，server/remote 使用 no-default-features；所有写入使用自有临时库、音频、缓存或配置。

最终格式检查、core/db/audio/desktop/CLI ASIO 组合与 server/remote no-default-features 的 all-targets strict Clippy 均通过。以下是定向命令的组合证据，未执行全工作区功能套件；嵌套子进程摘要不重复计数。

| 实际测试范围 | passed | ignored |
| --- | ---: | ---: |
| core lib，包含大小写敏感 URL 前缀 | 204 | 0 |
| db `vendor_import`、`tag_term_tests`、`source_tags_search` | 45 | 0 |
| audio lib / ASIO，包含大回调、Seek、EOF 与网络预缓冲 | 192 | 4 |
| remote lib，包含流、下载、续传、身份与缓存复用 | 322 | 0 |
| server `auth::tests`、`security`、`api`、`ai_relay` | 101 | 1 |
| desktop / ASIO 的 IPC Load、source-transition、remote-output、source-consistency 模块（含提交前 CR 补测） | 33 | 33 |
| 合计 | 897 | 38 |

ignored 未计为通过，包含隔离子进程入口、fixture 导出和真实 BOOM/SMED 素材入口。首次 auth 回归发现新增严格校验与派生 Default 的版本 0 冲突，导致缺少 `tokens.json` 时首次创建失败；改为版本 1 的显式 Default，并补首次创建/验证/重载回归后，重跑格式、server/remote strict Clippy 及整个 auth 模块通过。未变化的 core/db/audio/remote 通过项保持原结果，没有重启这些套件。全部日志和逐项命令保留于 `.rust-validation/review-fixes-20261115/`，原失败记录没有覆盖为成功。

提交前独立 CR 发现：旧 Slint 选择回调通过入口检查后仍可能在 Metadata 捕获处等待，IPC Load 已确认 B 后，旧回调继续发布 A 的 reload。补修在捕获结束后持 admission 重验代际并原子发布 selected/reload/job；新增真实 Slint 队列与 Metadata mutex 的确定性回归，同时验证当前备注落盘。`check-local.ps1 -Package audiolib-desktop -Bin AudioLibExplorer -TestFilter controller::ipc_load_tests -Asio -CleanBuildArtifacts:$false` 的格式、strict Clippy 和 3 项测试通过；source-transition/remote-output/source-consistency 再跑 30 项通过。上述 33 passed / 33 ignored 替代原桌面 32 / 32，没有将重跑或嵌套子进程重复计数；其余 864 passed / 5 ignored 的源码、feature、工具链与调用契约未变，复用原证据。CR 日志为 `.rust-validation/local-checks/47d6198c893a47b09068db8256965eb7/`，首次新测试格式失败保留在 `ad37f30af2624117b86c8a0ccc49f217/`，统一格式后通过；原和补修两轮的检查身份分别保留。

`test-build-environment.ps1` 与 `test-build-artifacts.ps1` 合成回归通过；后者确定性地在 `deps`/`.fingerprint` 已被删除后模拟编译器出现，并验证重新续跑、编译器摘要变化/越界证明/All 模式拒绝，以及最终 EXE/PDB 和未知 owner 字段保留。证据分别位于 `%TEMP%/AudioLibBuildEnvironmentTest-240ab4da21894962babfe4ef08e6303b/` 和 `%TEMP%/AudioLibCacheTest-5f68f4ed899848d2a09e0ded79704124/`。

首次修复源码的 desktop/CLI ASIO 开发版构建通过，实际 EXE 位于受管 target 的 `x86_64-pc-windows-msvc/debug`。对这两个新 EXE 执行 `validate-library-management.ps1`（10 项）、`validate-review-fixes.ps1 -CleanCheckout`（10 项）和 `validate-playback-ipc.ps1 -CleanCheckout`（20 项），均通过。验证保留用户标注、库身份、源 WAV 字节与客户端播放历史，覆盖跨实例写入/扫描排他、真实静音 WASAPI 播放和受控关闭；不把设备报告的缓冲当作声学延迟测量。首轮三个脚本各只运行一次，没有打包、安装或更新 `local_release/`。

提交前 CR 补修后，单独重建 desktop ASIO 开发版，再对更新后的 EXE 执行 `validate-playback-ipc.ps1 -CleanCheckout`，20 项通过。CLI 和两项库管理/跨进程数据库验证的实现、配置及数据边界未变化，复用其原通过结果；未重跑无关套件。补修构建证据在 `.rust-validation/cr-beta-20261116/`，播放脚本的独立新运行记录在上述逐项证据目录中；独立复核未发现剩余 P1/P2。此处仅记录开发验证，不代表 beta 环境部署。

首次修复验证结束的 `Intermediate -MaxGiB 0` 维护成功：删除逻辑字节 `43,019,516,385`（约 40.06 GiB），保留 `2,919,512,593`（约 2.72 GiB）的最终 EXE/库/PDB 等非候选内容。所有选定中间文件均已清理，没有强制终止进程或扩大删除范围；逻辑大小不是精确物理空闲增量。实际清理记录及原始验证日志仍在上述私有证据目录，未对已完成清理再做一次扫描。

CR 补修产生的新中间产物在定向检查、桌面构建和 IPC 验收结束后统一再清理一次：`Intermediate -MaxGiB 0` 通过，删除 `26,995,430,332` 逻辑字节，保留 `2,919,562,257` 字节的最终产物等非候选内容。没有重扫原已清理结果；这是补修重新编译后的独立清理周期，未终止进程或触及 SDK、安装和应用数据。

稳定基线采用 [v1.0.1 发布记录](Rust_Release_1.0.1.md) 的 `21a0e1c` 原身份；`a5a587d` 至本工作区的 AI、Windows、IPC、update 源码及 Cargo.toml/Cargo.lock 均无变化。保留其已通过的 update 40 项、Windows 33 项及相关平台发布证据；受修改公共调用链影响的客户端、CLI、server 与 remote 已重新纳入上述检查。不重新执行无关发布、迁移、权限、全量扫描或百万记录性能验收。当前 Windows 结果不代替 macOS/Linux 原生锁、真实 ASIO 设备或按钮到声学输出延迟测量。

## 本机构建目录与成功后自动清理（2026-11-14）

基于 `6e4ea1d` 的工作流脚本变更。Windows 开发检查和 release 构建默认解析到本机固定磁盘 `%LOCALAPPDATA%/AudioLibExplorerBuild/<checkout-hash>/target`，构建期间的 `TEMP`/`TMP` 同步到该 target，退出后恢复；独立打包和验证脚本使用同一解析规则。工作区已有的其他 Rust 改动保留，本节不为这些改动提供验收结论。

PowerShell 语法检查、`git diff --check`、`test-build-environment.ps1`、`test-validator-build-routing.ps1`、`test-development-pipeline.ps1`、`test-build-artifacts.ps1`、`test-release-pipeline.ps1`（All）、`test-package-boundary.ps1` 和 `test-server-package.ps1` 的合成回归通过。覆盖本地/显式/相对目录、所有权及链接拒绝、环境恢复、成功清理/失败保留、占用和租约、最终 EXE 保留、清理后的 build/交付收据复用，以及客户端/服务端包边界。目录与验证路径辅助测试另外通过 Windows PowerShell 5.1 兼容检查；自动清理执行仍要求 PowerShell 7.3+。

`windows-local` 的实际 Plan 预览解析为 C 盘的 `%LOCALAPPDATA%/AudioLibExplorerBuild/<checkout-hash>/target`，在 install 后列出清理；只读 `release-assets` 预览不含清理。预览未创建该构建目录。清理器以 `Intermediate -MaxGiB 0` 删除中间目录和 tmp，保留最终 EXE/库/PDB；下一次实际编译需要重新生成依赖缓存。未运行 Rust 编译、应用回归或重新安装；脚本路由变更按工作流验证范围检查，不重跑未涉及的应用功能矩阵，也不触发真实缓存扫描。

清理与续跑证据：`%TEMP%/AudioLibCacheTest-c7ca4b2e01a043d2ae4f44aff762142d/`；完整管线路由证据：`.rust-validation/release-pipeline-tests/fca7365385f44388b8ba6ae95c1a317f/repo with spaces/`。首次新增清理收据复用测试发现 PowerShell 普通 hashtable 参数顺序导致身份不稳定，改为 ordered dictionary 后通过；原失败证据保留在自有临时目录。最终审查补充了独立初始化锁和双进程首次启动回归，PowerShell 7/5.1 helper 验证通过，确保并行构建不会读到部分归属标记；该修复不改变已经通过的显式 target 路由及包边界行为。

## 0.8.4 开发与平台交付（2026-10-29）

发布基线为已经发布的 `v0.8.3`（最终提交 `f8c213f`）；其正式包、本机固定安装及人工验收结果见对应 GitHub Release。0.8.4 保留 API v1、schema 8 和原存储格式，新增 Linux x64 与 Docker 双架构交付，并修复侧栏箭头。

箭头旧实现使用 `transform-rotation`，但固定的 Slint 1.17.1 软件渲染器旋转操作尚未实现，展开状态变化后图标仍朝下。当前改为按状态选择两张统一细线、圆角的 12×12 SVG。Windows 工作区格式、桌面 all-targets 严格 Clippy 和六项侧栏回归通过；新增回归在 1×/1.5× 实际渲染中检查展开/收起图标的方向，并保留已有键盘、模态和分区布局覆盖。展开与收起的截图已经查看，原目录行、筛选和高度持久化契约不变。

Linux arm64 正式工具扩展的四个脚本语法检查与 Windows 合成服务端包边界回归通过；发布资产验证器的 41 项离线回归通过，覆盖历史四/六项及 0.8.4 十二项、缺少新增平台包、命名、重复、标签身份和摘要拒绝。Docker release 文件的 YAML 与 RUN shell 语法检查通过。实际 OrbStack 导出包含 OCI/legacy 混合元数据，最初按预期在加载前拒绝；生产端现仅重建明确的单镜像 manifest/config/引用层，校验 config digest 与解压层 DiffID，并删除 OCI 索引、attestation 和无引用 blob。49 项离线 Docker 回归通过；ARM64 实际镜像的版本/提交、鉴权、RIFF 206、非 root/只读边界、卷持久化、SIGTERM/restart 和缺库 unhealthy 验收通过，日志保持私有。以上结果不代替 Linux/Docker 的实际构建和运行验收。

初始候选 `cde2ed0` 已通过 `tools/check-local.ps1 -Asio`：默认及 ASIO 两种配置分别为 87 个顶层目标、1812 passed、0 failed、164 ignored，嵌套子进程摘要未重复计数；日志为 `.rust-validation/local-checks/777c01d819b74c3aaa8d0d361439035b/`。Mac 候选的严格桌面 Clippy、六项侧栏测试、原生签名、完整隔离启动与退出保存验收通过。Windows `f526a80` 候选构建、1247 文件兼容/隐私边界、完整便携验收及固定 `local_release` 的 1249 文件哈希、CLI 版本和隔离启动通过，另行安装了 `0.8.4-0` beta。Linux ARM64 的 server/db 严格 Clippy、all-targets 功能测试、原生包和 ABI、合成 WAV fixture 通过；AMD64 的 server/db 功能矩阵、包验收及 ABI 通过；x64 updater 的严格 Clippy 与 26 项测试另行通过。Docker AMD64 构建、离线加载和完整运行验收也通过，两个架构的测试容器/卷均清理成功。上述结果绑定候选应用代码，最终提交仍须重嵌版本身份并重新打包与运行验收；不重复未修改的功能矩阵。Linux amd64 在 ARM64 OrbStack 上执行时必须记录仿真条件，不能声称真实 x86_64 硬件覆盖。正式 Docker 包仅消费已验收的公开 Linux payload，不从开发工作目录构建发布镜像。最终提交产物、beta 人工验收、发布及固定安装结果以对应 Release 的说明和实际产物为准。

## macOS 客户端发布准备（2026-10-29，0.8.3）

本轮将 macOS arm64 客户端加入发布范围，补齐 per-user 数据目录、beta/rc 数据隔离、原生文件选择与启动错误提示、Finder 定位、CoreAudio 设置及手动更新入口。Windows 的偏好目录和既有更新包边界保持原样；服务端不使用客户端新增的数据目录解析器。

Windows 默认配置的 core/desktop/windows/cli 四包 all-targets 严格 Clippy 与测试通过：587 passed、0 failed、149 ignored；desktop/cli 的 ASIO 配置严格 Clippy 与测试通过：424 passed、0 failed、149 ignored，使用已校验的 SDK 2.3.4。纯行为测试覆盖 Mac 路径选择、合法/损坏包标记、beta 覆盖及跨平台音频设置适配，但不冒充这些分支已经在 Mac 原生执行。前一轮候选的全工作区默认/ASIO 矩阵作为未受修改子系统的基线复用，本轮按影响范围复跑。忽略项仍是子进程入口及需专项环境的用例，未计入通过。

新增发布资产验证器的 34 项合成回归通过；Mac ZIP 边界验证器的 19 个实际归档用例通过，包括精确大小写、Unicode 规范化与冲突、路径逃逸、符号链接、权限和私有文件拒绝。三个 Mac PowerShell 脚本语法检查通过。普通 CI 与 verify-only release workflow 不承担原生运行验收。

SSH 恢复后已在 Apple Silicon、macOS 27.0.1、Rust 1.97.1 原生环境执行验证。首次检查实际发现 Windows 测试导入范围、关闭测试缺少隔离 backend、Mac 文本导航快捷键及可恢复 CoreAudio 通知分类问题；原失败日志保留，修复后按影响范围重跑。未修改的 core/db/CLI 在 `46731b7` 通过；audio、407 项桌面测试的组合证据以及其余包分别绑定 `32c03ca` 和 `2e4c62f`。同一 87 个顶层测试目标去重合计 1801 passed、158 ignored，原失败项均由修复后的回归通过；10 项 responsive 重跑及嵌套子进程摘要未额外计数。全工作区基线和当前受影响包的严格 Clippy 通过，不将组合证据描述为最终提交单次全量运行。

新回归还覆盖 CoreAudio 欠载计数、非致命优先级通知、真正设备错误的粘性失败状态，以及原生退出夹具的所有权拒绝。Windows 默认/ASIO 的 audio/desktop/windows 严格 Clippy、音频测试及受影响的关闭/夹具/滚动交互回归通过。原生测试链接器曾提示 debug 测试程序的 `__eh_frame` 超过 compact-unwind 编码范围；测试通过不构成真实声学性能测量。

`ddda976` 将包标记迁入签名资源目录；新增三项隔离文件系统回归通过，Mac core/CLI 复跑合计 158 passed（其中 core 138），Windows core 140 项通过。当前组合矩阵去重为 1804 passed、158 ignored、87 个顶层目标。初次签名因版本标记误放入代码目录而失败，修复后重新构建和打包；旧失败 stage 保留。

该提交的 Mac arm64 release 构建、ad-hoc 签名、两个标记的资源 seal、Mach-O/系统依赖、包边界与完整原生合成运行验收通过。真实 `NSApplication terminate:` 后，通过 CLI 回读确认 dirty Metadata 备注已经落盘；还覆盖空库首次启动、合成 WAV、中文界面、坏偏好诊断、只读 app/CWD、临时 HOME 默认 beta 目录和导入 ASIO 设置的 CoreAudio 启动。候选证据保留于 `.rust-validation/release-083/native-8b14a8ef98f643a4b59811ee3d336b2b/`，不是最终 main/tag 产物证明。

截至上述候选记录，人工 GUI/声学播放、完整 beta 流程、最终提交产物及发布后的固定安装同步仍待完成。`MACOS_README.md` 记录原生命令和验收限制；最终验收结果以对应 GitHub Release 为准，不能把 `-StructureOnly` 或 Windows 结果记为 Mac 运行验收通过。

## 0.8.3 发布准备（2026-10-28）

以已发布的 `v0.8.2` 为基线，工作区及 10 个包的版本同步为 0.8.3；API `/api/v1/`、schema 8、快照兼容范围和完整存储格式保持不变。两项独立 CR 未发现阻止提交的问题；侧栏交互已经人工界面验收。

`tools/check-release.ps1 -Tag v0.8.3 -BaseTag v0.8.2` 与锁文件元数据检查通过。准备提交 `37a6c18` 已完成 `tools/check-local.ps1 -Asio`：格式检查、默认及 ASIO 配置的全工作区/all-targets 严格 Clippy 与测试全部通过。两种配置各 87 个顶层测试目标、1791 passed、0 failed、164 ignored；每套日志中两条嵌套子进程摘要均未重复计数。ASIO 使用已校验的 Steinberg SDK 2.3.4。

每套 164 个 ignored 中，143 个是子进程或 fixture 辅助入口；其余 21 项需要交互式 Windows、静音输出、真实服务器/BOOM SMED WAV/v6 快照、完整库或性能专项环境，或用于 fixture 导出。这些入口未计入通过；部分辅助入口对应的人工父用例未运行，真实 ASIO 硬件输出也未据此验收。完整日志保留于 `.rust-validation/local-checks/23d329dc6fad43599f7312b71376b898/`。

本次版本的 Windows 候选构建、打包与固定安装遵循 AGENTS.md 的顺序和隔离数据要求，实际便携启动结果由 `doc/Rust_Portable.json` 记录。下方 0.8.2 开发验证不冒充 0.8.3 发布验收。beta 服务端刷新、客户端同步/流读取冒烟、音量与服务器同步人工清单、Mac arm64 正式产物仍需绑定后续候选或最终发布提交。

## 左侧目录分区折叠与高度调整（2026-10-28，0.8.2）

基于 `5688876` 的工作区变更。Folders 与 Libraries 标题独立展开/收起；双展开时拖动水平分隔条或用上下方向键调整高度，单展开时利用剩余空间。展开状态与高度比例通过既有偏好写入流程保存，保留目录/音效库筛选、选择与目录滚动位置。

Rust 1.97.1 MSVC 下，格式检查、受影响 core/desktop 包的 all-targets 严格 Clippy 与 `git diff --check` 通过。core 全部 130 项测试通过；桌面新增 5 项交互测试及原有 responsive layout 10 项、pane review 4 项、window layout 4 项、search task UI 9 项，共 32 项通过。覆盖中英文、不同界面缩放、小窗口、鼠标/键盘、模态禁用、比例恢复及滚轮位置保留。本轮未运行无关的工作区测试、真实音频硬件或百万记录性能验收。

## 0.8.1 共享专辑与原始 Metadata TEXT（2026-10-28，新候选待验收）

当前可写目标为 schema 8 / `ale-s8-cld1-t3-m2-p1-a1`，仅增加共享专辑
`album_entities=1`，Metadata 保持原始 JSON TEXT，快照外层 zstd 保留。
用户已选择暂缓 Metadata 压缩；新库、扫描、迁移输出和新服务端快照不创建压缩值。
旧实验 `a1-z1` 只保留严格只读兼容和受保护的 owned TEXT 转换入口。

已完成的 TEXT 证据分别绑定原生迁移提交 `7f1dfda` 和 Windows 候选
`4c468dd`。Windows 默认配置的全工作区严格 Clippy、全部 target 测试在
`7f1dfda` 通过；新增取消检查后，完整 ASIO 配置在 `4c468dd` 通过，包含
无 BLOB 行时仍响应取消的新回归。随后默认配置的 db/remote 全 target
严格 Clippy、两项 `legacy_metadata_budget` 回归和全工作区格式检查通过。
这是默认全量基线、当前 ASIO 全量和默认定向差异检查的组合证据，不宣称
取消检查修改后重新执行了默认配置全工作区测试。

`4c468dd` 的正式 Windows release 构建、portable 打包，以及库管理、
review-fixes、播放 IPC、桌面关闭和 portable 启动七步均以实际进程退出码 0
完成。私有汇总器曾因 SHA256 大小写比较错误报失败；严格检查 64 位十六进制
并统一摘要大小写、精确匹配文件名后，复核原日志、源码和产物身份通过，
未重写原失败记录，也未重复已通过的构建与安全测试。

Mac arm64 使用匹配的 `7f1dfda` CLI，按显式离线 plan/apply 完成 schema 7→8
迁移和独立 verify：909,342 条音频、20,248 个文件夹、6,910 个共享专辑，
无活动迁移标记；beta 保持停止，生产库及原文件访问授权链指纹不变。
该 beta 的只读 SQLite online backup 已独立取得并验证，不等同于服务器启动、
客户端完整同步或人工 beta 验收。

Windows 对迁移前备份与迁移后只读快照，按音频 ID 逐条比较实际 TEXT 的
UTF-8 字节、长度和摘要，全部 909,342 条原始 Metadata 一致；两库均为
909,342 个 TEXT 值，目标压缩策略为 0。数据库主文件由 10,611,302,400
变为 10,643,787,776 字节，增加 32,485,376 字节（约 0.306%），输入数据库
及 WAL 条件在测量前后不变。本次共享实体调整未得到下方实验的 49.11% 压缩。
同参数 zstd level 3 / 8 threads 的只读体积测量通过：旧库 950,903,523 字节，
TEXT 库 959,144,742 字节，增加 8,241,219 字节（约 0.867%），源文件 stat
前后不变。这是压缩输出大小，未测实际网络同步耗时。图片本身不写入 SQLite、
FTS5 或数据库快照；新增专辑归属、索引和查询仍有空间及计算成本，不能据此
宣称封面功能完全没有开销。

真实库的原生搜索使用同一组 100 查询，按 schema7、TEXT、TEXT、schema7
顺序执行，909,342 条记录的原始结果如下。Metadata 全量核对先于计时，
因此 OS 缓存已暖；结果页采用 DataProvider 计时，含目录分面为顺序调用计时，
均排除进程启动和 provider 打开。

| 顺序 | 结果页 P95（ms） | 含目录分面 P95（ms） |
| --- | ---: | ---: |
| schema7-a | 98.9516 | 176.2659 |
| TEXT-a | 102.7350 | 178.0795 |
| TEXT-b | 101.3661 | 177.4423 |
| schema7-b | 99.7523 | 176.9803 |

补充的原生 `album_facets` 测量在同一份已验证 TEXT 副本上通过：空查询、
`wind`、`金属` 各 100 轮，专辑/匹配计数均稳定；暖调用 P95 分别为
27.2540、43.7681、0.2222 ms，首次调用分别为 29.8088、105.5711、0.5092 ms。
空查询覆盖全部 6,910 个专辑和 909,342 条记录。计时仅含专辑 SQL 与 owned DTO
构造，排除 provider 打开、前置检查和 GUI/图片；共享 provider 和已读索引
不构成磁盘冷缓存条件。源库、WAL 和 journal 的 stat 条件前后不变；这项
测量不替代已单独完成的 Metadata 逐字节核对。

前述 ABBA 是单轮暖缓存后端结果，不是冷启动、GUI、专辑侧栏、封面、网络或
播放延迟，也不足以单独证明统计显著的性能变化。独立 1,000,000 条合成记录
runner 以退出码 0 完成，结果页 P95 110.8558 ms、含目录分面 P95 200.1038 ms，
原始计时低于 **P95 latency <500ms for 1M+ records** 目标。但主文件
1,012,006,912 字节之外仍有 260,524,112 字节非空 WAL，最终 helper 在
后置物理 TEXT 审计前拒绝继续，整体状态为失败；未 checkpoint 或删除 sidecar。
不能将这些计时写成百万库自包含快照、物理格式审计或完整性能验收通过。

前一 `4a0ee72` 阶段在上述基线上新增 SMED 封面解析，当时仍需补齐新候选
验收；上述迁移和搜索记录不冒充这一提交的重新实测。当时尚未完成本轮 beta
服务刷新、客户端 smoke 或人工 GUI 全流程；后续目录候选进度见下节，正式 Release 未发布。
下方压缩实验记录仅适用于已暂缓的候选；无关源码与环境未变的结果按验证范围
复用，受修改影响的检查重新执行。最终发布结论以本版本 Release 的验收说明为准。

### BOOM 封面兼容调查（2026-10-28）

只读、有界 Range 采集跳过原 WAV 音频 data，仅保存 Metadata 和用静音帧
重建的自有测试夹具。Alien Life 的 ID 1、2、3 同时含 ID3 APIC 和 SMED
`Picture type="NSData"`，三条均为同一张 1024×1024 JPEG；携带正确库身份的
旧 0.8.0 服务接口均返回 200，响应含正确的 `X-Library-Id`，旧 0.8.0 GUI
复查可见三条封面。这不能解释或否定此前“只有第一条显示”的现象，客户端
当时的选择、请求和缓存状态仍需对应证据。

P-51 Mustang 样本 ID 72829 没有 ID3 图片，仅在 SMED 中含 512×512 JPEG，
旧服务接口返回 404。`4a0ee72` 新解析器的真实 tag 夹具测试已通过；以下为部署前
调查记录，后续真实目录接口验证见下节。新增 Windows 集成回归已通过：先扫描无图代表，再扫描同专辑
的 SMED-only 成员，直接 HTTP 与真实 loopback `RemoteClient` 的单文件及
共享专辑取图均返回有效图片，200/304 身份、缩略图、源文件不变和数据库检查
均通过；纯合成 fixture 与显式提供的真实 P-51 tag fixture 分别运行，服务端
全部 target 严格 Clippy 通过。采集前后原文件大小及服务端文件身份信息保持一致，未下载
原音频样本，也未修改素材、服务配置或现有封面覆盖缓存。

### 直接父目录封面候选（2026-10-28，beta `0262003`）

该候选保留共享 Album、schema 8 和原始 Metadata TEXT，不启用压缩。自动取图、
手动指定/隐藏及恢复默认均按专辑内 WAV 的直接父目录区分；目录恢复标记阻止旧
全专辑选择重新生效，旧偏好保留供其他目录只读继承。

Mac arm64 的相关原生检查及 server/CLI 构建通过，随后使用正式
`beta-refresh --no-build` 完成 beta 刷新：健康接口为 `ok`、提交 `0262003`、
schema 8，配置根的真实 206 读取通过；原有五个 launcher/启动脚本/配置/token/plist
授权链文件摘要保持一致，生产 schema-7 实例未更新。本次没有迁移数据库或重新授权。

真实 HTTP 验证覆盖九条已知记录：Construction Kit 三条、Designed 五条与 P-51
一条，返回有效 JPEG；CK 与 Designed 在同名 Alien Life 下返回各目录自己的不同
海报，P-51 的 SMED-only 图片正确。这是九条样本的实际结果；图片解码与 HTTP
成功不代替 Windows GUI 或实际音频输出验收。

Windows 默认配置相关包的严格 Clippy 通过；数据库专辑 37 项、remote 目录封面
10 项、server 目录封面 4 项，以及修正目录语义和窗口重开顺序后的 desktop 管理
17 项通过。先前失败记录保留；桌面父回归串行执行，避免隔离 CPAL/Slint 实例
并发争用。`19ab068` 的默认与 ASIO 全工作区结果仅为历史基线，不宣称目录候选
重新执行了这些全量检查。当前候选的 Windows 正式打包及安装验收、客户端 smoke、
人工 beta 全流程与正式 Release 仍待完成，不能由上述定向结果推定通过。

## 暂缓的 Metadata 压缩实验（2026-10-28，历史证据）

以下实验格式为 schema 8 / `ale-s8-cld1-t3-m2-p1-a1-z1`，未正式发布。
该结构实验发生在 0.8.1 发布前，前一 schema-7 候选的产物与人工 beta 结论
未被用于替代此次验收。
实施阶段已通过 core 127 项、Metadata codec 5 项、专辑 29 项、remote 262 项
（首轮失败修正后定向复测）、服务器封面/兼容/升级 12 项、CLI 20 项；
桌面旧有封面定向回归 12 项、专辑条件绑定 5 项与旧源到原生实体的偏好迁移回归通过。
新增导入身份事务提交/job 保存中断后的恢复、验证及回退两项通过；STRICT TEXT、
唯一索引和 COLLATE 策略保留原语义。个人工作区读取格式 1、保存格式 2，
阻止旧程序忽略新增条件。默认及 ASIO 全工作区严格 Clippy 已通过，完整 ASIO
工作区全部 target 测试通过，桌面为 377 项通过，隔离辅助用例由父测试执行。
默认配置按原始通过记录及修正后的定向回归续跑，失败记录保留。该实验候选已
停止晋级；其打包及人工结论不能替代 TEXT 候选，最终发布结论以本版本 Release
的验收说明为准。

Mac arm64 原生 core、db、remote 严格 Clippy 和全部 target 测试通过。
server 原有两项历史格式 fixture 经实际 schema-v5 检查替代后定向通过，
其余已通过单元结果、后续全部 binary/integration target、最终严格 Clippy
共同组成原生验收。续跑证明只涉及桌面变化和 server 测试模块，核心业务代码
未变，原失败日志未改写。原生 CLI/server release 构建及服务器包隔离启动、
哈希、健康接口、schema 8 能力检查通过；真实 Mac beta 流程未通过，见下述超时记录。

909,342 条记录的自有副本已通过迁移后独立 verify；原始副本大小及精确修改时间
不变。全部 Metadata 按 ID、原始字节长度和解压 UTF-8 字节逐条比较一致，
累计摘要为 `350a6ba397f82bf1ae9d2528222958580e5e1471d24ece1b6cdd8d3d547c275e`。
SQLite 从 10,611,302,400 降至 5,400,199,168 字节（49.11%）；Metadata 值的
物理字节减少 77.35%，6,910 个共享实体覆盖全部成员，孤立归属为零。
早期演练使用的旧回填 recipe 已被索引修复替代，因此该演练不用于报告最终
迁移速度；已索引回填的真实 Mac beta 迁移未完成验收。

9800X3D / Windows 本机 SSD、暖 OS 缓存、相同 100 查询混合的 ABBA 对照中，
结果页 P95 为旧库 99–101 ms、新库 109–113 ms。独立百万合成记录的结果页
P95 为 117.7 ms，含目录分面为 212.2 ms，符合 **P95 latency <500ms for 1M+ records**。
百万合成库只有一个文件夹回退专辑；真实库覆盖更高专辑基数。结果页计时不含
provider 打开，也不代表冷启动或整段 GUI 交互。独立 `albums` CLI 的总计时包含
多个连接首读，其百万库未 checkpoint WAL 对启动计时有影响，不能当成交互分面耗时。

同参数 zstd level 3 / 8 workers 的快照从 950,903,523 增至 2,033,256,351 字节。
这是压缩实验明确的传输取舍；用户已选择暂缓该方案，不作为当前 TEXT 候选的
空间或同步结果，也不宣称同步更快。

该实验的 Mac beta 刷新在启动等待预算内未完成迁移，脚本判为失败并回退二进制；
当时源库仍为 schema 7、候选尚未发布。启动中的目标 schema 标记未被计为验收通过。
旧迁移须按匹配 recipe 安全完成或回退，新 TEXT 候选将重新执行 beta 流程。

大库演练确认 owned 候选在建立目录后代索引前回填专辑，会按 WAV 重复扫描
`folder_closure`。修复只在候选事务中建立唯一覆盖索引，回填后移除自己创建的
索引；未知对象保留，取消时整体回滚。原生 bundled SQLite 回归以 4,097 个
文件夹、14,337 个闭包行、2,049 个 WAV 和 400 万 VM 指令预算验证归属与复杂度，
另验证取消回滚，两项通过。这是回填路径的规模回归，不代表整库迁移耗时。

根目录覆盖说明：前轮记录中的 38 个数据库顶层文件夹不能等同于 38 个
有效配置根。最近 schema-7 beta 检查按实际配置根取样，覆盖一个有效根内
20 个 Range 音频请求；快照中其他兄弟目录的记录不代表已授予访问权。
schema-8 beta 仍须重新按有效配置根检查，不扩大授权范围。

## Mac 生产部署与真实客户端验收（2026-10-27，0.8.0 开发构建）

经用户明确授权，将生产 Mac arm64 服务器更新为当前工作区版本。
Rust 1.97.1 原生构建 server/CLI 通过；构建副本的 240 个相关输入 SHA256
与工作区一致，基准提交为 `4d4b4ce`，包含本轮未提交补丁。
部署服务器二进制 SHA256 为
`36d77d53bd7d337e350396e7ebcdfd2a86ef70d3270c4fa494c547b0f08f4b3c`。

先在生产库的一致性副本上完成 schema 6→7 升级、`quick_check` 和完整
业务摘要比对，再制作独立 schema 6 回滚备份并验证。切换前后核对库文件
指纹；旧服务日志确认 `Shutdown requested`、checkpoint 完成及
`Server stopped`，随后通过原 plist 和 launcher 启动新服务器。
原库在原路径就地升级，909,342 条音频、库 ID 和所有业务数据保持一致，
revision 从 822 增至 823。升级后原库 `quick_check=ok`，完整业务摘要与
升级前及回滚备份相同：
`3f2fdbc27b29d971e3311b103e296f280a168f358663b67141bbd6b6fa9812d7`。
该摘要比较原始 Metadata、标注及其他业务表，排除可重建派生列。

launcher 的 SHA256、签名/CDHash、run.sh、plist、配置及 token 文件哈希
均保持不变。新进程的 38 个配置根目录各有一次真实音频 Range 读取成功
（206、4096 字节、RIFF/RF64）；验证了现有文件访问链仍可用。
真实内嵌 JPEG 封面返回 200，缩略图为 512×512，库身份正确，ETag 条件
请求为 304；无图记录为 404。PCM 预览起始及非零偏移 Range 均返回 206。

Windows 使用现有 `local_release/` 的 0.8.0 EXE，在全新临时数据目录与
独立 IPC 用户名下同步全部 909,342 条记录，未使用日常 v1 设置或库。
普通 GUI 显示真实 “Alien Life” 封面，未用合成 smoke 视图或手动封面。
客户端 PNG 与 HTTP 图片的尺寸、ETag 对应一致，平均像素差为 0.0093。
实际预览虚拟源使用 `pcm-48000-16` 路由，Playing 位置从 0.262 推进至
0.552 秒，无错误和缓冲。WASAPI 输出设备为 96 kHz、960 帧；暂停、定位
至 5 秒、恢复保持会话，Stop→Play 建立新会话并从 0.05 推进至 0.42 秒。
以 10% 音量验证设备播放状态和进度，未做现场听感或物理输出延迟测量。
测试客户端正常关闭，环境恢复；生产服务继续健康运行，schema 6 备份保留。
回退旧 0.7.8 时必须同时恢复对应 schema 6 备份，不能只换旧二进制。

本轮没有发布 GitHub Release，未变动 Windows 应用源码或 EXE；沿用前述
客户端构建及安装验证。生产地址、token、源音频路径及私有备份位置只保留
在本机忽略的验收记录中，不进入公开文档。

## 封面 CR 修复（2026-10-27，Windows x64，0.8.0 开发构建）

审查并修复封面操作的来源绑定与关闭排空：任务在接收时捕获原始目标，
切换来源后不会删除新库缓存；关闭在后台等待已接收的手动写入，真实保存
失败会显示错误。取消选图、无效图片及可丢弃缓存操作失败不会变成未保存
编辑，也会恢复先前取消的自动加载。慢 WAV 探测和 HTTP 不再占住缓存锁。

缺失记录重新选中、重新关联后的保留选择均重新加载封面；相册侧栏用最多
128 条小型代表提示复用已生成图片，搜索刷新和选择无图成员不再丢掉封面。
提示通过当前 owned 记录、路径和来源版本验证；手动图片与隐藏标记优先。
封面开关与动作在库操作、来源切换及关闭期间一致禁用。

本轮仅修改桌面行为，不修改数据库 schema、源 WAV 或服务端部署。
格式检查及桌面全目标严格 Clippy 通过；桌面全目标测试中 362 项通过，
唯一失败是新增 relink 测试直接比较 Windows verbatim 路径与数据库显示路径。
修正测试的路径规范化后该项单独重跑通过，共覆盖 363 项；132 个默认忽略项
包括由父测试执行的隔离 child helper。其余已通过项按相同源码复用结果。
新回归包括真实 loopback 慢 HTTP、持锁来源交换、关闭排空/失败重试、
输入与缓存错误允许关闭、缺失/重新关联及中英文两种模式控件门禁。
新 release CLI 的 `validate-review-fixes.ps1 -CleanCheckout` 通过，使用
2000 条自有合成记录，未打开音频设备；真实 legacy 夹具仍不在本机。
使用校验过的 ASIO SDK 2.3.4 完成 release 构建。原生标题栏
`WM_CLOSE` / `SC_CLOSE` 各 3 轮（含重复关闭请求）正常退出并重开自有空库，
没有强制终止进程；封面写入等待由前述持锁并发回归单独验证。
未变动的数据库、远程和服务器实现复用接手验证部分的结果。

## 服务器封面接手验证（2026-10-27，Windows x64，0.8.0 开发构建）

基于 `handoff/codex-20261027` 的 `4d4b4ce`，开发分支为
`codex/complete-artwork-playback`。本轮补齐服务器封面的能力检测、身份绑定、
有界请求与缓存，以及本机手动指定、隐藏/恢复和清理缩略图管理。
图片不写入素材库或源 WAV，schema 6 镜像不为封面升级。

Rust 1.97.1 MSVC 的格式检查、工作区全目标严格 Clippy 通过。
数据库、core、audio 和 CLI 的工作区测试结果通过并复用；桌面修正后重跑
353 项通过，远程客户端 258 项通过，服务器单元 157 项、API 67 项、封面
HTTP/loopback 集成 4 项通过，其余服务器集成、IPC、Windows 和更新组件
测试通过。默认忽略的隔离 child helper 由父测试执行，不重复计数。
真实素材、交互桌面或平台专用的按需测试仍按原门禁忽略。

封面回归覆盖手动图片与缓存的独立生命周期、开关持久化、旧选择/来源拒绝、
异步 capability 到达后重新加载、PNG/JPEG 解码上限、小图不放大、ETag/304、
404/405 降级、服务器换库身份拒绝、已授权文件句柄复用、数据库无图片写入和
原始音频 Range 仍返回 206。中英文、本地/服务器模式的新控件均可操作，
忙碌时拒绝重复操作；常用扫描和试听设置保持可达。既有测试辅助 timer
只发送一次 Quit，保留原超时与完成断言。

另对本机既有 schema 6 镜像进行显式只读验收：原路径打开并成功读取目标
音频，0.24 秒完成，文件大小和修改时间未变。该结果排除了这份镜像的
全库复制/误升级假设，不代表百万条搜索性能验收。本轮不运行性能基准；
主要目标仍为 **P95 latency <500ms for 1M+ records**。

生产 0.7.8 服务器未升级或重启。先前原始流及 PCM 预览无响应头，另一次完整
预算请求等待 110.036 秒仍无响应。经授权 SSH 只读诊断，Mac 日志确认服务端
源文件打开曾长期挂起，约 19:05 集中恢复成功，原进程未重启。随后两份 WAV
可在 Mac 直接读取，38 个根均在线；Windows 同一样本原始流返回 206/RIFF，
首响应 53 ms、读取 4096 字节共 67 ms，PCM 预览首响应 2 ms、共 3 ms。
用户随后确认约 19:05 允许过文件或网络宗卷访问，与 TCC 允许记录和文件打开
集中恢复吻合，本次阻塞定位为源卷/文件访问授权等待；没有通过修改客户端
解码器或重启服务来恢复。未来部署须保留持有授权的既有 launcher。
端点响应时间不是物理播放延迟。

已使用校验过的 ASIO SDK 2.3.4 构建 release。便携包、库管理、跨进程数据安全
回归通过；静音合成音频的真实 WASAPI/IPC 播放、暂停、Seek、变换、循环、
独立历史和关机保存通过。固定 `local_release/` 的 1250 个包文件 SHA256 匹配，
CLI 为 0.8.0，隔离桌面启动通过；实际库和设置没有被测试夹具替换。
另在 Mac 的独立源码副本与自有临时目录中，以 Rust 1.97.1 arm64 运行封面
单元 7/7、HTTP 集成 4/4 通过，server release 构建通过。6 个关键源码文件
与 Windows 当前源码哈希一致。该副本无 Git 元数据，内嵌 commit 为 unknown，
产物仅供验证，未部署或发布；Mac 严格 Clippy、ASIO 硬件输出及物理延迟未验证。
最后补修无专辑名记录保存标注后保留手动封面的界面状态；相关 4 项专辑/封面
父回归通过，其他已通过的数据库与服务器结果未重复执行。
客户端手动封面可用于旧服务器；远程内嵌封面需部署支持 `album_artwork` 的服务端。

操作与缓存契约见[封面说明](https://github.com/Freedragonlancer/AudioLib-Explorer/blob/main/doc/Rust_Artwork.md)。

## multi-search 最终 CR（2026-10-25，Windows x64，0.7.4）

基于 `multi-search` 合入 beta `7b97a78`，修复代码提交为 `f81401a`。收藏复用现在关联正确收藏并保留已有任务名称；目录 ID 漂移按存储路径判断，大小写不同的 POSIX/Windows 目录项及模糊别名不会合并。目录与音频路径查找在同一读事务内完成 ID 解析和 owned 行读取，覆盖并发 ID 复用。显式名称记录来源，避免 `Search 2`、`default` 等用户名称被自动名称覆盖。切页后重排正确 Waveform，包括远程 Loading/Ready/Playing 来源，保持音频 generation/session/位置。

Rust 1.97.1 MSVC：格式检查、core/db/remote/desktop/CLI/server 全目标严格 Clippy 通过；106 项 core、191 项控制器、35 项任务/界面、6 项工作区、3 项新路径身份、3 项原路径身份单元、10 项远程写入/路径查询通过。新并发路径回归执行 512 次事务性 ID/路径交换及 1024 组查询。beta 集成验证另通过 19 项 CLI、318 项 server、5 项搜索片段和 2 项包含标签测试；隔离 child helper 由父测试执行，不重复计数。

在 AMD Ryzen 7 9800X3D（8 核/16 线程）上运行 `cargo run --release --locked -p audiolib-db --bin search-benchmark -- --records 1000000 --queries 100`：独立临时合成库 1,000,000 条，默认混合循环 100 次，结果页 P50 **2.11ms**、P95 **150.67ms**、P99 **194.78ms**，65 次排名缓存命中；初始混合轮 P95 **308.17ms**。通过本次 **P95 latency <500ms for 1M+ records** 的结果页验收。生成与重建发生在计时前，保留 OS 缓存，测量时没有并行构建；未计入目录统计、新 provider 冷启动、GUI 防抖/排队/绘制及物理播放延迟。原始记录在本机 `C:/al-build/multi-search-cr-million.log`，完整 JSON 在同目录的 `multi-search-cr-million-report.json`。

## 审查修复：包含标签排序、鉴权限速、流名额与桌面端健壮性（2026-10-25，0.7.4，beta）

基于 beta `d5baffc`。修复一次代码审查找出的问题，不改 schema、不加索引，旧库和服务器快照不需要迁移。

- **包含标签 + 非文件名排序**（audiolib-db，新增 `search_include.rs`）：有包含词时，只看存在的文件、没有搜索词，按时长等非文件名列排序的取页原来沿排序索引逐行回表判断标签。匹配稀疏时这一步要读几乎每个文件的宽行；没有 ANALYZE 统计时则对全部可见文件排序。用户截图上同样的筛选，默认排序 500 ms，时长降序 17 秒。现在先在 `idx_audio_visible_tagged_folders` 覆盖索引上判断标签，只有匹配的文件回表取排序键，计数也读同一索引。不限文件夹、匹配很密（至少占 1/16，页在前 1/4）的时长排序仍按 `idx_duration` 顺序读，读满一页就停。文件名排序原本就按 `idx_audio_visible_tagged_any` 的顺序读，没有改。派生标签列未就绪、索引定义不同、显示范围不是“存在的文件”或带搜索词时，沿用原语句。
- **鉴权限速**（server）：同一 socket IP 60 秒内失败 60 次后，管理页生成的 token（256 位随机）仍然放行，环境变量 token 和错误 token 继续返回 429。以前代理或 NAT 后面一个人输错 token，所有人都会被锁一分钟。
- **流名额**（server）：响应还有数据要发、客户端却连续 60 秒一个字节都不收时（休眠、断网、拿着响应不读），连接断开，响应体和它占的 `max_streams` / `max_previews` 名额随之释放。桌面客户端最多拿着未读响应 15 秒，不受影响。
- **桌面端后台线程 panic**：搜索、目录统计、Metadata 保存和 Waveform 线程把单个任务的 panic 转成该任务的错误，线程继续服务，等待 Metadata 写入的关闭流程也能结束；新的 panic hook 把 panic 和 backtrace 写进 `AudioLibExplorer.log`（release 版没有控制台）。
- **Windows debug 构建栈溢出**：`build.rs` 在 MSVC 目标上给可执行文件链接 `/STACK:16777216`，debug 版不再需要 `editbin`。
- 边缘情况：扫描启动期间设置锁冲突的 409 提示不再写成“另一个服务器实例”；目录浏览检查满 5 万个条目时，管理页会注明子目录可能没列全；桌面端超过 64 个标签词的输入留在输入框里并提示，不再变成 chip；筛选无效时结果计数位置显示“未搜索”和原因，直到下一次搜索；只填了空格的时长、颜色字段在应用筛选时清空，筛选计数不再把它算进去；README 程序版本更新为 0.7.4。

正确性：新增 `search_include_tags`，以“对每个可见行逐行判断标签”的语句为 oracle，比对总数、每页 id 与顺序（排序值相同时按 id）。覆盖稀疏和密集的包含词、单词和多词路径、包含加排除、带采样率筛选、Unicode 词、不存在的词，时长升/降序、采样率、修改时间、标签、文件名和默认排序，三种文件夹范围，深分页和越界 offset，整段翻页拼接，有无 ANALYZE 统计，以及只读 provider。单元测试锁住走新路径的条件和两种路径在没有统计时的查询计划。服务端新增限速期间 token 放行规则和“客户端不读响应时响应体被释放”的测试；后者在超时设为 600 秒时会失败。

本次在 Linux（`x86_64-unknown-linux-gnu`，Rust 1.97.1）上验证：工作区格式检查通过；audiolib-db、audiolib-server、audiolib-desktop 全目标严格 Clippy 通过（audiolib-desktop 的测试目标在 Linux 上有一条原有的未使用 import 警告，与本次改动无关，检查时单独放过）；audiolib-core、audiolib-db、audiolib-server 全部测试 823 项通过、0 项失败、6 项 ignored；audiolib-desktop 全部测试 288 项通过、3 项失败、87 项 ignored，失败的 3 项都是测试容器没有音频输出设备和窗口系统（报错为音频设备不可用、winit 找不到 `DISPLAY`，以及等待试听的界面过渡超时），与本次改动无关。没有在 Windows 上运行：MSVC 构建、`/STACK` 链接参数、Slint 界面交互、ASIO 和打包；没有更新 `local_release/`，也没有发版。

性能：`search-benchmark --existing-db <100 万条合成库> --queries 44 --request-file`，release，同一请求 4 次，优化前（beta `d5baffc`）和优化后的二进制依次运行。表中为结果页 P50 / P95（含计数，不含目录 facet），单位 ms。每行都有标签，`rareword` 只在 1/1000 的文件上，而且这些文件的时长都是最短值；合成库每行的 Metadata 很小，真实库宽行回表要慢得多。

| 请求 | 无统计 · 优化前 | 无统计 · 优化后 | 有 ANALYZE · 优化前 | 有 ANALYZE · 优化后 |
| --- | --- | --- | --- | --- |
| 无筛选 · 时长降序 | 124 / 124 | 113 / 143 | 125 / 132 | 120 / 127 |
| 包含 `rareword` · 时长降序 | 604 / 622 | 396 / 397 | 1198 / 1214 | 402 / 419 |
| 包含 `rareword` + 排除 `footstep` · 时长降序 | 511 / 517 | 243 / 247 | 1103 / 1113 | 254 / 301 |
| 包含 `rareword` · 时长升序 | 206 / 207 | 357 / 410 | 236 / 253 | 376 / 427 |
| 包含 `rareword,sfx` + 排除 `footstep,door`（0 条）· 时长升序 | 122 / 123 | 118 / 136 | 119 / 136 | 119 / 129 |
| 包含 `outdoor`（全部 100 万条）· 时长降序 | 565 / 576 | 153 / 156 | 160 / 183 | 167 / 198 |
| 包含 `sfx` + 排除 `footstep`（25 万条）· 时长降序 | 535 / 590 | 199 / 211 | 197 / 214 | 206 / 262 |
| 包含 `rareword` · 修改时间降序 | 292 / 298 | 422 / 442 | 296 / 307 | 412 / 489 |
| 包含 `rareword` · 唯一文件夹 · 时长降序 | 610 / 635 | 410 / 436 | 1219 / 1286 | 461 / 496 |
| 包含 `rareword` · 文件名升序 | 246 / 269 | 244 / 245 | 247 / 263 | 239 / 270 |
| 包含 `rareword` · 标签升序 | 374 / 382 | 384 / 402 | 363 / 393 | 404 / 418 |

“时长升序”和“修改时间降序”两行变慢是合成数据造成的：`rareword` 的文件恰好都是最短时长，合成库的修改时间又全为空（按 id 顺序走），旧语句沿索引很快就碰到匹配。真实库里匹配分布不规则，旧语句要先读过大量宽行，新语句的耗时与分布无关。`--tag-exclusion-cases` 新增两个“稀疏包含词 + 时长降序”的请求，可以直接复跑。

## 侧栏页签切换、表头排序与显示文件菜单（2026-10-24，0.7.3，分支 feat/sidebar-tab-switch，未合并）

基于 beta `5c07294`。改动集中在桌面界面：
- 列表标题栏：只保留「筛选 | 详情」图标分段开关。
- 侧栏：顶部改为分段页签；收藏移到详情页的文件名旁；筛选页改为「标签列 + 控件」的表单行。
- 排序：表头点击按「升序 → 降序 → 默认」循环，修改时间排序移到「视图 → 排序」。
- 显示文件：移到「音效库 → 显示文件」，非默认的文件范围和修改时间排序会在列表底部提示。
- 每次启动侧栏都显示详情页。

数据库和搜索契约没有改动，排序仍由数据库在完整结果上进行。

本机 Rust 1.97.1 MSVC：工作区格式检查、工作区全目标严格 Clippy 和工作区全部测试通过，共 1506 项通过、0 项失败；103 项 ignored 是原有的隔离 helper 和本地素材夹具。桌面端新增和更新的测试包括：表头排序的三态循环（含保存的降序偏好在第三次点击时回到默认）、启动时显示详情页、图标开关的打开与收起、「音效库 → 显示文件」和「视图 → 排序」子菜单的真实点击、底部提示的复位。1080×700 下详情页提取字段在不滚动时仍完整可见。

截图使用 `--smoke-ui` 软件渲染，窗口 1440×900，在服务器模式的真实资料库（909342 条）上截取，使用隔离的数据目录：
- `settings.json` 和 `cache.json` 是副本，并关闭了自动同步和轮询；
- 本地资料库路径指向一个不存在的文件，防止回退到本地模式时打开工作库；
- 快照通过硬链接只读使用，截图前后快照的大小和修改时间、原 `cache.json` 的哈希都没有变化。

系统原生菜单不在应用自身的截图里，Slint 1.17 的测试后端也没有公开的离屏渲染，因此「音效库 → 显示文件」只有真实点击的自动测试和底部提示截图，没有菜单展开的截图。

同时对上一轮的标签排除补测了按时长排序：100 万条合成库（每行都有标签），release 构建，搜索加目录 facet 的 P95 如下，括号内为结果页 P95：

| 请求 | P95 |
| --- | --- |
| 仅 `tag_contains`，SQL 未变 | 385 ms（181） |
| 包含 + 2 个排除 | 535 ms（261） |
| 仅排除 | 952 ms（415） |

仅排除时结果页仍在 500 ms 内，但加上 facet 后超标，作为后续优化单独处理。

## 筛选侧栏页签与标签排除（2026-10-24，0.7.2，分支 feat/filter-panel-tabs，未合并）

基于 beta `8ddbe24`。筛选移入右侧栏「筛选 | 详情」页签，标签改为 +/− chip，`SearchFilters` 新增 `include_tags` / `exclude_tags`（见 [API 文档](api/README.md) 的 Include / exclude 条目）。

本机 Rust 1.97.1 MSVC：工作区格式检查和工作区全目标严格 Clippy（公共契约有变化，覆盖全部直接使用方）通过。audiolib-core 102 项、audiolib-db 374 项（库内 183 项另有 4 项既有 ignored，其余为全部集成测试）、audiolib-cli 19 项、audiolib-desktop 289 项通过；桌面端另有 91 项既有隔离 helper 标为 ignored。新增回归：词法解析、合并、格式往返和校验；数据库在派生列与 JSON 回退两条路径上，分别覆盖仅包含、仅排除、两者同时、同一词两侧（结果为空）以及有标签加排除的情况，并核对结果数、总数与目录 facet 一致；桌面端用真实按键和点击验证回车添加、Backspace 删除最后一项、chip 的 +/− 切换和 × 删除，以及 chip 换行。两项既有布局和菜单测试按新设计更新，并断言打开筛选页后声音列表高度不变、选中声音不会切换页签。

性能：`search-benchmark --records 1000000 --queries 100 --folder-facets --request-file`，合成库每行都有用户标签，是排除的最坏情况；表中数值为搜索加目录 facet 总耗时的 P95，结果页 P95 在括号内。第 1 轮使用按词展开的 SQL，第 2 轮改为每行调用一次 `audiolib_tag_terms`。

| 请求 | 第 1 轮 | 第 2 轮 |
| --- | --- | --- |
| `tag_contains=outdoor`（两轮 SQL 相同） | 178 ms（83） | 215 ms（95） |
| 仅排除 `explosion` | 431 ms（172） | 516 ms（213） |
| 仅排除 `rareword` | 442 ms（181） | 519 ms（257） |
| 包含 `outdoor` + 排除 `explosion,door` | 550 ms（273） | 292 ms（154） |
| 包含 `rareword,sfx` + 排除 `explosion` | 203 ms（101） | 211 ms（109） |
| `metal` + 排除 `door` | 322 ms（164） | 339 ms（163） |

第 2 轮总体 P95 为 463 ms，达到目标；多词请求超标的问题已经修复。第 2、3 轮运行期间同机有其他 cargo 构建，未改动的基准请求依次变慢到 215 ms 和 652 ms，因此第 3 轮全部作废，第 2 轮仅排除行的上升按噪声处理，不作为回退结论。仅排除的请求不受索引限制，需要扫描全部可见行，计数和 facet 的成本主要来自读取宽行。若真实百万级资料库上仍偏慢，可改为“可见总数减去带标签覆盖索引中命中排除的行数”，此项留作后续。

界面通过 `--smoke-ui` 软件渲染截图检查：改动前后同为 1440×900 和 1080×700，另有中英文混合 +/− chip 视图（新增的 `--smoke-view filter-tags`），使用隔离的合成资料库。debug 构建启动时主线程栈溢出（beta 基线同样如此），截图前用 `editbin /STACK` 调大了 exe 副本的栈保留，没有修改构建配置。本分支未合并，按要求没有更新 `local_release/`，也没有发版。

### 后续：只排除标签的计数与目录统计（2026-10-24，0.7.3，分支 perf/exclude-tag-duration-sort，未合并）

基于 beta `5c07294`。feat/sidebar-tab-switch 只改桌面界面，查询和排序代码与 beta 相同，那一轮测到的“仅排除 + 时长排序”超标在 beta 上同样存在。

根因：只排除的筛选没有索引能缩小范围。在 100 万条合成库上（排除 `explosion`，release，`tag-exclude-diagnose`）：COUNT 对全表宽行逐行调用 `audiolib_tag_terms`，耗时 170 ms；目录 facet 先用同样的扫描收集 90 万个 ID（186 ms），再按 ID 统计文件夹。取页本身按 `idx_duration` 顺序读，拿到一页就停，升序 1.5 ms、降序 2.2 ms；但没有 ANALYZE 统计时（真实资料库通常如此），降序取页会改用 `idx_audio_visible_id`，对全部可见文件排序。

改动只在 audiolib-db，不改 schema、不加索引，旧库升级和服务器快照不需要迁移：
- 只排除、只看存在的文件、没有其他筛选时，总数 = 存在的文件数（`idx_audio_visible_id`，5 ms）− 含排除词的有标签文件数（`idx_audio_visible_tagged_folders` 覆盖索引，只有带标签的文件判断排除词）；目录 facet 按文件夹做同样的减法。派生标签列未就绪或索引定义不同时沿用原语句。
- 不限文件夹的时长取页，在匹配足够密（总数 ≥ 4×(offset+limit)）时固定读 `idx_duration`，两个方向都在拿到一页后停止。匹配稀疏时逐行走索引反而更慢（全部排除时 355 ms，全表排序 153 ms），所以稀疏、深分页和带文件夹范围的情况仍由规划器选择；offset 85 万的深分页走索引为 579 ms，全表排序为 639 ms。
- 带搜索词且不限文件夹时，排名只跳过不存在的文件和被排除的有标签文件；facet 从完整 ID 中去掉被排除的文件，不再收集每个通过的 ID。
- `audiolib_tag_terms` 对 ASCII 标签就地比较，不再每行复制小写字符串：被排除行的扫描从 98 ms 降到 60–82 ms（只扫索引为 36–43 ms），原来的全表 COUNT 也从 170 ms 降到 137 ms。

正确性：新增 `search_exclude_tags`，以原来的全表语句为 oracle，比对总数、每页 id 与顺序（时长相同时按 id）以及目录 facet。覆盖升/降序，时长、采样率、文件名和默认排序，整段翻页拼接，多个、不存在、大小写不同和 Unicode 的排除词，文件夹范围，只读 provider，以及搜索词排名（期望为不加筛选的完整排名按通过集合过滤；facet 在新 provider 上先于任何搜索调用）。同一测试文件在未改动的 beta 上同样通过。单元测试锁住走新路径的条件、绑定的排除词与 `search_sql` 一致、没有统计时新语句的查询计划，以及 ASCII 匹配与“先小写再查找”等价。

本机 Rust 1.97.1 MSVC，最终提交上：工作区格式检查、工作区全目标严格 Clippy 通过；工作区全部测试 1512 项通过、0 项失败，103 项 ignored 为原有的隔离 helper 和本地素材夹具。

性能：`search-benchmark --existing-db <100 万条合成库> --queries 280 --folder-facets --request-file`，每行都有用户标签；`search-benchmark` 新增 `--tag-exclusion-cases`，可直接复跑主要场景。每个请求 2 轮共 40 次，优化前后的二进制交替运行。表中为搜索加目录 facet 的 P50 / P95，括号内为结果页的 P50 / P95，单位 ms。第 1 组运行时机器负载较轻；第 2 组运行时同机其他程序占用 CPU（结束时 83%），未改动的“无筛选”请求也从 29 ms 升到 36 ms。每行都有 `outdoor` 标签，排除 `door` 会排除全部行，所以两个排除词用 `explosion,footstep`。

| 请求 | 第 1 组优化前 | 第 1 组优化后 | 第 2 组优化前 | 第 2 组优化后 |
| --- | --- | --- | --- | --- |
| 仅排除 `explosion` · 时长升序 | 443 / 668（180 / 313） | 162 / 248（72 / 115） | 597 / 812（244 / 341） | 241 / 306（110 / 145） |
| 仅排除 `explosion` · 时长降序 | 442 / 702（183 / 318） | 161 / 252（72 / 116） | 593 / 813（251 / 329） | 244 / 321（112 / 153） |
| 仅排除 `explosion,footstep` · 时长升序 | 482 / 715（205 / 331） | 186 / 288（85 / 133） | 658 / 913（283 / 395） | 275 / 351（128 / 160） |
| 仅排除 `explosion,footstep` · 时长降序 | 481 / 730（204 / 319） | 184 / 279（84 / 133） | 648 / 865（270 / 367） | 274 / 343（124 / 172） |
| 仅排除 `rareword` · 时长升序 | 436 / 634（176 / 295） | 153 / 222（69 / 106） | 589 / 778（241 / 321） | 237 / 313（104 / 139） |
| 仅排除 `explosion` · 时长升序 · 第 10000 条起 | 444 / 694（185 / 319） | 163 / 214（76 / 110） | 596 / 763（250 / 328） | 247 / 355（113 / 166） |
| 无筛选 · 时长升序 | 29 / 44（6 / 9） | 27 / 43（6 / 9） | 36 / 52（8 / 11） | 41 / 63（9 / 12） |
| 包含 `outdoor` + 排除 `explosion,footstep` · 时长升序 | 303 / 480（151 / 237） | 190 / 279（91 / 128） | 403 / 536（202 / 250） | 274 / 409（136 / 201） |
| 仅排除 `explosion` · 默认排序 | 438 / 702（178 / 285） | 155 / 230（69 / 102） | 602 / 780（248 / 287） | 236 / 331（104 / 150） |
| `metal` + 排除 `footstep` · 相关度 | 452 / 740（194 / 293） | 381 / 524（157 / 224）¹ | 619 / 863（266 / 363） | 309 / 420（100 / 143） |
| 仅排除 `explosion` · 文件名 | 439 / 693（180 / 309） | 161 / 246（71 / 109） | 606 / 836（241 / 359） | 239 / 308（107 / 140） |
| 仅包含 `outdoor` · 时长升序 | 182 / 283（84 / 128） | 178 / 282（81 / 133） | 242 / 337（111 / 154） | 268 / 343（123 / 166） |
| 排除 `explosion,door`（全部排除）· 时长降序 | 366 / 585（182 / 329） | 193 / 292（80 / 124） | 498 / 661（254 / 325） | 286 / 370（119 / 159） |
| 包含 `outdoor` + 排除 `explosion,door`（全部排除） | 253 / 403（126 / 201） | 168 / 264（84 / 131） | 329 / 418（166 / 211） | 250 / 311（126 / 156） |

¹ 第 1 组的优化后二进制还没有带搜索词路径的改动；其余请求两组的代码相同。“无筛选”和“仅包含”不经过改动的代码，组内差异按噪声处理。

与 feat/sidebar-tab-switch 试合并（`git merge-tree`，不写入）没有冲突。本分支未合并，按要求没有更新 `local_release/`，也没有发版。

## WASAPI 空闲连接释放与 DAW 共存（2026-10-22，0.6.2，beta）

修复提交 `fd400fc` 在控制线程上为 WASAPI 增加 500 ms 空闲释放：Ready、Paused、Stopped、Ended 到期后销毁输出连接，保留源、位置、变换和播放会话。快速预览仍可复用输出，Playing（含网络缓冲）与 ASIO 不进入该释放策略。源码检查未发现普通播放路径周期性激活外部窗口或枚举 ASIO；已确认的缺陷是旧实现仅暂停 WASAPI，长时间保留音频客户端。此项修复不等同于已经复现并确认 Reaper 的失焦根因。

本机 Rust 1.97.1 MSVC、已校验 Steinberg ASIO SDK 2.3.4：工作区格式检查、音频包全目标 ASIO 严格 Clippy 通过；音频 86 项及 IPC 1 项测试通过。音频的两个既有 ignored 用例分别为夹具导出与缺失的本地 BOOM Metadata 夹具；不重复制造或读取工作库。新增四项确定性回归覆盖空闲时限、逻辑状态、播放/缓冲取消释放、ASIO 生命周期和释放后的定位/变换/会话语义。

标准 ASIO release 构建通过。`validate-playback-ipc.ps1 -CleanCheckout` 在真实 WASAPI 输出上通过 20 项检查，设备输出 96 kHz、实际缓冲 960 帧；验证暂停、自然结束、Stop 后断开且不自行重开，暂停续播保留会话，Stop/Ended 重播分别新增一个会话。夹具为隔离的静音 WAV，源文件未改变；没有测量实际声学启动延迟。构建、测试、便携包验收及固定安装的日志和 SHA256 记录保存在忽略目录 `.rust-validation/wasapi-idle/`，最终安装状态以其中的 `delivery.json` 为准。

尚未完成原声卡与 Reaper ASIO 的联合验收。人工复测应使用 beta 启动器：先预览任意音频并等待结束或暂停至少一秒，再切换到 Reaper 连续右键框选数分钟；同时检查再次预览、暂停续播和停止后重播。若仅在两者同时播放时仍出现打断，需要另行核对具体 ASIO/WDM 驱动的多客户端及采样率限制。

## 镜像目录与保守清理（2026-10-22，0.6.0，本地迭代）

本轮基于 main `e90596d`，局部整合镜像目录按钮和缓存清理，没有覆盖旧工作树的未提交修改。
按钮支持已保存、同组且已知同库的 LAN / 外网配置；改地址、未知身份和缺失文件均拒绝。
清理使用非阻塞的 staging → publication OS 租约，保护正在使用或记录的镜像、
续传文件、受保护恢复任务、手动备份、未知文件及链接指向的内容。
Windows junction 与真实跨进程 Busy 回归使用隔离夹具，不接触工作库或源 WAV。

一次工作区格式检查、受影响包的严格 Clippy 和定向回归日志保存在
`.rust-validation/mirror-cache/`。远程首轮 221 项通过、两项夹具失败，
修复后复验两项及清理模块，复用其余通过结果：一项修正 mklink 路径分隔符，
另一项从真实快照字节构造缓存，避免夹具额外生成未知锁文件；生产删除范围没有放宽。
桌面首轮 252 项通过、85 个隔离 helper 标为 ignored，CLI 19 项通过；
暂停切源测试的首次失败和单独复验日志均保留。

阶段诊断测得暂停点击返回约 207 ms，完整暂停与切源约 2.7 秒，接近原 3 秒总断言。
该用例尚停在 health 响应头，未进入新增清理路径。测试现把原 3 秒约束精确绑定到
服务端实际观察到的 HTTP 连接关闭，同时保留原 12 秒流程预算及全部切源门禁、
Metadata、暂停意图、空白库和自动同步抑制断言。这是测试计时语义修正，
不声称修复了生产取消逻辑；临时诊断代码已移除。
修正后的暂停模块 4 项父用例、镜像入口 2 项父用例全部通过；
隔离子用例由父测试执行，不重复累计。
首次原生截图发现缓存页头部和清理说明纵向拉伸，已通过两处布局约束修正，
保留英文自然换行；该轮原始截图和构建证据留在 `history-6c32228/`。
其原生续传 6 项、review-fixes 10 项和关闭 6 轮均已通过；
review runner 首次因隐藏 PowerShell 默认 CP936 误解码中文而失败，
仅修正其 UTF-8 测试 bootstrap 后通过，未修改生产 Metadata 解码。

最终复验、标准 ASIO release、原生关闭/续传、双语界面、便携包与固定安装的
实际结果、源提交和二进制 SHA256，以本机忽略目录
`.rust-validation/mirror-cache/delivery.json` 为准。安装目录仍为原仓库的
`local_release/`，新增功能不发布新 tag 或 GitHub Release，也不部署生产服务器。
未重复百万条基准、播放/真实 ACL、无关库管理或其他目标平台验收。

## 远程续传 CR：整合最新 main（2026-10-21，0.6.0）

本轮从已完成的续传实现合入 main `d64c0a7`，workspace 为 **0.6.0**。
保留 schema 6 / p1、共享兼容目录、受保护迁移和独立的本机历史侧库；
没有把旧 0.5.1 测量当作当前构建证据，也没有打开工作库或修改源 WAV。

CR 修复固定对象的旧 revision 被最新 `/library` 错误拒绝、前置兼容失败误清断点、
首次响应的错误库身份被误分为过期重试，以及续传/304 绕过实际格式准入的问题。
固定对象保留其完整格式描述；客户端仍拒绝旧对象覆盖已经推进的缓存。
验收夹具补齐现代 capability 协商；桌面夹具保留发布门禁断言，
完整压缩缓存恢复明确要求本地重放；另修正已有波形测试共享槽的有界等待，生产波形代码不变。

Rust 1.97.1 MSVC 的一次 workspace 格式检查、workspace/all-targets 严格 Clippy 通过。
初次 workspace 测试的失败日志保留；修复后仅复验受影响目标，并续跑尚未执行的目标，
复用其余已通过结果。远程兼容性 **5/5**、续传专项 **11/11**、桌面续传父用例 **4/4**、
服务端波形并发 **19/19** 通过；修复后 remote、desktop、server 严格 Clippy 均通过。
其余工作区测试已有通过结果，包括迁移/崩溃恢复、CLI、音频及 Windows 单元测试和服务端集成；
Slint 子用例由隔离父测试执行，不重复累计。需要外部实库或硬件的 ignored 用例不计为已执行。

本轮 release、原生故障/关闭、review-fixes、便携包、Windows 服务端包及固定安装的
实际结果和二进制 SHA256，统一记录在本机忽略目录
`.rust-validation/cr-resume-main/delivery.json`，对应日志也保存在该目录。
原 0.5.1 机器可读报告另存于其 `history-0.5.1/`，不与本轮合并统计。
构建与打包使用同一套已校验 ASIO SDK；测试设置、数据库和启动均隔离，
不改变正常数据目录环境。未重复百万条基准、播放/真实 ACL 验收或真实库迁移；
其他服务端目标平台、生产外网链路和生产部署不在本机已验证范围。

## 历史：远程数据库断点续传初轮（2026-10-21，0.5.1 main 基线）

本轮基于 `origin/main` 的 `c90c0fe3675480a5776431ecb1b756fbafd1b92f`，
workspace 版本为 **0.5.1**，迭代位于 `codex/snapshot-resume-main` 工作树。
保留 main 的 Waveform 管理、默认单击试听、键盘试听修复及 Metadata 保存发布顺序；
旧 0.4.11 工作树及原有未提交修改没有被覆盖。下方旧构建结果是历史记录，不计入本轮验收。

本轮实现固定快照 Range 续传、压缩字节持久断点、单解码器本地重放后惰性连接后缀、
暂停/继续/重新下载、30 秒正文无数据重试，以及客户端关闭后的恢复。
缓存发布与清理共用 OS 锁；清理确认精确数据库文件，迟到事件不能删除新断点或暂停意图。
Windows 回归发现并修复了 CloseHandle 后锁释放延迟，两个 lease 均显式 unlock。
服务端仍使用 schema 5，快照支持 3–5；没有修改业务库 schema、工作库或源 WAV。

Rust 1.97.1 MSVC 下，格式检查与四个受影响包的严格 all-targets Clippy 通过。
定向验证为：远程客户端 **203 passed**；服务端单元 **110 passed / 1 ignored**、
API **65 passed**、关闭清理 **6 passed**；桌面暂停/发布窗口 4、传输进度 6、
切源 23、单击偏好 1、启动管理器判断 2，共 **36 个父层测试 passed**；
CLI identity **5 passed**；数据库 feature revision **9 passed**。
隔离 Slint 子进程 helper 在普通列表中标为 ignored，由其父测试显式执行。
未重复无关 workspace/ASIO 测试、百万条基准、播放或真实 ACL 回归。

使用校验过的 Steinberg ASIO SDK 2.3.4，标准 release 构建通过，耗时 **311.065 秒**。
`validate-review-fixes.ps1 -CleanCheckout` 的 **10 项检查通过**。
原生空库关闭 **6 轮通过**（每轮两个重复关闭请求），正常退出耗时 **66.66–75.63 ms**。
新 release 的远程故障脚本在 32 条合成记录、381,560 字节 zstd 快照上通过：
断线后从 190,780 字节续传；真实 30 秒静默连接后在 **32,100 ms** 完成自动恢复；
多次失败后新 CLI 进程从 357,712 字节续传；显式 restart 从零下载且保留旧缓存；
桌面在静默正文中正常关闭耗时 **136 ms**，重启后从 190,780 字节恢复。
脚本核对最终内容、Range 偏移及旧缓存身份，未使用真实工作库。
Windows 服务端包的校验和、边界、解包版本/哈希及隔离 health/schema 检查通过；
包启动脚本不测试优雅停机，服务端关闭行为由上面的 6 项 shutdown 测试覆盖。

便携包与服务端包的合成边界回归通过。原生运行、构建和安装证据分别记录在本机忽略目录的
`.rust-validation/remote-resume/report.json`、`.rust-validation/desktop-close/report.json`、
`.rust-validation/resume-main-build.json` 及固定安装目录所在工作树的
`.rust-validation/local-install-resume-main.json`；以最终 EXE SHA256 绑定本轮构建。
本轮仅在 Windows x64 本机验证；macOS/Linux、生产外网链路和生产部署未验证或执行。

## PR #20 同步 main 与旧库自动升级（2026-10-21，0.6.0-dev.1，未发布）

main `c90c0fe`（0.5.1，含方向键试听）已合入 `c81eca2`；保留排序预算、schema 6 / p1 与本机历史迁移。`7216563` 隔离启动测试的共享日志捕获状态，`c0870a8` 让桌面构建尊重显式 Slint 调试元数据开关。CLI / 服务端 / benchmark 的本轮可执行源码为 `c81eca2`，桌面最终检查源码为 `c0870a8`，显式启用测试调试元数据。两端版本均为 `0.6.0-dev.1`，精确旧端例外含 0.4.11、0.5.0、0.5.1；不允许旧客户端读取或写入新 p1。

按新版 AGENTS 做相关检查：core 兼容/配置/滚动估计、DB 迁移（40 个顶层用例）及结构/快照/排序/分页/租约集成、remote 旧协议和新版格式错误、服务端兼容/启动/状态接口/任务、CLI 迁移命令、桌面写入排空/关闭重试/历史/波形和音频读取回归通过。公共 `Error::NewerDatabase` 影响全部直接消费者，使用 workspace/all-targets 严格 Clippy 覆盖编译；后续仅对变化的 server、desktop 重跑相关 Clippy/测试，没有跑完整 workspace 测试或 ASIO。初始 core `newer_database`、server `service::` 筛选没有命中用例，不计测试覆盖；格式错误由 DB/remote 测试覆盖，服务就绪由 `api` 中的 3 个实际测项覆盖。正式 CLI 的 library-management、review-fixes（CleanCheckout）各 10 项检查通过，未读取原库或打开音频设备。

服务端真实 `AppState` 入口验证 schema 3/4/5、p0 自动升级到 p1，保留稳定 ID、Metadata、用户注解、收藏、旧 user_rating 与未知 SQL/JSON 扩展，删除明确退役对象；完成后再次打开无新任务，备份可回滚，回滚后普通启动不自动重升。完整 p1 不迁移；未来 schema、已知更高 feature 和未知必需 feature 拒绝且库字节不变。3/4 为基于历史 DDL 构造的布局，不是归档实库。迁移模块同时覆盖声明式 nullable/default 字段增加、字段退役、依赖阻断、断点恢复与本机旧事件先导入再退役。服务端 Router 验证 health 可达、库接口 503→就绪及失败重试；不是实际局域网或服务器平台验收。

新增 main 的键盘测试最初缺 Slint 元数据，单设环境变量仍被原 build.rs 的 release 强制关闭覆盖；保留两次失败日志，`c0870a8` 增加显式 1/0 开关，默认按 profile 处理。该配置的严格 desktop Clippy 及静音键盘父测试通过；父测试实际执行子进程用例，不重复累计子进程汇总。正常 release 默认仍关闭这项元数据。

909,342 行已有 owned p1 副本，仅用新工具各开一个只读进程抽查采样率、标签、时长、修改时间、声道。与上一轮 final-native 记录的请求、总数、页面 ID 顺序及目录统计全部一致；搜索分别 **222.683 / 327.486 / 43.993 / 229.800 / 275.590 ms**，搜索＋目录最高 **459.366 ms**。OS 缓存未控制，无并行 Cargo；不含 provider 打开，也不替代先前全 86 类、百万压力或全库迁移证据。副本大小和修改时间不变，未重复哈希大库。

日志在本机忽略目录 `.rust-validation/cr-plan-b/pr20-main-sync-run.json` 所指目录，保留初始失败、修复复验及源/二进制身份。PR 继续草稿，不合并、不部署、不打包安装；本任务未改当前安装、工作库或正常数据目录环境。实际部署前置条件及用户通知后的检查见 [局域网验收](api/Schema_V6_LAN_Acceptance.md)。

## 首次排序退化修复（2026-10-21，0.6.0-dev.1，未发布）

查询源码 `a65e102`：覆盖现有采样率/时长/修改时间/声道/标签索引，分页后才读宽 Metadata，不增建索引、不改库结构。真实 909,342 行的 86 类首轮搜索＋目录 P95 **466.797→417.446 ms**、最大 **2517.621→540.193 ms**；独立进程五类首轮搜索 **358/384/114/250/289 ms**，合计最高 **514.813 ms**。OS 缓存未清空，仍有单例超过 500 ms。86×3 页面/完整 DTO/目录摘要与修复前及 v5 相同；真实 0.5.0 CLI 全 86 类与最终受影响十类排序对照一致，仅归一化退役播放字段。

百万 26 类 first-only 工作负载搜索＋目录 P95 **338.894 ms**。额外“百万全部命中”压力发现 Tags 物化退化，最终为 Tags/Channels 设置 131,072 命中预算，大集合保留原查询；标签压力页仍 516–531 ms、加目录 727–744 ms，未声称达标。相关 fmt/严格 DB Clippy 和 **39 个不同测项通过、0 failed**，最后预算变更复用未受影响的已通过结果；只构建 CLI/benchmark，未重复 workspace/ASIO/迁移/播放/打包/安装。当前安装和工作库不变，PR #20 保持草稿，不合并、不部署。协议、具体源身份/复用范围、独立旧程序、失败样本与结果边界见 [排序补充验收](api/Schema_V6_Iteration.md#首次排序修复与补充验收2026-10-21)。

## v6 / p1 与方案 B CR（2026-10-21，0.6.0-dev.1，未发布）

源码 `e0df12a`：默认和 ASIO 两套格式、严格 Clippy、locked workspace/all-targets 测试通过；每套 **69 个顶层目标、1,230 passed、0 failed、79 ignored**。数量排除父用例继承的重复子进程汇总，未将全部 ignored 项目声称为已执行。release、便携包、library-management 和 review-fixes 回归通过；909,342 行主库 19,495,989,248 → 10,611,302,400 字节（-45.572%），完整迁移/回滚、752 条历史导入、58 类原生查询与 86×3 provider 一致性核验通过。百万条合成库 26 个 fresh-provider case 的搜索＋目录 P95 为 405.211 ms（不含打开；OS 缓存未控）。真实库首轮 P95 为 466.797 ms，但首次排序最大 2,517.621 ms 的退化已定点复现；现有桌面实例占用正常 IPC，正式 playback-ipc 验收未通过且未控制该实例。本任务不安装、不部署；最终 p1、本机历史、旧客户端及回滚证据以 [v6 迭代记录](api/Schema_V6_Iteration.md) 和 [CR 记录](api/Search_Storage_B_CR.md)为准。

下面的 0.5.0-dev.1 / p0 测量属于此前构建，不能替代当前配方的验收。

## 历史：方案 B 隔离验证（2026-10-21，0.5.0-dev.1，未发布）

共享迁移器、兼容目录、播放结构退役和断点恢复的当前证据见
[实现与验收记录](api/Implementation_B_Status.md)及
[最终全库复验](api/Search_Storage_B_Integrated_Validation.md#0-最终构建复验当前结论)。
最终 ASIO 全工作区为 **1,137 passed、0 failed、75 ignored（67 targets）**，
格式化和严格 Clippy 通过；隔离 release/便携包及库管理、Metadata/扫描回归通过。
909,342 行真实快照从 19.496 GB 降到 10.612 GB，查询一致性和完整回滚通过；
1M 合成库的最终 26 类请求首次搜索 P95 为 298.915 ms（OS 缓存未清空）。
当前安装和工作库不变，不替代下面记录的其他 GUI、音频或 Mac 验收。
## 远程快照下载与解压双进度（2026-10-21，0.4.11 修复构建）

开发集成源码修复为 `aecd59b0f376d992940bea4d592407eec1ebd122`，已推送。最小 main backport 为 `d479a2c3d02a5e286e5d09dc939d597854d38aab`，通过 [PR #16](https://github.com/Freedragonlancer/AudioLib-Explorer/pull/16) 合并为 `88d8bf39a086d2040927f48bb841e144cfa1099f`；未夹带集成分支的 84 个前置提交或其他任务文档。

zstd 下载按 HTTP `Content-Length` 统计压缩响应体字节，解压按 `X-Uncompressed-Length` 统计数据库写入字节。GUI 连接页和缓存/导出页显示两组文字及独立进度条，19,495,989,248 字节对应的 **18592.8 MiB 仅用于解压总量**。缺失总量时分别保持不定进度，普通响应只显示下载。CR 另修正声明大小过小时重复绕过节流、首次收到下载总量被节流隐藏的问题，并加入回归。

Rust 1.97.1 MSVC 的格式检查、默认及 ASIO 两套严格 workspace/all-targets Clippy 均通过。默认 locked workspace/all-targets 测试：开发集成版本 **65 个目标、1,075 passed、73 ignored、0 failed**；main backport **50 个目标、824 passed、71 ignored、0 failed**。PR 关联 Windows 与 Linux CI 均通过。两名代理分别审查后端、GUI 和最小 backport，没有未解决发现。

本次验证范围过大。按用户要求停止重复 ASIO 全套测试和额外原生截图运行，省略无关 Metadata/库维护回归；不再追加测试。相同 Slint 布局在之前一轮已通过原生 UI 回归（1 passed），检查中英文、连接/缓存页、下载完成继续解压和解压总量未知的 8 个截图场景；该历史结果没有计作本轮新执行结果。

使用验证过的 Steinberg ASIO SDK 2.3.4，`tools/build-release.ps1` 成功，用时 **306.177 秒**；标准便携打包成功，包验证通过（5.487 秒）。独立本机 `CARGO_TARGET_DIR` 的新 EXE 按 SHA256 同步到规范 release 输出后再打包，251 个源码/构建输入在构建和打包后哈希一致。

固定 `local_release/` 已更新 **1,214 个包内文件**，通过 `validate-portable.ps1 -BinaryDirectory local_release -CleanCheckout`，CLI 版本为 **0.4.11**。本机保留既有开发集成功能并包含 `aecd59b` 的修复。两份安装 EXE 与验证过的便携包及本轮 release 输出 SHA256 一致：

- AudioLibExplorer.exe：`1B0F980A43C38B503A0CC847F3563E1F6F1E080D9FC574366DA2C7D4771ED174`
- AudioLibCli.exe：`FCDEE68E454616E5E4D4E1E57CB62D3EC9DE366652D640E82C3A969C2ED1A231`

只覆盖包内文件，未清空安装目录。工作库、设置、Waveform 缓存库和占位缓存共 4 项的大小及 UTC 修改时间保持原值，设置 SHA256 与正常 `AUDIOLIB_DATA_DIR` 环境不变。上轮基线的远程 r793 快照已在本轮 CR 前被替换为 r819；当前 19,495,989,248 字节快照及缓存清单均早于本轮验证。旧基线导致的核对误报已保留，修正核对后确认安装完成，没有恢复或改写用户缓存。记录位于本机忽略目录 `.rust-validation/snapshot-progress/`。

## 升级恢复与最新客户端/服务端集成（2026-10-20，0.4.11 开发候选）

本轮首先修复首次升级无法续跑、WAL 未截断及停机快照残留，再按用户要求拉取并合并最新远端代码。最终可执行源码为 `1d81a784e7372a21a71968470eef83061807133c`，包含 `origin/main` 的 `71bb1fd`、客户端 `integ/client-list-waveforms` 的 `c50bd27`、服务端 `integ/list-waveforms-final` 的 `3eef19c`，以及 `bd58b3f` 的升级恢复修复。构建完成后再次 fetch 并验证三条远端分支都是当前提交的祖先。发布说明保留 Unreleased 状态，未创建新 tag、未发布 GitHub Release、未部署 8790。

Rust 1.97.1 MSVC 的格式化、默认及 ASIO 两套严格 Clippy 和完整 locked workspace/all-targets 测试全部通过：**每套 64 个顶层目标、1,067 passed、73 ignored、0 failed**。247 项动态源码/配置/资源输入与维护的 GUI 性能验证脚本在检查、构建及发布回归前后 SHA256 相同。ASIO 使用校验过的 Steinberg SDK 2.3.4。第一次集成检查发现的目录缓存测试问题与修正边界见 [审查修复](Rust_Review_Fixes.md)；失败批次日志保留。

正式 `tools/build-release.ps1` 构建耗时 **272.717 秒**；`validate-review-fixes.ps1 -CleanCheckout`、`validate-library-management.ps1` 和 CLI 片段回归通过。编译期间只有根目录文档修改，动态编译输入保持冻结；构建身份报告因此记录 `WorkingTreeChanges=true`。本轮两 EXE 的身份为：

- AudioLibExplorer.exe：`6B8C4578EB72F5DBEF732D531ECEDEF9B60637B491B5FBBD6A4D1ECE51678CB4`
- AudioLibCli.exe：`7383190DC9848C0F0A97F3B46A5B5E7F66EED3E16056AA51658FDE58ED0486EA`
- audiolib-server.exe：`FA23469A577B1F2ED059E78775F3A732FB57A778E0FAE17102598C7860C10376`；同一 workspace 构建，`--version` 为 0.4.11。

恢复回归覆盖分词、索引、验证和 checkpoint 阶段的取消及子进程突然退出，检查续跑、完整行数、signed ID 极值、Metadata、未知扩展和播放历史保留；另检查旧已打开 writer 的持久保护、读事务阻塞 checkpoint 时的 Busy、释放后 WAL 归零，以及未知恢复协议拒绝执行。服务端回归覆盖快照创建/压缩取消、活动下载持有文件、带锁的残留目录清理、health 进度、正常停机 WAL 回收与 revision 不虚增。用户已明确暂缓原 Mac 的同机耗时复测；这些功能回归不能代替新的 Mac 性能数据。

真实库使用 `upgrade-benchmark --source <原快照> --live`，只在 owned 副本中执行实际可写库 WAL 升级，没有强制降级源数据。909,342 条记录、19,492,810,752 字节，schema 5、tokenization 2→3，SQLite 3.53.2；Windows 本地 SSD、Ryzen 7 9800X3D（8 核/16 线程）、100,415,373,312 字节物理内存，预校验已预热文件缓存，测量时没有并行 Cargo 构建。结果如下：

| 项目 | 实测 |
| --- | ---: |
| 源 quick-check/FK/统计 | 34.711 秒 |
| 复制到 owned 临时库 | 33.687 秒 |
| owned 升级前完整性检查 | 65.162 秒 |
| **可写库打开及升级，含回退备份、验证、分批 checkpoint** | **336.371 秒** |
| 其中备份阶段通知至首批分词通知（含备份验证及初始化） | 67.954 秒 |
| 分词阶段通知至索引阶段通知 | 158.756 秒 |
| 索引阶段通知至验证阶段通知 | 95.969 秒 |
| 索引验证通知至 checkpoint 通知 | 13.536 秒 |
| 升级后完整性检查 | 63.766 秒 |
| 全流程含准备和临时目录清理 | 536.141 秒 |
| 进程峰值 working set / 采样 private bytes 峰值 | 243,048,448 / 235,114,496 字节 |
| **200ms 采样 WAL 峰值 / 成功打开时 WAL** | **151,780,832 / 0 字节** |
| owned 目录采样峰值（主库、回退备份、WAL/SHM） | 39,137,730,016 字节 |

分词和索引均提交到 909,342 条；升级前后 SQLite、FTS5、外键检查通过，条数不变。原库测试前后 SHA256 均为 `5ADAECFFB603716F4B2840EFA2838F3D8174B2C9825B0D95EAF93275EBF6393F`，大小及修改时间一致；测试退出码 0，owned 临时目录已经删除。采样峰值是观测下界，目录大小不含保持不变的原快照，也不含运行中的服务器快照缓存；正常升级保留的回退备份在本次临时目录清理时一并删除，不代表生产升级会删除回退备份。该源修订和硬件与 Mac 报告不同，不能把 336.371 秒视为 Mac 新耗时或直接用其计算提速倍数。

候选包通过正式 portable 流程更新固定 `local_release/`；两个目录各自运行隔离验证，只复制包所有文件并核对 SHA256，不替换工作库、设置、日志或源 WAV。最终安装结果独立记录在 `.rust-validation/resumable-upgrade/completion.json`，仅其 `success=true` 且两个 portable 检查和全部载荷哈希通过才表示安装完成。开发包与已发布 v0.4.11 的二进制身份不同，不能作为该 Release 的原产物；下一次发布仍需新程序版本和新 tag。

完整检查与构建日志位于本机忽略目录 `.rust-validation/gui-e2e/round-upgrade-integrated-2/`，真实副本测量及安装记录位于 `.rust-validation/resumable-upgrade/`。原有搜索性能慢样本和未执行的 224 样本矩阵仍保留；**P95 latency <500ms for 1M+ records 尚未全面验收通过**。

## b49f7d2 搜索与 GUI 阶段收尾（2026-10-20，0.4.11）

用户要求尽快阶段收尾后审查、推送，本轮据此停止扩展优化。**P95 latency <500ms for 1M+ records 仍未全面达到**；完整 224 样本矩阵尚未开始，也未完成。当前源码为 `b49f7d278505669ac025b4b49b9eceec45873728`，与另一个 Debug 任务协调后独立完成代码、构建及 GUI 操作，未混入其 Mac 升级、WAL 或服务端生命周期修复。

本轮将首次文件名排序的完整 MATCH ID 收集、基本筛选交集及精确计数移至宽 Metadata 查询之前，验证现有可选覆盖索引后由 SQLite 执行 NOCASE 排序及 ID 升序平局规则，仅加载所选页面。无附加筛选的 present 请求要求同快照全 present 证明；不适用或超预算时完整回退。此前的冷目录统计、复杂查询文档长度、时长覆盖分页及 30ms debounce 优化继续保留。空页菜单动作采用稳定可用状态与实时空页 guard，保留 WGC 的严格可见性和同步几何检查。

同一正式 ASIO GUI EXE 完成三个独立阶段批次，各 14 类请求、每类一次、每次新进程。真实库为 909,342 条、20,248 个目录的 owned 只读副本，另有独立百万条合成库。分页 200 条，首次目标请求排名缓存未命中；OS 缓存未清空，启动、索引准备和校准不计入计时。终点为结果页与完整目录计数模型发布后、CRC/nonce/代次符合的首个观测 WGC ALL compositor frame，包含生产 debounce、排队及当前视口绘制；不是物理屏幕出光或同时绘制所有目录。

| 阶段样本 | 有效 / 无效 | ≥500ms | P95 / 最大 |
| --- | ---: | ---: | ---: |
| 真实库，synthetic Slint 输入 | 14 / 0 | 4 | 933.151 / 933.151ms |
| 百万条合成库，synthetic Slint 输入 | 14 / 0 | 2 | 568.9038 / 568.9038ms |
| 真实库，原生 Sky 输入 | 14 / 0 | 1 | 609.3829 / 609.3829ms |

全部 42 个有效样本的页面顺序、精确总数与全部目录计数均与计时后 oracle 一致；7 个有效慢样本全部保留，不以重试替换。每组只有 14 条不同请求，P95 按原摘要 `ceil((n-1)*p)` 索引计算，此处等于最大值；不能据此建立长期尾延迟保证。百万条 `ambient` + 48kHz + 0–5s + 文件名排序本次为 **125.9468ms**，前轮同类有效慢例为 1,673.8516ms；真实库该请求的本次 synthetic 样本仍为 **584.7215ms**。局部优化不意味着总体达标。完整条件及历史失败见 [GUI 搜索性能](Rust_GUI_Search_Performance.md) 与 [待解决问题](Rust_Known_Issues.md)。

Rust 1.97.1 MSVC 的格式化、默认和 ASIO 严格 workspace/all-targets Clippy、完整 locked 测试全部通过：**每种配置各 57 个顶层目标、959 passed、72 ignored、0 failed**。227 项动态源码/配置/资源输入及维护的 GUI 验证脚本在检查与构建前后保持相同 SHA256，正常数据目录环境和六项持久数据基线保留。首次完整检查捕获了旧 COUNT 密度测试与新免 COUNT 文件名路径的测试意图冲突；该旧测试改用 Modified 继续验证原 128 行密度阈值，新文件名路径由完整 native SQL oracle 回归覆盖，随后重新执行两套完整检查。

同源正式 ASIO 构建耗时 **262.641s**，Steinberg SDK 2.3.4 由准备脚本验证。发布版 `validate-review-fixes.ps1 -CleanCheckout`、`validate-library-management.ps1` 和 CLI 片段回归通过。构建与测量的身份为：

- AudioLibExplorer.exe：`588553215AF4C0A6133DEB0C456F0B66A756AD1DB68AC38495970161CC0A97EA`
- AudioLibCli.exe：`938265EBE96612314ED9609A3EC81C72430E4A17A5C1BA3A33AE7FDACD066527`

阶段安装使用相同 ASIO 便携载荷和固定 `local_release/`：先打包及隔离 portable 验证，再仅覆盖包所有的文件、核对两 EXE 与全部载荷 SHA256，最后执行安装目录的隔离 portable 验证并复核持久数据。安装结果独立记在本机 `.rust-validation/gui-e2e/round-v11-checks/completion.json`，仅其成功结果可证明安装完成；其中 `StageAcceptanceOnly=true`、`PerformanceTargetMet=false`、`Full224Complete=false` 与软件安装成功分别记录。没有发布 Release 或 tag，未替换工作数据库或源 WAV。

原始私有阶段记录由 `.rust-validation/gui-e2e/coordination/stage-report-storage-v1.json` 定位，检查和构建日志位于 `.rust-validation/gui-e2e/round-v11-checks/`。旧的有效慢例、无效捕获及失败检查批次继续保留。原定大矩阵与后续性能定位均为待办。

## 7ec84ed 审查修复与真实升级资源复测（2026-10-20，0.4.11）

本轮按主报告及逐行补充报告修复 BM25 跨平台测试判定、源路径别名、辅助 reader 资源预算、mmap 策略、串行回退诊断、服务端升级进度及 FFI 生命周期回归，并合并上游 `afb2f04`。单字母查询仍按用户明确要求返回输入提示；API 文档明确当前服务器只提供快照，尚未实现远端搜索路由。Mac 原生数据库 CI 单独验证 ARM64 C/Rust 浮点及文件系统行为，不以 Windows 结果代替 Mac 测试。

真实升级使用当前只读服务器缓存：909,342 条音效、20,248 个目录，19,492,810,752 字节，schema 5、tokenization 2。新 `upgrade-benchmark --source` 先验证源库，再用 SQLite backup 生成 owned 临时副本，验证副本后实际执行修订 2→3 升级，最后通过公共完整性检查并自动清理副本；没有强制降级或升级用户工作库。源文件在测试前后 SHA256 均为 `5ADAECFFB603716F4B2840EFA2838F3D8174B2C9825B0D95EAF93275EBF6393F`，大小、修改时间相同，升级后条数仍为 909,342。

首次完整测量发现一个额外资源问题：`check_library()` 复用搜索池中的 mapped reader 复制整库，使全流程峰值工作集达到 19,542,970,368 bytes，而采样 private bytes 约 129MB；这不能描述为升级本身需要 19.5GB 私有内存。修复让完整性检查使用独立禁用 mmap 的只读连接，并继续持有原 read gate，副本目标也禁用 mmap。`b4d64e6` 的正式 release 工具复测结果如下；后一轮文件系统重定位和 GUI 诊断修改没有参与该次测量。

| 真实升级复测阶段 | 秒 |
| --- | ---: |
| 源只读验证 | 34.304 |
| owned 副本完整性预检 | 64.073 |
| 实际升级 | **236.582** |
| 其中全部 909,342 行派生文本完成 | 161.941 |
| FTS5 构建结束、进入 source tags | 236.555 |
| 升级后公共完整性检查 | 286.448 |
| 工具全流程（另含复制等阶段） | 656.357 |

整个工具进程的 Windows 高水位工作集为 **123,932,672 bytes**，200ms 采样的 private bytes 峰值为 **128,884,736 bytes**；3,120 个采样点。采样不能保证捕捉 private bytes 的瞬时峰值，工作集也包含共享/映射页。硬件为 Ryzen 7 9800X3D（8 核、16 线程）、系统报告内存 100,415,373,312 bytes、本机 SSD；测量期间没有并行编译或 GUI 性能测试，OS 缓存未清空。这是 Windows owned DELETE-journal 副本的整套工具测量，不能代替服务器 WAL 写入负载、Mac 峰值内存或播放首声测量。工具 SHA256 为 `07EE67409B72E5AD655011D8CC70901F7FDC497838A8431785A727BD5F029AD4`。

两轮源报告、逐阶段 JSONL、采样方法及前后哈希保留在本机忽略目录 `.rust-validation/review-7ec84ed/upgrade-real-v1*` 与 `upgrade-real-v2*`。首次失败资源基线保留，未覆盖为成功结果。

最终应用源码为 `38c5ed2ecdf59adf799ade50882171e5fb8522c4`，Windows Rust 1.97.1 MSVC 的 `cargo fmt --all -- --check`、默认及 ASIO 严格 workspace/all-targets Clippy、完整 locked 测试全部通过：每种配置各 **54 个顶层目标、925 passed、72 ignored、0 failed**，隔离子进程不重复计数；两套检查总计约 410.7 秒。ASIO 使用准备脚本验证过的 Steinberg SDK 2.3.4。222 项应用、crate、服务端、配置及资源输入在检查前后集合及 SHA256 不变；正常数据目录环境和六项持久数据基线保持一致。此前 `b4d64e6` 的检查与构建证据另保存在 `checks-b4d64e6/`，没有覆盖为最终版本。

同一提交的 [原生 macOS ARM64 数据库 CI](https://github.com/Freedragonlancer/AudioLib-Explorer/actions/runs/39372798464/job/118464191043) 通过：`macos-15` runner 安装 `1.97.1-aarch64-apple-darwin`，先断言 `uname -m=arm64` 并验证编译器/C tooling，再执行 `cargo test -p audiolib-db --lib --tests --locked --target aarch64-apple-darwin`。涵盖主报告的四项 BM25 测试、Unicode fixture、源别名及大小写改名回归；不是交叉编译或 Windows 结果推断。该 CI 不验证 Mac 桌面、ASIO、真实大库升级资源或音频首声，且本轮未运行 Miri/ASan。相同工作流的 Linux 服务端检查也通过。

同源正式 ASIO release 构建耗时 256.53 秒，版本 `0.4.11` 开发构建，未发布新 Release。两 EXE 在本机 SSD 构建后复制到打包使用的仓库 target 目录并逐个验哈希：

- AudioLibExplorer.exe：`7CE8AE1FC9A49648128FD221F3A4C192248783880DBFF502E055ACE080D2E1C5`
- AudioLibCli.exe：`D47A65C2C8C3FCE48A920216F5BE2ECB1472843A60E94F646588F0EF1EB00664`

`search-benchmark --records 1000000 --queries 100 --fragment-cases --query et --concurrent-writer --db <new-owned-path>` 新建独立百万条合成库，不复用历史冻结 fixture。生成及重建耗时 168.24 秒；`et` 查询的两组各 100 次，每次使用新只读 provider、provider 打开和目录统计不计入搜索计时。无写入搜索 P95 **114.804ms**；并发 favorite 提交 P95 **188.654ms**（1.643 倍），共 8,054 次提交，写线程每次提交后等待 2ms。无写入组 100 次并行尝试、无回退；并发组 99 次尝试均因 `snapshot_changed` 回退，Busy/Locked/Interrupted/Unavailable/启动失败均为 0。这证明本次提交竞争回退可见，不代表测出了扫描时 Busy、网络盘或真实扫描全负载。整个含生成、重建、搜索及写入的进程峰值工作集 **277,479,424 bytes**，200ms 采样 private bytes 峰值 **259,784,704 bytes**；并非仅搜索新增内存。

正常结束后 checkpoint 返回 `(0,0,0)` 并关闭连接，主库 1,786,855,424 bytes，SHA256 `8D131FFB2E55A770802A79ACA5E23ABF9F5658D90B02DA9177D7A6F7B5C688DF`，无 WAL/SHM/journal。再以同一 EXE 对它执行只读 **21 类请求、100 次共享 provider 循环、21 类新 provider 首查及目录统计**，不带 query filter：共享结果页 P95 **114.210ms**、搜索加目录统计 P95 **208.895ms**；新 provider 首次串行总计 P95 **224.083ms**（打开另计）。完整混合工具峰值工作集 **284,418,048 bytes**，200ms 采样 private bytes 峰值 **130,957,312 bytes**。7 个辅助 reader 各 8MiB cache，普通 reader 64MiB，本地 fixed-volume 的 mmap 配置上限 64GiB；上限不是实际驻留内存。测试期间无并行编译、GUI 或其他基准，OS 缓存未清空；沿用含测前统计的历史混合协议，不能混称严格新进程首查或 GUI 端到端。测后库 SHA256、大小及修改时间不变。目标仍为 **P95 latency <500ms for 1M+ records**；这些是本次资料与条件下的实测。

同一正式 GUI EXE 的真实 909,342 条副本 `impact metal` 原生输入筛查（`gui-e2e/native-probe-v4`）结果页和全部目录计数与 oracle 相符；进程工作集高水位 **400,482,304 bytes**，200ms 搜索窗口仅 3 次采样，private/current WS 最大分别为 **353,734,656 / 395,149,312 bytes**。这是一个画面验收无效样本的资源观察，不能外推宽泛查询、整套矩阵或 8GB 机器预算。工具捕获到 431.59ms 的匹配画面，但真实瞬时 Resized 事件触发严格几何门禁，因此保留为 invalid，**不计为 GUI <500ms 达标样本**。大批量 GUI 矩阵由另一协调任务继续；本轮没有测量搜索同时试听的实际首声延迟。

本轮原始基准与资源/哈希证据位于 `.rust-validation/review-7ec84ed/concurrent-million-v1*`、`mixed-million-v1*`、`million-fixture-baseline.json`；benchmark EXE SHA256 为 `AE3363B78F0030BAC244193E3B8B2396849F3CBB30D61D94EEFD172AEB982D53`。新合成库保留供后续只读 GUI 验收，未删除源 WAV 或正常运行数据。

发布版 `validate-review-fixes.ps1 -CleanCheckout`、`validate-library-management.ps1` 均通过；`package-portable.ps1 -SkipBuild` 与上述构建使用相同 ASIO 选择，随后对 `dist/latest/portable` 和固定 `local_release/` 分别运行 `validate-portable.ps1 -CleanCheckout`，两次均通过 EXE 身份、隔离首次启动、CLI/UI 和启动诊断检查。旧库/WAV fixture 在本 checkout 缺失，由支持该模式的脚本明确跳过，不能计为真实音频或首声验收。安装仅覆盖包拥有的 1,213 个文件，没有删除或镜像清理安装目录，也没有强制终止用户应用；两份已安装 EXE SHA256 与上述正式构建、验证后的包完全一致。六项持久数据基线及正常 `AUDIOLIB_DATA_DIR` 环境保持原值，未覆盖工作库、设置或 SQLite sidecar。日常入口继续为 `local_release/Start-AudioLibExplorer.cmd`。成功记录在本机 `.rust-validation/review-7ec84ed/installation.json`，本轮只推送开发分支，没有创建 tag 或发布 GitHub Release。

## 片段搜索 CR 推送前检查（2026-10-20，0.4.7、tokenization 3）

本轮复审修复单 grapheme 完整 Unicode 折叠的片段漏命中，以及非相关度分页/COUNT/排名预算 SQL 回退可能重复 MATCH 的执行顺序，详见 [审查修复](Rust_Review_Fixes.md)。派生文本修订升为 3；原修订 2 的真实库后端测量保留为历史证据，不能代替新修订或 GUI 输入到完整显示的验证。

`cargo fmt --all -- --check`、默认与已校验 ASIO SDK 2.3.4 配置的严格 workspace/all-targets Clippy、完整 locked 测试全部通过：两种配置各 **52 个顶层目标、873 passed、71 ignored、0 failed**，隔离子进程不重复累计。217 项应用、crate、服务端、资源及配置输入的集合与 SHA256 在整套检查前后保持一致；当前六项持久数据基线、正常数据目录环境及真实源库大小/修改时间也保持一致。Rust 1.97.1 MSVC，构建缓存位于本机 SSD。

首次检查被新增测试的冗余 struct update 警告中断；修正后在新审计批次完整重跑两种配置，耗时 440.39 秒，没有忽略警告或覆盖失败记录。检查证据位于本机忽略目录 `.rust-validation/gui-e2e/prepush-retry1/`；初次失败保留在 `prepush/`。此阶段尚未运行新修订的真实库 GUI 帧计量，也尚未打包或更新安装；这些结果需由后续独立验收记录确认。

## 真实音效库首次查询与目录统计（2026-10-20，0.4.7 本地开发构建）

本轮直接只读验证机器上当前有效的服务器缓存快照，没有拿空的本地库或合成库代替真实资料：**909,342 条音效、20,248 个目录、19,492,810,752 字节**。真实库未满百万条，因此另保留原有百万条合成基准回归；目标术语仍为 **P95 latency <500ms for 1M+ records**。所有测试不联网同步、不重建索引、不运行 ANALYZE、不写入真实库或源 WAV。

原业务实现的首次对照发现一个真实慢例：`ambient` 加 `sample_rate=48000`、`duration_min=0`、`duration_max=5`，命中 11,776 条、199 个正计数目录；搜索 216.16ms、目录统计 **62,268.15ms**，外层串行总计 **62,484.31ms**。未过滤的完整排名为 17,156 条，过滤索引候选有 154,447 条。源码与复现执行计划表明，缺少 ANALYZE 统计时，过滤索引外层会逐条进入复杂位置 MATCH，与现场慢例一致；原实现没有利用小排名缓存，即使去掉旧的 65,536 条准入门槛，候选仍超过 `8×17,156+8192=145,440` 的预算而回退到原慢计划。

修复让任何同修订完整排名均可尝试有界交集；预算溢出仍丢弃整个部分结果，随后使用共享 `folder_search_from` 构造的 FTS5 外层 CROSS JOIN，一次遍历 MATCH 后按 ID 读取文件并应用原参数化筛选。无缓存及修订不稳定也走这一完整回退。没有增加候选上限、截断结果或改变原生 BM25 排序；无/陈旧统计的执行计划、小排名不重新访问 FTS、候选溢出、NULL/非二元 missing、目录范围与分页均有回归。极宽 MATCH、极窄过滤且没有缓存时仍有扫描匹配集的成本，不能据此宣称对任意选择率都最优，详见 [架构说明](Rust_Architecture.md)。

新增 `--request-file` 读取上限 1MiB 的非空、逐条校验 `SearchRequest` 数组，`--first-only` 在共享 provider、统计及 warm search 之前分流。每个正式样本启动一个新进程/只读 provider，计时前只有 schema/派生状态检查，拒绝隐式升级副本；按顺序调用 `search`、`search_folders`，同一个外层计时器记录总计。全库窄索引 COUNT、SQLite 配置探测、结果 ID 与目录计数输出均放在计时后。打开 provider 单独报告；总计不含 GUI 防抖、排队或绘制。原 21 类混合基准保留测前统计的历史协议，不能与此严格首查协议混称。

正式构建后的固定请求集合为 `explosion`、`expl`、`plos`、`metal`、`door outdoor`、`impact metal`、`foley`、`whoosh`、`et`、`on`、`爆炸` 和上述带采样率/时长筛选的 `ambient`；全部跨目录、present、relevance、descending=false、limit=200、offset=0，其余筛选默认。没有沿用合成库的 folder 1 作为真实范围；全部请求均有命中。每类运行 30 个独立进程，结果页有序 ID、完整命中数及全部排序后的 folder ID/count 均逐次与修复前基线比较。分位取排序后 `ceil((n-1)*p)`；保留全部慢例，不自动重试或替换样本。

硬件仍为 Ryzen 7 9800X3D、约 93.5GiB 系统可见内存、本机 WD_BLACK SN8100 2TB SSD，Rust 1.97.1 MSVC、已校验 ASIO SDK 2.3.4。正式计时与编译、发布回归及用户 GUI 分开执行；OS 页面缓存未清空，首次对照后已进行源文件完整哈希，因此是新进程/provider 的首次业务查询，**不是物理冷盘或 GUI 端到端保证**。连接缓存、mmap 和并行 reader 的资源配置与下节一致；64GiB mmap 是配置上限，不是驻留内存。

正式 **360 次总计 P50 为 120.98ms、P95 为 277.78ms、最大 293.20ms，≥500ms 为 0/360**。搜索本身 P50/P95 为 98.92/263.86ms，随后目录统计 P95 为 91.17ms；provider 打开 P95/max 为 39.36/43.01ms，单独计时。各列分位不能相加。每类完整 30 次结果如下：

| 请求 | 完整命中数 | 正计数目录 | 总计 P95（ms） | 总计 max（ms） |
| --- | ---: | ---: | ---: | ---: |
| explosion | 10,020 | 941 | 105.62 | 106.47 |
| expl | 13,177 | 1,236 | 86.58 | 87.65 |
| plos | 11,280 | 1,074 | 99.99 | 103.87 |
| metal | 85,996 | 4,231 | 281.43 | 287.16 |
| door outdoor | 2,085 | 425 | 95.39 | 100.32 |
| impact metal | 25,867 | 1,498 | 289.85 | 293.20 |
| foley | 64,980 | 1,707 | 130.42 | 133.56 |
| whoosh | 43,343 | 2,223 | 120.98 | 121.07 |
| et | 562,510 | 13,923 | 197.93 | 204.49 |
| on | 638,080 | 15,227 | 202.83 | 209.96 |
| 爆炸 | 1 | 4 | 62.60 | 65.91 |
| ambient + 48kHz、0–5s | 11,776 | 199 | **185.49** | **186.14** |

原筛选慢例的最终搜索 P95 为 132.16ms、目录统计 P95 为 57.81ms，30/30 总计低于 500ms。全部 360 个样本的有序结果页 ID、返回数、完整命中数及每个目录的精确计数均与修复前基线一致；最初 62.48 秒样本和中间候选记录全部保留。缓存条件不同，不能把两轮结果页时间之差单独归因于这次目录统计改动。

随后用同一正式 benchmark EXE 回归原有 1,000,000 条隔离合成库，保留 21 类完整请求及 100 次共享 provider 循环，逐类请求、命中数与正计数目录数同前一轮正式结果一致。共享结果页 P50/P95 为 0.59/111.60ms，共享搜索加目录统计总计 P95 为 **200.69ms**；21 类新 provider 首次搜索 P95 为 126.21ms、首次总计 P95/max 为 **215.23/283.85ms**，0/21 达到 500ms。该历史混合协议保留测前统计，OS 缓存未清空，不代替上述真实库严格首查测量。

默认与 ASIO 的格式检查、严格 workspace/all-targets Clippy、完整 locked 测试均通过：各 52 个顶层目标、**869 passed、71 ignored、0 failed**，隔离子进程不重复计数。版本 0.4.7，基于 `a666857b0913dde070e1fb2e61d69f65d37d7bf0` 加工作区修改；217 项应用、crate、服务端、配置和资源输入在全套检查、正式构建及性能验收后 SHA256 一致。正式 ASIO 构建耗时 276.65 秒；`validate-review-fixes.ps1 -CleanCheckout`、`validate-library-management.ps1` 和 CLI 片段验收通过。缺失旧库/WAV fixture 明确跳过，不计为真实资料或实际音频输出验收。正式 EXE SHA256：

- AudioLibExplorer.exe：`C1D53DC2474C0EEB70BB8329273A370BE0C91AF3D5D402BFB972320D6C0514CF`
- AudioLibCli.exe：`173D0747151F2A36AC59DF481890C8019844C9D50D9AFEA44C55239AE7501F1B`
- search-benchmark.exe：`51C5A37570C804908778C9E989F78B50C51F4812266F1D6431C104C071988BDD`

真实库在首轮对照后及全部正式测量后的完整 SHA256 均为 `5ADAECFFB603716F4B2840EFA2838F3D8174B2C9825B0D95EAF93275EBF6393F`，大小、修改时间一致；合成库仍为 `2CD3AABD7A32D12E44AB05C9529058A0050A9FAF7194A5E4B1123AE7124D179B`。正常数据目录环境及本轮六项设置/工作库/sidecar/远端状态基线也保持一致。没有为适配旧基线恢复或覆盖运行数据。

本轮所有原始 JSON、stderr、请求、失败基线和校验输出保留在本机忽略目录 `.rust-validation/real-first-total/`：`formal-summary.json`、`formal-verified.json` 和全部 `formal-rXX-cYY.json` 对应 360 次实测，`synthetic-verified.json` 对应百万条回归，`library-hash-final.json` 对应测后完整源库校验。便携包与固定 `local_release/` 分别运行隔离 `validate-portable.ps1 -CleanCheckout`；最终安装状态、构建→包→安装两 EXE 身份、完整包内文件身份及六项持久数据复核以该目录 `completion.json` 的成功记录确认。安装仅覆盖包内文件，日常入口仍为 `local_release/Start-AudioLibExplorer.cmd`，正常数据仍位于 `%LOCALAPPDATA%/AudioLibExplorer/v1`。

## 首次复杂查询与目录统计总耗时优化（2026-10-20，0.4.7 本地开发构建）

本轮将 `door outdoor` 首次复杂查询与随后目录统计的串行总耗时纳入验收，目标为 **P95 latency <500ms for 1M+ records**，并要求该复杂请求的 30 次首次总计全部严格小于 500ms。实现采用主 reader 加七个辅助 reader 的精确全局统计准备及八段评分；目录统计先投影筛选 ID，与同快照完整排名交集，再读取覆盖索引中的目录。宽泛密集 ID 使用至多 1MiB 位图顺序计数，其余保留 8192-ID 分块查询；候选或内存预算超限时丢弃整个部分结果并完整回退。原生 BM25 分数、排序、分页、完整计数及 Metadata 契约保持不变，细节及官方资料见 [架构说明](Rust_Architecture.md)。

复用同一只读隔离合成库：单目录、1,000,000 条 present 记录、主库 1,776,566,272 字节；测试前后 SHA256、大小和修改时间一致，SHA256 为 `2CD3AABD7A32D12E44AB05C9529058A0050A9FAF7194A5E4B1123AE7124D179B`。硬件为 Ryzen 7 9800X3D、约 93.5GiB 系统可见内存和 WD_BLACK SN8100 2TB 本机 SSD，Rust 1.97.1 MSVC。普通及辅助连接各保留 64MiB SQLite cache，配置 mmap ceiling=64GiB，bundled `SQLITE_MAX_MMAP_SIZE=68719476736LL`；这是按需虚拟映射上限，VFS 可降低或回退，不是每个连接预占 64GiB RAM。benchmark 在全部计时结束后只读探测，requested/effective 配置读回值均为 68,719,476,736 bytes，不代表实际映射长度。

最终完整 ASIO release 构建及发布回归完成后，在没有并行编译或应用升级重负载、原 GUI 已退出的空闲窗口计时。OS 页面缓存没有清空，且测前会校验 fixture 文件哈希；因此这里的“首次”指新进程或新 provider 的首次查询，不是物理冷盘测试。每轮仍为原有 21 类查询、每页 200 条、100 次共享 provider 循环；各类请求、命中数与目录数逐一对照原基准，没有缩减工作负载。所有首次排名缓存未命中，目录统计可复用刚生成的完整排名。

| 正式完整工作负载（ms） | 第 1 轮 | 第 2 轮 |
| --- | ---: | ---: |
| 循环结果页 P50 / P95 | 0.87 / 130.87 | 0.82 / 129.52 |
| 循环结果页与目录统计串行总计 P95 | 239.92 | 242.67 |
| 21 类新 provider 首次结果页 P95 | 133.35 | 131.41 |
| 21 类首次搜索与目录统计总计 P95 | **214.30** | **221.77** |
| 21 类首次总计最大值 | **287.89** | **294.16** |
| 首次总计 ≥500ms | **0/21** | **0/21** |

另连续运行 30 个独立进程，每次只采用新只读 DataProvider 的第一条 case 4：`door outdoor`、folder 1、包含子目录、limit 200、offset 0、relevance、descending=false、visibility=present，其余筛选为默认。每次完整匹配 1,000,000 条且 `search_ranking_cache_hit=false`；不用同进程后续样本替代。分位取排序后 `ceil((n-1)*p)`，全部样本保留。

| 独立进程首次复杂请求（30 次，ms） | min | P50 | P95 | max | ≥500 次数 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 搜索 | 223.43 | 233.25 | 248.61 | 248.99 | 0/30 |
| 随后的目录统计 | 60.78 | 62.45 | 67.61 | 67.89 | 0/30 |
| **搜索与目录统计串行总计** | **285.00** | **296.98** | **311.87** | **312.14** | **0/30** |
| provider 打开，单独报告 | 23.03 | 27.02 | 42.87 | 43.07 | 0/30 |

总计由外层计时器直接测量，不包含 provider 打开、GUI 防抖、排队和绘制。各列分位不能相加。GUI 文件页和目录统计仍由两个 worker 并行发布，其交互端到端延迟未由本基准测量。总体 P95 和指定复杂请求逐次总计门槛均通过；额外观察的全部 42 个首次总计也通过，但这不是任意生产资料库或任意负载下最大延迟的保证。

本轮失败记录完整保留：旧构建五次总计为 531.25–547.22ms；首个密集计数候选 30 次中首样本为 621.72ms，整批逐次门槛失败，没有移除。首次正式 v1 的混合筛选曾达到 4514.68ms；仅调大 mmap 的中间实验仍失败，因此又实现筛选 ID 投影及交集。中间 staged2 的复杂请求 30 次总计 P95/max 为 356.71/394.18ms，但空查询 `tag_contains=rareword` 的首次总计为 724.87ms。最终空闲正式批次该标签请求总计为 214.30/221.77ms；没有再为此改动源码，也不能据此把此前差异归因为某个已证实的单一原因或宣称旧 outlier 已消失。原始对照、分阶段诊断、失败正式构建及所有重测均保留。

默认及 ASIO 的 `cargo fmt --all -- --check`、严格 workspace/all-targets Clippy 和完整测试通过：每种配置各 52 个顶层目标、864 passed、71 ignored、0 failed，隔离子进程不重复计数。新增回归覆盖筛选交集预算、极端 signed ID、NULL/非二元 missing、覆盖计数计划、分块边界、旧 WAL 快照、取消与 SQL 错误。发布前复核还修复了 ready/prepared 重复失败通知可能填满有界队列并阻塞 join 的问题；每个 worker 在各通道只发送一次，确定性回归覆盖启动失败及两个 gate 的取消。20ms 是接收/gate 轮询粒度，不是 SQLite 执行取消的总耗时上限。

最终源码为 0.4.7，基于 `a666857b0913dde070e1fb2e61d69f65d37d7bf0` 加工作区修改；217 项应用、crate、服务端、配置及资源输入在完整检查、构建和性能验收前后 SHA256 一致。已校验 ASIO SDK 2.3.4 的正式构建耗时 311.54 秒，发布版 `validate-review-fixes.ps1 -CleanCheckout`、`validate-library-management.ps1` 及 CLI 片段搜索验收通过。缺失的真实旧库/WAV fixture 显式跳过，不计为生产资料库或实际音频输出验收。正式二进制 SHA256：

- AudioLibExplorer.exe：`489FAB0E5723566DC978F2C61E6DC5AB2A75E5094BF9DFE32EE6768B5F1E8100`
- AudioLibCli.exe：`596FF7321D910BF6AE28465EBEBA512209A0CF03B7D8FA8BF5A389A777E9D9DF`
- search-benchmark.exe：`31E47CEA0BB8ECFEC2B9B1CF15E0F61636C034F0C17C750A4A71151C8A9231B7`

正式性能证据在本机忽略目录 `.rust-validation/first-total/formal64-*`，失败正式 v1 独立保存在 `failed-formal-v1/`，此前 candidate/staged2 不覆盖。联合打包、固定 `local_release/` 更新及安装后隔离验证由 `.rust-validation/index-upgrade/` 记录；最终包→安装 EXE 身份、便携验证及持久数据复核由本轮 `completion.json` 记录。安装只覆盖包内文件，保留正常数据目录和库路径；原 GUI 在安装前已退出，两个任务均未强制终止它。服务器同步正常轮换缓存及关闭时的设置保存分别记录，不能为凑齐旧哈希而回写运行数据。

## 服务器缓存索引升级与可见进度（2026-10-20，0.4.7 本地开发构建）

现场旧服务器缓存需要从 `tokenization=1` 升级到 `2`，重新计算派生文本并构建 FTS5。进程的 CPU 与磁盘读写持续增长，同一次同步最终正常完成；仅凭界面停在“正在升级搜索索引”及累计秒数，无法判断是否卡死。宽 Metadata 和位置二元编码会扩大重写数据量及回滚日志，这与小型合成库的耗时条件不同。

Owned snapshot 升级原来采用 SQLite 默认约 2MiB 页缓存；现在与普通 writer 一样使用 64MiB 页缓存和内存临时存储，保留 DELETE 回滚日志及原同步耐久性。重建每 5,000 条记录报告真实累计计数，另行显示 FTS5 构建和提取标签阶段。行数只代表文本阶段，未知耗时阶段仍不显示估算百分比。日志记录阶段、节流后的处理条数及耗时，不记录 Metadata 或凭据。未在同一真实大库上进行旧、新配置的速度对照，因此不宣称加速倍数或固定完成时限。

全部重分词批次和 FTS5 构建保留同一迁移事务，已观测到的批后取消及 FTS5 开始前取消均逐字节回滚。迁移提交后的取消由远端准备流程丢弃 owned staging，保留当前缓存、状态和已有 reader。新增回归覆盖真实旧 Porter 索引、10,003 条跨批处理、完整 signed i64 边界、原 Metadata 与标注保留、空库、取消及完成后重复调用不写文件；远端回归覆盖进度传播及各阶段取消，隔离 Slint 子进程检查双语行数和阶段显示。

共同最终源码的 `cargo fmt --all -- --check`、默认及 ASIO 严格 workspace/all-targets Clippy、两种配置的完整测试全部通过：各 52 个顶层目标、864 passed、71 ignored、0 failed，隔离子进程不重复计数。输入 SHA256 在全套检查及正式构建期间保持一致。基于 `a666857` 加本地修改的完整 ASIO release 构建耗时 311.54 秒；`validate-review-fixes.ps1 -CleanCheckout`、`validate-library-management.ps1` 和发布版 CLI 片段验收通过。缺失的真实旧库/WAV fixture 不计为已验证。构建、回归、便携包及固定安装的本机审计输出保存在忽略目录 `.rust-validation/index-upgrade/`。

## 首次复杂查询优化（2026-10-20，0.4.7 本地开发构建）

本轮继续处理此前约 758ms 的 `door outdoor` 首次慢例，目标仍为 **P95 latency <500ms for 1M+ records**，并额外要求本批次每个首次结果页均低于 500ms。保留两字符起任意连续片段、默认 BM25 分数、ID 次序、完整计数及 Metadata。三个辅助 reader 分别准备不重叠短语组的全局 DF，同时主 reader 加载文档长度；验证同一快照并完整发布统计后，再按四段 rowid 范围评分。SQLite 默认关闭全局内存统计以减少分配锁竞争，保留 THREADSAFE=1、事务与 WAL 锁；内存边界和回退契约见 [架构说明](Rust_Architecture.md)。

复用同一份只读隔离合成库：单目录、1,000,000 条 present 记录、主库 1,776,566,272 字节，测试前后 SHA256、大小和修改时间一致。硬件仍为 Ryzen 7 9800X3D、约 93.5GiB 系统可见内存和 WD_BLACK SN8100 2TB 本机 SSD，Rust 1.97.1 MSVC。四个常驻 reader，每 reader SQLite cache 64MiB、mmap 上限 1GiB；单个 provider 最多新增三个临时辅助 reader。

正式完整 ASIO release 构建后，在没有并行编译的情况下，两次运行原有 21 类查询及 100 次共享 provider 循环：`search-benchmark --existing-db <隔离库> --queries 100 --fragment-cases --folder-facets --first-provider`。没有修改查询集合或减少结果数。

| 正式工作负载 | 第 1 次 | 第 2 次 |
| --- | ---: | ---: |
| 循环结果页 P50 / P95 | 0.78 / 155.45ms | 0.74 / 115.54ms |
| 循环结果页与目录统计串行总计 P95 | 313.91ms | 336.90ms |
| 21 类新 provider 首次结果页 P95 | 198.81ms | 176.60ms |
| 21 类新 provider 首次结果页最大值 | 302.12ms | 306.57ms |
| 21 类首次搜索与目录统计串行总计 P95 | 457.38ms | 475.33ms |

两次循环排名缓存均命中 75/100；全部 42 个首次结果页均未命中排名缓存且小于 500ms。每轮最慢的仍为 `door outdoor`，均完整匹配百万条。

另以同一正式 benchmark EXE 连续启动 30 个独立进程，每个只采用新只读 DataProvider 的第一条查询：`--case-index 4 --queries 1 --folder-facets --first-provider`。精确请求保持 `door outdoor`、folder 1、包含子目录、present、relevance、升序、offset 0、limit 200，其余可选筛选为空。每次 `total_count=1,000,000`、`search_ranking_cache_hit=false`，不采用随后同进程的预热样本。

| 独立进程首查（30 次，ms） | min | P50 | P95 | max | ≥500 次数 |
| --- | ---: | ---: | ---: | ---: | ---: |
| 结果页查询 | 296.38 | 307.33 | **352.20** | **364.84** | **0/30** |
| provider 打开，单独计时 | 22.20 | 25.28 | 29.27 | 30.33 | 0/30 |
| 搜索后目录统计 | 231.78 | 238.27 | 248.44 | 260.28 | 0/30 |
| 搜索与目录统计串行总计，不含打开 | 532.56 | 549.39 | 601.37 | 604.22 | 30/30 |

OS 页面缓存未清空；这些是新进程/新 provider 的首次查询，不是物理冷盘或完整 GUI 输入到显示延迟。分位取排序后的 `ceil((n-1)*p)`，所有样本保留。首次复杂结果页的本批次最大值达标，不能推导为任意请求的最大延迟保证；其与目录统计的串行总计仍超过 500ms，GUI 两类 worker 并行发布的时间另需测量。

本轮最初五次旧构建对照为 788.07–875.99ms。只共享统计并并行评分的前一候选在 30 次中仍有 3 次超时：第 19/20/22 次为 568.21/534.71/518.83ms，整批判失败，未删除或替换。增加准备阶段重叠后的诊断 30 次为 299.51–343.42ms，P95 337.07ms；随后以上正式构建又独立复测 30 次。全部对照、失败和最终原始 JSON/stderr 均保留于本机忽略目录 `.rust-validation/first-complex/`。

格式检查、默认/ASIO 严格 workspace/all-targets Clippy 和全部测试通过：两种配置各 51 个顶层目标、845 passed、71 ignored、0 failed，隔离子进程不重复累计。定向回归涵盖逐位原生 BM25 分数及排序、极端 ID、稀疏长度的原生回退、完整统计发布、跨提交保留旧 snapshot、两道 gate 的取消、资源释放及真实 SQL 错误传播。发布版 `validate-review-fixes.ps1 -CleanCheckout`、`validate-library-management.ps1` 和 CLI 片段验收通过；缺失的真实旧库/WAV fixture 显式跳过，不计为生产资料库或实际音频输出验收。

版本 0.4.7，基于 `a666857b0913dde070e1fb2e61d69f65d37d7bf0` 加工作区修改；215 个应用、crate、服务端、配置与资源输入在完整检查及正式构建前后 SHA256 一致。使用已校验 ASIO SDK 2.3.4 的完整 release 构建耗时 290.9 秒。最终 EXE SHA256：

- AudioLibExplorer.exe：`10142BC37F4A5FF9277DFEC715F31F6D4AA8C48F895B27435A7CEE9636BCA75A`
- AudioLibCli.exe：`58F17C098BFBAE71E13232FD55DB2EA418E8F02F61BCC1E04162A1739BB4CE60`

固定安装目标为仓库 `local_release/`，正常入口为 `local_release/Start-AudioLibExplorer.cmd`。便携包和固定安装分别执行隔离 `validate-portable.ps1 -CleanCheckout`，安装只覆盖包内文件。两 EXE 的构建→包→安装身份、ZIP 校验和、8 项工作库/sidecar/设置基线以及正常数据目录环境的最终核对，以本轮审计目录 `completion.json` 的成功结果确认；这些安装验证不访问用户工作库。

## 百万条宽泛查询性能优化（2026-10-19，0.4.7 本地开发构建）

以下保留上一轮结果；首次复杂慢例的后续优化和最新构建数据见本报告首节。

本轮在既有两字符起任意连续片段语义上优化宽泛查询，目标为 **P95 latency <500ms for 1M+ records**。保留默认 BM25、ID 次序、完整计数、分页及原始 Metadata；没有截断候选或修改基准查询集合。相同完整排名经逐 ID 比较后共享缓存，32MiB 预算按唯一 ID 数组计费；覆盖索引和保留 `missing=0` 的筛选使目录/格式统计避开宽 Metadata 行。目录统计在固定读快照内复用完整排名，以 8192 个 ID 分块聚合。

私有 FTS5 评分函数缓存同一修订的文档长度，减少逐命中的 docsize 查找。短语命中达到 `ceil(N/2)` 时可提前结束文档频率枚举，因为原生 IDF 此时已固定钳位为 `1e-6`。原生分数位级 oracle 覆盖稀有/常见短语、AND/OR、列限定、奇偶记录数半数边界和单条记录；稀疏 ID、长度槽损坏、语句释放、重复注册、取消和修订失效均有回归。原生 BM25 分数与排序保持一致；提前结束不承诺与全遍历在未访问损坏页上的报错时机相同。新增 `search_indexes` 实现修订 1；已有当前 tokenization 的库只增加索引，不重建 FTS5。

同一份隔离百万条合成数据使用 SQLite backup API 复制并增加当前两个索引，包含单目录下 1,000,000 条可用记录，主库为 1,776,566,272 字节，较原库增加约 48.9MiB。准备共 6.94 秒，其中 backup 2.82 秒、索引创建 2.36 秒；原合成库 SHA256 未变，没有重新生成 Metadata 或 FTS5。硬件为 Ryzen 7 9800X3D、约 93.5GiB 系统可见内存、WD_BLACK SN8100 2TB 本机 SSD；Rust 1.97.1 MSVC、校验后的 ASIO SDK 2.3.4，四个 reader、每 reader SQLite cache 64MiB、mmap 1GiB。

最终完整 ASIO release 构建后、没有并行编译时，连续运行两次 `search-benchmark --existing-db <隔离库> --queries 100 --fragment-cases --folder-facets --first-provider`。查询仍为原 14 类加 7 类字母片段，每页 200 条；P95 使用排序后 `ceil((n-1)*0.95)`。结果页为 DataProvider 执行时间；目录统计列为先结果页再统计的串行后端时间，GUI 两个 worker 仍并行，这些数据不包含输入防抖、事件排队和绘制。

| 同一基准口径（P95） | 优化前 | 最终第 1 次 | 最终第 2 次 |
| --- | ---: | ---: | ---: |
| 共享 provider 循环结果页 | 759.27ms | **120.26ms** | **119.06ms** |
| 同轮结果页与目录统计顺序总计 | 1407.49ms | **293.75ms** | **286.41ms** |
| 每类新 provider 的首次结果页 | 767.98ms | **423.92ms** | **419.30ms** |
| 每类新 provider 的首次结果页与目录统计顺序总计 | 1538.20ms | 678.42ms | 656.84ms |

两次循环排名缓存均命中 75/100（优化前为 69/100）；结果页 P50 分别为 0.81/0.69ms。首次目录统计 P95 为 254.50/244.33ms。固定查询混合包含命中百万条的 `metal`、`door outdoor`、`et`，以及普通片段、中文、目录范围、标签、采样率/时长、深 offset 和文件名排序。优化前对照为同轮记录的 `baseline-page-cases.json`；最终结果为 `benchmark-1m-1.json`、`benchmark-1m-2.json`。

新 provider 阶段每类仅一次、共 21 次查询，之后共享 provider 先执行一轮，再循环 100 次。OS 页面缓存没有清空，不能称为物理冷盘测试；首次目录统计可以自然复用刚生成的排名。首次 `metal` 结果页为 423.92/419.30ms；最慢的 `door outdoor` 为 758.16/755.57ms，均命中百万条。首次串行总计 P95 仍超过 500ms，后续问题见 [SEARCH-001](Rust_Known_Issues.md#search-001百万条数据的宽泛片段查询仍有慢例)。结果页 P95 已达标，但不能将其解释为每次请求最大延迟或完整 GUI 显示均在 500ms 内。

格式检查、默认与 ASIO 的严格 workspace/all-targets Clippy 和完整测试均通过；两种配置各 51 个顶层目标、834 passed、71 ignored、0 failed，隔离子进程不重复累计。发布版 `validate-review-fixes.ps1 -CleanCheckout`、`validate-library-management.ps1` 各 10 项通过；CLI 片段验收覆盖有效/无效片段、大小写、单字母拒绝及源 WAV 字节不变。新增定向用例还覆盖 canonical 排名哈希碰撞、最后引用计费、8192 分块边界、极端 ID、非零/NULL missing、范围/排序/分页无关的目录计数、外部写入失效及旧索引只读副本升级。

本轮基于 `a666857` 加当前工作区修改，214 个应用、crate、服务端、配置及资源输入在完整检查和正式发布构建前后 SHA256 一致。正式 ASIO release 构建耗时 301.9 秒，最终两个 EXE 的 SHA256 为：

- AudioLibExplorer.exe：`1BFD71692CC319ED4E9F7807D72C493C6287AA0BF24DB988200A7FF330B47171`
- AudioLibCli.exe：`93B56E57CE4E08E8F6BD1DC687CC588568E19CB54663C79425F61F1D79EAF398`

检查、基准原始 JSON、源码清单及构建/安装身份位于本机忽略目录 `.rust-validation/search-p95/`。现有工作库、SQLite sidecar、配置及其他持久数据使用独立基线核对，所有验证仅使用隔离临时数据；缺少旧库/WAV fixture 的发布回归显式使用 CleanCheckout，不计作旧 fixture 或实际生产库验收。

## 两字符起的字母片段搜索（2026-10-19，0.4.7 本地开发构建）

以下保留字母片段初版的验收记录；本轮后续的宽泛查询性能优化、最终构建和复测另见本报告首节。

关键词包含至少两个字符的字母片段时支持任意连续位置：`ex`、`expl`、`plos`、`sion` 均匹配 `explosion`。单个非汉字字母不发起搜索，并取消旧文件页和目录统计请求；空查询、单个汉字、数字及多词中的完整单字母代码保留原规则。两字符的判定按 Unicode 字素，组合重音不算额外字母。

FTS5 派生列改用位置二元编码，词间分隔防止跨词拼接；原文字段和编码字段分别限定查询，用户输入的类似编码字符串不会误匹配内部词元。移除 Porter，`tokenization` 实现修订升为 2，`user_version` 仍为 5。真实旧 Porter 索引的可写升级、只读副本升级、重复打开、Metadata/标注/扫描与播放历史保留均通过回归；恢复旧备份在重建前严格检查表和同步触发器，损坏备份不能被升级隐藏。WAV 源字节保持不变，无需重新扫描音频文件。

Rust 1.97.1 MSVC 的格式检查、默认与 ASIO 严格 Clippy、两种配置的完整 workspace/all-targets 测试均通过。每种配置各 51 个顶层目标、819 passed、71 ignored、0 failed；隔离子进程不重复计数。定向回归覆盖全部两字符起的 `explosion` 连续片段、大小写和重音、中文、数值、跨字段 AND、排序分页、目录计数和缓存失效。桌面用例还验证单字母输入取消旧请求，拒绝迟到的文件页/目录统计，并在清空输入后恢复浏览。

首轮完整用例发现既有表格测试在请求退出事件循环后，定时器再次回调而进入 `unreachable!()`；完成阶段改为幂等后复测通过。NAS 构建输出还出现生成 `.rmeta` 的访问拒绝，最终验证和构建使用本机 SSD 上独立的 `CARGO_TARGET_DIR`，保留原输出目录，并将新生成的 EXE 按 SHA256 同步回仓库 `target/`。正常数据目录和库路径没有迁移。

本轮源码基于 `a666857`，包含当前工作区修改。213 个应用、crate、服务端、配置及资源输入在发布构建前后 SHA256 一致。ASIO 使用准备脚本校验的 SDK 2.3.4，release 构建耗时 248.0 秒。`validate-review-fixes.ps1 -CleanCheckout`、`validate-library-management.ps1` 和实际 release CLI 片段搜索验收均通过；CLI 同时确认单字母查询被拒绝、无效片段不命中、合成 WAV 源字节不变。旧库/WAV fixture 不可用的检查采用明确的 CleanCheckout，不计为已执行旧 fixture 验收。

本机忽略目录 `.rust-validation/keyword-prefix/` 保存检查、构建、回归、输入清单及身份日志。当前 release 输出：

- AudioLibExplorer.exe：`0C7A919AFE2CA117210BB6AFACB99B0A48D04F5B25A0039C30C5F1FFD5FB484E`
- AudioLibCli.exe：`E813E21C14A915E0524AE71E9FC8E054C4918125108DED526B3CD2C768594DB1`

新增源 Metadata 复合代码回归：`FX_123` 的 `123`、`A.wav` 的多词 `a wav` 保留可检索性；位置边界防止 `1_AB_2` 误匹配数字短语 `1.2`。原始 JSON、用户标签和只读查询均验收通过。缓存回归验证稍超预算的循环工作集不会退化为全部未命中，大型新排名不能挤掉较小工作集，拒绝保留不改变本次完整结果；32MiB ID 预算、修订失效和每查询上限不变。

百万条性能实测使用 Ryzen 7 9800X3D、约 93.5GiB 可见内存和 WD_BLACK SN8100 2TB 本机 SSD。隔离合成库含 1,000,000 条记录，主数据库为 1,725,247,488 字节；使用最终 release CLI 重建当前派生索引耗时 33.9 秒。`search-benchmark --existing-db <隔离库> --queries 100 --fragment-cases --folder-facets --first-provider` 包含原 14 类及新增 7 类片段查询，每页 200 条；4 个 reader、每 reader 64MiB SQLite cache、1GiB mmap。首次 provider 阶段每类仅测一次，之后共享 provider 先运行一轮再循环 100 次；操作系统页面缓存未清空，因此不能称为物理冷盘测试。

| 最终测量 | P50 | P95 |
| --- | ---: | ---: |
| 共享 provider 循环结果页，排名缓存命中 69/100 | 0.63ms | 738.30ms |
| 同轮结果页后顺序计算目录统计 | 201.95ms | 1353.96ms |
| 每类新 provider 的首次结果页 | 未汇总 | 752.99ms |
| 每类新 provider 的首次目录统计 | 未汇总 | 782.10ms |
| 每类新 provider 的结果页与目录统计顺序总计，不含打开 provider | 未汇总 | 1535.09ms |

新 provider 上 `ex`、`pl`、`plos`、`sion` 各匹配 100,000 条，结果页分别为 69.25、68.90、93.13、94.46ms。`et` 匹配 1,000,000 条为 441.18ms；同为百万命中的 `metal`、`door outdoor` 分别为 752.99、1222.58ms。宽泛首次排序和部分筛选仍有慢例，整体不能认定满足 **P95 latency <500ms for 1M+ records**，后续问题见 [SEARCH-001](Rust_Known_Issues.md#search-001百万条数据的宽泛片段查询仍有慢例)。顺序服务计时包含目录统计，而 GUI 两类 worker 仍并行，结果页可先发布；这些数据不是完整 GUI 输入到显示延迟。
## 定位包络与列宽复查（2026-10-19，0.4.10 源码，未发布）

用户安装 0.4.10 后反馈定位仍有破音、自定义列宽不生效；原因与修复见 [审查修复](Rust_Review_Fixes.md)。

`seek-loopback` 新增 `--signal sine --tone-hz --source-rate --source-channels` 及二阶差分指标。CABLE Input 端点 48 kHz、增益 0.3、60 Hz 正弦（输出峰值 0.15），音调自身最大相邻差 0.001178、最大二阶差分 9.25e-6：

| 场景 | 修复前定位窗口 | 修复后定位窗口 |
| --- | --- | --- |
| 源 48 kHz 立体声（不重采样） | 相邻差最大 0.00497，二阶差分 0.0011–0.0048（约 120–520 倍） | 相邻差 0.001178，二阶差分 1.3e-5–1.4e-5（约 1.5 倍） |
| 源 44.1 kHz 单声道（重采样） | 二阶差分 0.0011–0.0048 | 二阶差分 1.3e-5–1.4e-5 |
| 源 96 kHz 6 声道（重采样） | 二阶差分 0.0011–0.0046 | 二阶差分 1.3e-5–1.4e-5 |

覆盖播放中定位、暂停后定位、三条排队定位、接近结尾定位、从 Ended 定位、暂停中 Seek 后 Play、换源和 Stop；所有命令引擎 underruns 为 0，未出现超过源峰值的旧 PCM。剩余较大二阶差分只出现在两处：首次 Play 的 5 ms 线性音量斜坡（约 0.0011，修复前后相同）以及测试音在文件末尾非零斜率处结束（EOF，属源内容）。捕获端仍报告 Xrun 通知，不称为无损采集，也不等同于模拟回录或人工听感验收。

新增音频回归 2 项、列宽回归 1 项；以旧包络或旧双击处理运行时均失败。格式检查、默认与 ASIO 严格 Clippy 通过；默认与 ASIO（`--no-fail-fast`）完整 workspace/all-targets 测试各 51 个目标、817 passed、0 failed、70 ignored。一次 ASIO 运行中 `audiolib-server` 的 `admin_roots` 列举起始位置因并发负载 5 秒超时（FS_TIMEOUT），重跑通过，与本次改动无关。debug 二进制上的 `validate-playback-ipc.ps1 -CleanCheckout`（默认 WASAPI 96 kHz、960 帧）与 `validate-desktop-close.ps1 -Cycles 3` 通过。本轮未构建发布包、未更新 `local_release/`；正常数据目录的 `settings.json` 未被改动。

## WASAPI 96 kHz Waveform 定位补修（2026-10-18，0.4.7）

根据用户反馈复查默认 WASAPI、96 kHz、播放中点击 Waveform。确定性回归复现旧顺序在淡出前打开解码器，以及 Pause/Load 保留设备队列的问题；此前单独测试包络和环形缓冲未覆盖这两层。控制线程现在先静音旧源，再执行可能阻塞的打开/定位；暂停前排空设备队列，失败路径也保留淡出尾段。细节见 [审查修复](Rust_Review_Fixes.md)。

真实 Worker/RenderCallback 测试覆盖 48/96 kHz、慢 opener、目标帧与源位置；独立的两缓冲设备 FIFO 覆盖暂停恢复、暂停后定位、复用输出换素材、重开失败、网络 Waiting 和 ASIO 两次完整静音回调。数据均为隔离临时 WAV。

`cargo run --locked -p audiolib-audio --example seek-loopback -- --device <明确端点子串> --expected-rate <设备频率> --volume <增益>` 实际使用 CPAL WASAPI render-endpoint loopback。测试合成正负 DC 段，重开延迟 200 ms（一次定位可能多次打开），执行播放中定位、暂停后定位、三条排队定位、换源和 Stop，不修改系统默认设备或工作库。

| 实测端点 | 结果 |
| --- | --- |
| CABLE Input，48 kHz，增益 0.3 | 360,384 个交错样本，峰值 0.045；各定位窗口最大同声道相邻差 0.001451619，等于 32 帧线性包络的约 `峰值/31` |
| Zen Go Playback 1/2，96 kHz，增益 0.01 | 741,120 个交错样本，峰值 0.001447988；定位、暂停、换源和 Stop 窗口最大相邻差 0.00004670944，约 `峰值/31`；首次 Play 的全局最大差为 0.0003016642 |

两次捕获都无容量溢出、削波、非有限值或致命采集错误，所有播放命令的引擎 underruns 为 0。捕获端分别报告 2/1 次 Xrun，96 kHz 的首次通知在样本 0；因此不称为无损采集，也不等同于模拟输出回录、人工听感或声学延迟验收。最初诊断在停止输出后才停止捕获而收到错误通知，后续增加错误分类并先停止捕获；原失败报告保留，未计为通过。

96 kHz PCM 逐帧复核：左右声道一致，实际输出定位段的 32 点包络拟合最大误差 `1.46e-10`。三条排队定位中前两条未形成非零输出，不能计为各自播放了完整淡入；最终目标起音前连续 118,050 帧为零，未发现旧 PCM 重现。首次 Play 的较大步差符合现有绝对音量平滑步长在 0.01 增益下约五步达到目标的公式，与定位包络分开记录。

本机忽略目录 `.rust-validation/seek-device/` 保存前后回归日志、两份实际端点 PCM/JSON、构建及安装身份。性能目标仍为 **P95 latency <500ms for 1M+ records**；本轮不重新测量搜索性能。

Rust 1.97.1 MSVC 的格式检查、默认与 ASIO 严格 Clippy、两种配置的完整 workspace/all-targets 测试均通过。每种配置各 50 个顶层目标、806 passed、70 ignored、0 failed，音频模块为 72 passed、1 ignored；隔离子进程不重复计数。209 个应用、crate、服务端、配置及资源输入在检查前后 SHA256 一致。ASIO 使用准备脚本校验的 SDK 2.3.4。

2026-10-19 完成源码提交 `4ec211a` 的 ASIO release 构建，耗时 4 分 54 秒，构建及发布回归期间上述 209 个输入保持一致。播放 IPC 17 项通过，默认 WASAPI 实际输出为 96 kHz、960 帧；隔离空库 WM_CLOSE/SC_CLOSE 各 3 次全部正常退出并重新打开库。便携包的隐私边界和 `validate-portable.ps1 -CleanCheckout` 通过。

固定 `local_release/` 已用本轮验证过的 1,213 个包内文件覆盖更新，两个 EXE 与包 SHA256 一致，安装后的独立临时数据 portable 验收通过，CLI 版本为 0.4.7。正常 `%LOCALAPPDATA%/AudioLibExplorer/v1` 的现有数据库、SQLite sidecar 和设置共 6 个基线文件 SHA256 未变，正常数据目录环境保留。旧库/WAV fixture 不可用的检查采用明确的 CleanCheckout，未执行依赖旧 fixture 的 runtime/ACL 验收。该段为构建完成后的文档记录，不改变已验收的二进制。

- AudioLibExplorer.exe：`B00D3255FB1DBEB0E797A611B13D2FA0FA15EFBB147D0D9788C9F71AEF1F69C2`
- AudioLibCli.exe：`4165BC7C09BDE6A47041983EF418357C8ACBC5CD9C804C932E870CAF31ED5411`

## Seek 淡入淡出复审补修（2026-10-14，0.4.7）

复审补齐短尾缓冲：旧 PCM 不足或为空时，用当前源最近真实立体声样本完成有界衰减，合成帧不推进播放位置；普通静音及源修订变化清除尾样本。Stop 在已排队的淡出尾段排空后暂停 CPAL 流，播放中的 seek 继续保持流运行。问题与修复对应见 [审查修复](Rust_Review_Fixes.md)。

新增 3 项硬件无关回归，覆盖 0/1/7/31 帧旧缓冲、EOF/网络缺流、源位置计数、静音后不重现旧尾音，以及新源尚无 PCM 时清除旧尾音。补修前 10 项 seek 测试中 8 passed、2 failed，确认缺陷；补修后音频模块 64 passed、0 failed、1 ignored。

格式检查、默认与 ASIO 严格 Clippy、工作区全部目标测试通过：两种配置各 49 个顶层目标、798 passed、0 failed、70 ignored，隔离子进程只累计一次。测试输入为隔离临时文件，207 个源码、配置及资源输入在检查期间 SHA256 一致。日志、源码清单和固定安装的 EXE 身份、portable 验收记录保留于本机忽略目录 `.rust-validation/seek-review/`；非零 PCM 数字包络测试不等同于物理回录或人工听感验收。

使用已校验 ASIO SDK 2.3.4 的 release 构建耗时 6 分 51 秒；`validate-playback-ipc.ps1 -CleanCheckout` 与 `validate-desktop-close.ps1 -Cycles 3` 均通过。后者在独立空库完成 WM_CLOSE/SC_CLOSE 各 3 例，全部正常退出且库可重新打开，本轮未发生退出超时。构建及发布回归前后 207 个输入的 SHA256 一致；保留前轮偶发超时记录，不把本轮通过当作已定位该旧问题的证据。

## Seek 边界 click 修复（2026-10-14，0.4.7）

源码基于 `8b7ebd5` 加本轮本地修复，版本仍为 0.4.7。定位前后对每声道使用 32 个设备输出采样点的线性淡出/淡入，独立于音量平滑；设备在替换源时持续输出静音，避免暂停丢弃已排队的淡出尾段。控制线程等待带源修订号的零帧确认，回调不增加锁、分配、文件 I/O 或解码。暂停时定位保留淡入到下一次 Play；共享源重建路径上的 Stop 也先淡出，再保留静音设备流。

新增 7 项硬件无关回归，覆盖正负 PCM 跳变、完整 32 点端点、跨小块回调、监听声道路由和音量保留、静音后停止消耗旧 PCM、暂停及连续定位、真实控制线程/模拟回调握手、旧源确认隔离、设备失败及回调超时。原有定位位置、传输修订号和播放历史会话回归保留。

Rust 1.97.1 MSVC 格式检查、默认与 ASIO 严格 Clippy、工作区全部目标测试通过；两种配置各 49 个顶层目标、795 passed、0 failed、70 ignored，隔离子进程只累计一次。ASIO SDK 2.3.4 经校验后使用。日志及源码 SHA256 清单保存在本机忽略目录 `.rust-validation/seek-click/`。非零 PCM 断言验证数字输出包络，不等同于物理回录或人工听感验收；本轮不重测百万记录搜索与物理音频启动延迟。

ASIO release 构建耗时 6 分 18 秒，`validate-playback-ipc.ps1 -CleanCheckout` 通过。额外关闭验收首轮的 SC_CLOSE 第 2 例超时：空库未加载音频，最初未记录关闭请求；补发 WM_CLOSE 后排空完成且窗口隐藏，但事件循环未退出。同源重跑 WM_CLOSE/SC_CLOSE 各 3 例全部正常退出。首轮不计作通过；已核验并清理仅该隔离空库测试进程，保留 fixture 和失败日志，不将其计为 graceful shutdown。尚未确认该偶发事件循环退出问题的根因。

## 列宽与排序复审补修（2026-10-13，0.4.7）

源码基于 `f8453be3cbc10469ea657c245f62d06342d093ae` 加表格功能及本轮三项修复；程序版本仍为 0.4.7，schema/API 不变。用户标签采用与源标签一致的 Unicode 排序键，Unicode 纯空白标注回退源标签；空结果保留完整列宽和横向滚动。具体问题见 [审查修复](Rust_Review_Fixes.md)。

格式检查、默认与 ASIO 严格 Clippy、工作区全部目标测试均通过。两种配置各完成 49 个顶层目标、788 passed、0 failed、70 ignored；隔离子进程只累计一次，不将忽略项计作通过。206 个源码、配置及资源输入在检查期间 SHA256 保持一致。

新增标签回归覆盖 `Straße` 与 `strassz`、ASCII/Unicode 边界空白、NULL 和空标注、派生键就绪前后、升降序、FTS5、缺失文件与稳定分页。标注编辑仅允许现有修改时间更新；原始 Metadata 和未知扩展字段完整保留，全部排序查询前后的 Metadata 与标注逐项一致。

空列表回归通过同一 VecModel 的空→有→空→有切换，验证真实滚轮输入、右侧标签表头排序、分隔线拖动及键盘调整、小数列宽、无溢出布局、清除搜索按钮与恢复后的五列对齐。60ms 快速切换也通过；公共 `PointerScrolled` 是即时输入，不将其计作底层 `TouchPhase::Moved` 物理动画时序验证。

ASIO release 使用已验证 Steinberg SDK 2.3.4，构建耗时 5 分 41 秒；206 个输入在检查、构建及发布回归期间 SHA256 一致。`validate-review-fixes.ps1 -CleanCheckout` 和 `validate-desktop-close.ps1 -Cycles 3` 通过，后者完成 WM_CLOSE、SC_CLOSE 各三轮重复关闭，全部自然退出、正常 shutdown 且隔离空库重新打开成功。本机缺少旧数据库及真实 WAV fixture，不将缺失素材的验证计作通过。

完整日志和源码 SHA256 清单保留于本机忽略目录 `.rust-validation/table-review-fixes/`；便携包及固定 `local_release/` 安装的后续验收、EXE 哈希也记录于该目录。本轮未重测百万条性能或物理音频启动延迟；主指标仍为 **P95 latency <500ms for 1M+ records**。

## 声音列表列宽与排序（2026-10-13，0.4.7）

源码基于 `f8453be3cbc10469ea657c245f62d06342d093ae` 加本轮表格功能；程序版本仍为 0.4.7，schema/API 不变。五列支持拖动调整、双击恢复单列、列菜单恢复默认布局及横向滚动。表头切换文件名、时长、采样率、声道与标签的升降序，排序作用于全部搜索结果并回到第一页；修改时间继续通过排序下拉框选择。列宽和排序保存到现有本机偏好，重启及切换音效库后保留。

格式检查、默认与 ASIO 严格 Clippy、工作区全部目标测试均通过。两种配置各完成 49 个顶层目标、786 passed、0 failed、70 ignored；隔离子进程结果仅累计一次，不将忽略项计作通过。新增回归验证真实表头点击、宽文件名列缩窄、分隔线多段拖动及上下限、双击与菜单恢复，以及宽窗口、调整列宽和横向滚动后的五列表头/单元格对齐。

205 条合成 WAV 的隔离控制器回归验证全库升降序、跨页与排序后回到第一页、偏好加载、后台保存及关闭时保存最新布局；配置保存锁被占用时，布局回调仍能返回。分页/FTS5 回归覆盖声道与标签排序、缺失文件、稳定 ID 次序和标注修改；源标签的 Unicode 排序在派生键就绪前后保持一致。标签排序采用用户标签优先、空用户标签回退源标签的规则。

ASIO release 使用已验证 Steinberg SDK 2.3.4，构建耗时 4 分 21 秒；构建输入与完整检查时的 SHA256 清单一致。`validate-review-fixes.ps1 -CleanCheckout` 与 `validate-desktop-close.ps1 -Cycles 3` 通过，后者完成 WM_CLOSE、SC_CLOSE 各三轮重复关闭，全部自然退出、正常 shutdown 且隔离空库重新打开成功。本机缺少旧数据库及真实 WAV fixture，不将缺失素材的验证计作通过。

完整检查、专项回归日志与源码 SHA256 清单保留于本机忽略目录 `.rust-validation/table-controls/`；便携包和固定 `local_release/` 安装的后续验证及 EXE 哈希也记录于该目录。本轮未重测百万条性能或物理音频启动延迟；主指标仍为 **P95 latency <500ms for 1M+ records**。

## 推送前复审补修（2026-10-13，0.4.4）

最终代码提交为 `9cbd54d4a1482f919121cab3fe1bbc81a86494b5`，覆盖此前尚未推送的客户端、服务端、关闭与公开包修复。另一个进行中的服务器目录功能保留在原工作区，本轮使用独立工作目录；版本、schema 与 API 不变。三项新增功能修复见 [审查修复](Rust_Review_Fixes.md)。

格式检查、默认与 ASIO 严格 Clippy 均通过。两种配置各完成 49 个顶层目标、722 passed、0 failed、59 ignored，隔离子进程结果只累计一次。新回归覆盖已确认服务器换库后的旧 Metadata 草稿恢复、目标打开失败及恢复文件写入失败后的重试、切回 Local、关闭后重新启动发现恢复文件，以及普通网络保存失败仍阻止切库和退出。恢复记录保留原库身份和源路径，不导出凭据、不自动重放到替换库；新增 Git 忽略规则覆盖仓库内自定义数据目录的恢复文件。

管理页回归验证 snapshot 交接后的可见页面重新加载和扫描轮询，保留表单草稿及新请求的 busy 所有权；同一端点的默认端口、尾斜线及 `/api/v1` 地址别名仍按普通保存处理。试听流回归使用未完成的受控服务器/WebDAV 响应，验证失败的声道切换恢复原注册、成功替换后解除旧注册、Stop 后新注册，以及共享 buffer 真正复用时不取消新流。测试没有跳过原有 ID、请求计数、provider 身份、草稿与持久化断言。

两项额外 Windows native 关闭测试各 1 passed。最终 ASIO release 使用已验证 Steinberg SDK 2.3.4，构建耗时 4 分 23 秒；197 个非文档源码、配置与资源输入在完整检查、构建及发布回归期间 SHA256 不变。`validate-review-fixes.ps1 -CleanCheckout`、`validate-library-management.ps1`、`validate-playback-ipc.ps1 -CleanCheckout`、`validate-desktop-close.ps1 -Cycles 10` 和 `test-package-boundary.ps1` 全部通过。缺失的旧数据库与真实 WAV 验证没有计入通过。

最终 release 完成 20 次原生关闭：WM_CLOSE 与 SC_CLOSE 各十次、每次连续两条请求。所有进程自然退出、窗口消失、正常 shutdown 及隔离空库重新打开均通过；本机消息投递到自然退出为 98.68–113.67ms，不代表大型缓存或实际写入的等待时间。播放回归使用 owned 静音合成素材，不代表物理音频延迟。六项已有数据库、sidecar 与偏好输入在回归后 SHA256 不变，正常数据目录环境保持。

源输入、完整日志和后续便携包、固定 `local_release/` 安装的 EXE 哈希与隔离验证记录保留于本机忽略目录 `.rust-validation/push-cr/`。本轮不发布新 GitHub Release，不改写已公开的 Git 历史或删除旧附件。现场 Saving changes 停滞仍未稳定复现；UI-001 完整前台失焦/聚焦验收仍受既有报告记录的 Windows 捕获和前台焦点限制影响。本轮未测生产服务端写入/全量同步、Linux 实机、百万条性能或物理音频启动延迟；主指标仍为 **P95 latency <500ms for 1M+ records**。

## 退出保存卡住补修（2026-10-13，0.4.4）

源码基于 `1c2aaeab948269bbf32597c2ae4b79596c05dc2a` 加本轮修复；版本仍为尚未发布的 0.4.4，schema/API 不变。关闭结果邮箱、UI 关闭期间的 timer、远程 worker 的一次性 busy guard 和保存失败恢复见 [审查修复](Rust_Review_Fixes.md)。

格式、默认与 ASIO 严格 Clippy 全部通过。两种配置各完成 49 个顶层目标、715 passed、0 failed、53 ignored，隔离子进程仅累计一次。故障注入拒绝全部跨线程 UI 通知，实际无效端点同步仍释放 busy；草稿保存、扫描排空及 UI 响应通过。真实管理锁使首次保存失败，窗口、草稿及同步指示恢复后能重复关闭并成功保存，源 WAV 字节不变。

额外选择执行两项真实 Windows native 测试，各 1 passed：完整启动事件循环到主事件循环的空库关闭，以及未保存备注的重复关闭、持久化和最终隐藏。新同步语义将 worker 排空与 UI/provider 交接分开；旧缓存回退测试最初仅等待后台 busy，在 UI 回调之前提前断言。补上管理页完成条件后，完整默认/ASIO 重跑通过，旧状态、provider、active cache 与快照字节断言均保留。

最终 ASIO release 使用已验证 Steinberg SDK 2.3.4，构建耗时 4 分 22 秒。195 个非文档源码、配置和资源输入在最终检查、构建和新二进制回归期间 SHA256 不变。`validate-review-fixes.ps1 -CleanCheckout`、`validate-library-management.ps1`、`validate-playback-ipc.ps1 -CleanCheckout` 和公开包边界回归通过；缺失的旧数据库及 WAV 验证没有计入通过。播放仍用 owned 静音合成素材，不代表物理音频延迟。

`validate-desktop-close.ps1 -Cycles 10` 对最终 release 完成 20 次原生关闭：WM_CLOSE 与 SC_CLOSE 各十次、每次连续两条请求。每次自然退出、窗口消失、正常 shutdown 日志及空库重新打开均通过；本机消息投递到自然退出实测 90.77–105.04ms。此测量针对隔离空库，不代表大型缓存或实际写入时的等待时间。

日常安装目录继续为 `local_release/`，只覆盖经便携验证的包内文件，保留原有运行数据。六项已有数据库、sidecar 和偏好输入在新二进制回归后 SHA256 不变，正常数据目录环境保持。源输入、完整测试和回归日志、便携包与固定安装的验证及 EXE 哈希记录保留于本机忽略目录 `.rust-validation/fix-all-v0.4.4/`，不随 Git 或 ZIP 分发。

现场 Saving changes 停滞尚未稳定复现，本轮证明并修复通知失败导致的等待路径，不宣称已确认现场同根因。UI-001 的完整前台失焦/聚焦验收仍未完成：input desktop 可读取，但测试窗口没有取得前台焦点，computer-use 捕获返回桌面合成禁用（0x80263001）；未修改 Windows 设置。此限制不影响以上原生关闭事件回归。

## 客户端、服务端与隐私审查修复（2026-10-13，0.4.4）

源码基于 `6f30d713aadc1927f37bab013a2935fc4e0258c0` 加本轮修复；逐项变化见 [审查修复](Rust_Review_Fixes.md)。194 个非文档源码、配置和资源输入在最终检查与构建期间 SHA256 保持一致。程序版本 0.4.4，API v1、schema 5、snapshot 3..=5 不变。

格式检查、默认与 ASIO 严格 Clippy 全部通过。两种配置各完成 49 个顶层目标、714 passed、0 failed、51 ignored；隔离子进程结果仅累计一次。回归覆盖库身份绑定和旧服务端能力拒绝、全部九项服务器库写入保护、根目录编辑/扫描预约与 panic 清理、Waveform 身份、同步 header/body 取消、声道表示替换及延迟 Stop、管理请求 busy token，以及原生重绘的完整损伤。忽略项包含按条件执行的 native/live-server/真实素材及可选 benchmark，不将其算作通过。

本轮正式 ASIO release 使用已验证 Steinberg SDK 2.3.4，首次完整构建耗时 3 分 58 秒。Rust 编译路径重映射；SoundTouch 使用原生 NDEBUG Release 配置，避免 C++ 调试断言中的宽字符编译机路径进入 EXE。最初构建被公开包路径检查拒绝，补修后重新构建并执行新二进制回归，不沿用先前二进制。最后复查将测试响应中的生产路径、精确扫描数量和时间改成合成 fixture，保留目录前缀、计数、布局及协议断言；随后重新通过上述完整默认/ASIO 检查，并从最终源码再次构建、验证和安装。

`validate-review-fixes.ps1 -CleanCheckout`、`validate-library-management.ps1` 与 `validate-playback-ipc.ps1 -CleanCheckout` 均通过。前者保留 2000 条并发扫描、Metadata、路径和初始偏好验证，明确排除缺失的真实旧库检查；后者使用 owned、已索引的 105 秒 192 kHz float stereo 静音 WAV，保留传输、暂停/seek、Pitch/Rate、重复、播放 session、实例排他及关闭持久化检查。样本 161,280,044 bytes，实际设备输出 96 kHz / 960 frames，最终回归工作集增量 1,085,440 bytes；这是一次 Windows 测量，不代表物理音频启动延迟，也不代表真实旧素材验收。

UI-001 的复用软件 buffer 回归通过，验证完整帧、草稿和选择恢复且空闲不重复绘制。新 release 的 native 自有窗口 DC 抓帧在 192 DPI、1094×630 client 下完成九次恢复操作，像素保持；不使用 PrintWindow 或主动渲染来掩盖问题。当次 Windows 会话锁定，input desktop 不可访问，实际前台失焦/暴露转换尚未验收，报告明确 `foreground_exposure_verified=false`。解锁后需补充 [UI-001](Rust_Known_Issues.md) 的前台验收。

公开资料移除实际生产库身份、路径、规模和私人截图；正式性能条件、合成规模和测量时间保留。portable 使用明确清单和全新暂存目录，隐私检查覆盖隐藏文件、本机 UTF-8/UTF-16 路径、报告允许字段及 EXE 哈希；真实打包发现 SMB 将点前缀目录标为隐藏后，补上 Force 查询并增加回归。包边界回归验证历史残留、忽略报告与未跟踪资源不混入新包，拒绝私有路径、额外报告字段、错误 EXE 哈希及 junction。

最终二进制的公开包隐私检查及 `validate-portable.ps1 -BinaryDirectory dist/latest/portable -CleanCheckout` 通过，覆盖 EXE 身份、隔离首启、合成 WAV、中文 GUI、CLI、启动诊断和许可证。测试和新二进制回归后，六项已有数据库、sidecar 与偏好输入 SHA256 不变，正常数据目录环境保持。固定安装路径继续使用 `local_release/`，安装只覆盖包内文件，并按 AGENTS.md 对两 EXE 哈希和隔离首启再次验证。源输入、完整日志、截图、包与安装验收记录保留于本机忽略目录 `.rust-validation/fix-all-v0.4.4/`，不随 Git 或 ZIP 分发。

本轮未执行生产服务端写入/全量同步、Linux 实机、百万条性能 benchmark 或物理音频延迟测量。远程写入需要客户端与服务端一起升级。普通提交和新包不移除已公开的旧 Git 对象与 Release 私人信息副本；本轮不改写远端历史或删除旧附件。主指标仍为 **P95 latency <500ms for 1M+ records**。

## 发布前 CI 回归修正（2026-10-12，0.4.3）

0.4.2 发布准备中的 Windows CI 两次在 `unchanged_sources_resume_cancelled_reads_without_replaying_completed_auditions` 超时。本机完整默认/ASIO 测试和额外十次重复均通过，但测试把共享状态栏的 `Ready` 文本当作搜索完成条件；无输出设备时，播放错误会持续覆盖这段文字。

新增隔离子进程，指定不存在的输出设备，先等待对应错误实际显示；旧判断稳定触发同一 12 秒超时。修正为检查当前搜索 generation、成功页面和已发布的目录模型后，包含正常配置与无输出设备两种场景的父测试通过。原有选择、Waveform、provider 身份、Metadata 写入计数及禁止重复 Load/Play 的断言均保留，不通过跳过测试或延长超时消除失败。

该修正仅调整测试同步与版本/发布文档；最终源码的完整验证、构建来源和两 EXE 哈希由发布附件 `Rust_CI_Release.json` 记录。原始迁移 fixture 缺失的限制仍适用，便携包使用隔离合成数据验收。

## 缓存流程合并与可见进度（2026-10-12，0.4.1）

源码基于 `fcb1f65` 加本轮工作区修改。服务器模式 GUI 先打开管理页，由同一个同步流程选择、加载或下载缓存；已准备好的同版本快照不重复复制、下载或重建索引。复制进度按 SQLite 页数计算，下载按字节数计算，校验与索引升级显示阶段、动态进度条和耗时。管理页同步/切换期间保留输入保护，但不再被泛化的“等待扫描结束”提示遮挡。

格式检查、默认与 ASIO 严格 Clippy 均通过。推送前补修后的两种配置 workspace/all-targets/locked 测试各为 49 个顶层目标、697 passed、0 failed、48 ignored，嵌套子进程结果只累计一次。回归覆盖启动延后加载、匹配端点的离线缓存、旧缓存原始字节与既有 reader 保留、实际复制进度、同版本复用，以及关闭窗口等待缓存 worker 安全结束。[本轮 CR](Rust_Review_Fixes.md) 补修新快照拒绝时旧缓存不可用、打开 provider 时进度提前结束两项 P2；新增回归先确认失败，再验证补修通过。

额外执行真实 Windows 原生窗口测试：1 passed。保存并核对六张中英文阶段/管理页截图，管理页在切换写入保护期间仍完整显示进度；此处使用隔离测试数据和受控阶段，不代表生产服务器下载实测。截图测试改为等待 worker 状态发布后捕获，避免原生窗口创建较慢时抢在进度更新前断言。用户报告的重新聚焦后局部黑屏另登记为 [UI-001](Rust_Known_Issues.md)，按要求后续处理，本轮不宣称已修复。

当前检出缺少 `data/audiolib.db` 和旧 WAV fixture；`validate-review-fixes.ps1` 在读取原库哈希的前置步骤退出，未执行其回归项，`validate-runtime.ps1` 的旧素材验证也未运行。便携验证使用 `-CleanCheckout` 的隔离合成数据，不代替真实旧库迁移验收。本轮未测生产服务器完整同步、百万条性能或物理音频延迟。

映射 SMB 盘的编译 metadata 覆盖遇到 `ERROR_ACCESS_DENIED`，因此构建输出使用本机 NTFS 的独立 `CARGO_TARGET_DIR`；发布脚本仍使用已验证 Steinberg ASIO SDK 2.3.4。打包前将本次生成的两 EXE 复制到常规 release 输出并逐一核对 SHA256。测试日志、155 项源码输入哈希、截图及后续打包/安装验收记录保存在忽略目录 `.rust-validation/cache-progress/`。

## 推送前 CR 与发布回归（2026-10-11，0.4.0）

对 `origin/main` 到本地已合并 `main` 的待推送内容独立审查，补修五项 P2，详见 [审查修复](Rust_Review_Fixes.md)。源码为 `1e69af2812113ed718960bc878f3de4d015e4448` 加本轮审查修复，183 个构建输入在检查、构建与发布回归期间保持一致。

格式检查、默认及 ASIO 严格 Clippy 均通过。两种配置的 workspace/all-targets/locked 测试分别为 49 个顶层目标、694 passed、0 failed、44 ignored；嵌套子进程结果只累计一次。新增回归覆盖旧缺失值重扫、转义 JSON 标签、派生回填 revision/进度及完整 signed i64 ID 范围、跨服务器 roots 缓存隔离和 CLI 惰性空库提示。正式 ASIO release 使用已验证 Steinberg SDK 2.3.4，构建耗时 290.881 秒，版本保持 0.4.0。

runtime、review-fixes、library-management、access-denial、playback-ipc 五套新二进制发布回归全部通过。34 条 WAV 导入/重扫保留 Metadata，2000 条并发扫描 fixture 正确排他；实际 Windows ACL 拒绝期间保留 2 条记录，恢复权限后正确保留 1 条；静音真实播放确认传输、播放 session 和关闭持久化。原迁移库和源 WAV 未修改。首次误用 PowerShell 5.1 的调用在解析阶段退出，改用 PowerShell 7 后完成验证，未修改脚本。

便携包及固定 `local_release/` 的 EXE 身份、隔离首启、中文 GUI、CLI、启动诊断与许可证验证全部通过。1234 个包内文件覆盖到既有安装目录，两 EXE SHA256 与本次 ASIO release 一致；六个已有设置、工作库/sidecar 和旧迁移输入在安装及隔离验证后 SHA256 不变，正常数据目录环境恢复。没有留下验收 GUI 实例。源码身份、完整测试计数、发布回归、包及安装哈希见仓库附件 推送前验证数据，未发布远程 Release。

本轮未重新测量百万条性能 benchmark、生产服务器完整 snapshot 同步或物理音频启动延迟。主指标仍为 **P95 latency <500ms for 1M+ records**，下列历史测量保留各自的源码版本与实测条件。

## 最新远程分支合并复测（2026-10-11，0.4.0）

`main` 合并 `feature/remote-mode` 的 `acf5d4a80282fb32e0c3ab2d229298fb30e9dd32`，合并提交为 `4aef720a157318759cf558191954fb8374e0663f`。此前客户端请求排序、服务器身份校验及可见启动修复由 `295b8ca9efcc1d9b80771fc4a8520e110a1f35d9` 保留。库 schema 更新为 v5，服务器 snapshot 接受 v3–v5；完整的原始只读 snapshot 保持原样，需要修复派生搜索状态时只升级 owned staging/copy。评分产品接口随最新分支移除，原 SQLite `user_rating` 和既有 Metadata 保留。

格式检查、默认与 ASIO 严格 Clippy 均通过。两种配置分别完成全部 workspace/all-targets 测试：49 个顶层目标、686 passed、0 failed、44 ignored，嵌套子进程汇总只累计一次。真实 Windows 准备窗口测试及关闭排空测试分别 1 passed。新增合并回归覆盖 v3/v4/v5 原库字节、ID 高水位、旧评分数据、关键词及只读 staging 修复；非法 snapshot 版本在下载或写缓存前拒绝。正式 ASIO release 使用已验证 Steinberg SDK 2.3.4，从上述合并提交构建，耗时 329.589 秒。

新 release CLI 对实际服务器的只读连接测试返回 exit 0、success=true，服务端 snapshot 为 schema 4。TLS、授权、库身份、根目录、1 byte stream 与有界 preview 检查均通过；未请求生产 snapshot 同步，也未改变连接配置。生产库身份、记录数和 revision 已从公开报告移除。截图中的 schema 4 超出旧客户端支持上限 3 的错误由此次客户端兼容范围更新覆盖。

runtime、review-fixes、library-management、access-denial 与 playback-ipc 五套发布回归全部通过。真实 Windows ACL 拒绝期间保留 2 条记录，权限恢复后正确保留 1 条。静音播放验证确认暂停/恢复、seek、Stop/Ended 后新 session、转换设置及关闭持久化；不代表物理音频延迟测量。隔离回归后，原有设置、工作数据库及 sidecar、旧迁移数据库和 YAML 共六个文件 SHA256 不变。

默认 ASIO portable 包及固定 `local_release/` 均通过 EXE 身份、隔离首启、中文 GUI、CLI、同步启动诊断和许可证验证。1233 个包内文件复制到既有安装目录，两 EXE SHA256 与本次 release 一致；安装和隔离验证未改变上述六个已有文件，正常数据目录环境已恢复。从 `local_release/Start-AudioLibExplorer.cmd` 正常打开，当前已保存 Local 配置及 Windows 热缓存条件下，340.941 ms 获得可见窗口句柄，401.246 ms 返回 IPC ready；窗口响应正常。由 Codex MSIX 启动时，IPC 报告设置的规范路径位于该应用的 LocalCache；保留既有 active_database 和目录选择，未迁移偏好目录。这些计时不含首次生产服务器大库升级或物理显示延迟。

源码身份、183 个输入 SHA256、默认/ASIO 测试计数、发布回归、真实服务器诊断、包及安装身份记录于 分支合并验证数据。合并保存在本地 `main`，未发布远程 Release。自动审批策略拦截删除旧包文档 `Rust_ASIO_Enumeration.txt`，因此该历史文档保留，不影响 EXE 验证结果。

本轮未重新测量百万条性能 benchmark、首次生产服务器大库升级或物理音频启动延迟。历史性能结果保留其原始版本和条件，主指标仍为 **P95 latency <500ms for 1M+ records**。

## 客户端逻辑与可见启动复测（2026-10-11，0.3.7）

本轮修复七项客户端问题及大型服务器缓存启动前无窗口的问题，逐项说明及正式测试见 [审查修复](Rust_Review_Fixes.md)。源码基于 `06fb246ad7d32c3ff520a775ee12298ccb724d3a` 加本地修复，版本保持 0.3.7；采用已验证 Steinberg ASIO SDK 2.3.4。默认与 ASIO workspace/all-targets 测试均为：43 个顶层目标、633 passed、0 failed、44 ignored，子进程汇总只累计一次。默认与 ASIO 严格 Clippy、格式检查通过。真实 Windows 准备窗口测试和 Metadata 排空关闭测试分别 1 passed；前者验证耗时初始化期间可捕获软件渲染窗口、处理关闭事件、安全完成 worker 并再次运行同一原生事件循环。

旧版实机的大型服务器缓存启动过程约 220 秒后才创建主窗口；这是一次旧派生索引升级观察，生产缓存精确容量已从公开记录移除。新版先显示窗口，后台完成同样的 owned copy 和完整校验，并去掉备份的固定分段等待。该观察不作为日常搜索或新版首次大库升级的计时；本轮未重跑百万条性能 benchmark，主指标仍为 **P95 latency <500ms for 1M+ records**。

runtime、review-fixes、library-management、access-denial、playback-ipc 发布回归与 portable 包/已安装目录验证全部通过。1231 个包内文件覆盖到固定 `local_release/`；两个 EXE SHA256 与最新 ASIO 包一致，安装验证前后六个已有设置/数据库/sidecar 文件的 SHA256 不变，正常数据目录环境恢复。从该目录的 `Start-AudioLibExplorer.cmd` 正常启动，当前已保存配置及 Windows 热缓存条件下，194.436 ms 获得可见窗口句柄，251.563 ms 返回 IPC ready；这不是首次大型服务器缓存升级耗时或物理显示延迟。源码身份、哈希及结果见 客户端修复验证数据。未发布远程 Release。

## 提交前 CR 补修及最终复测（2026-10-11，0.3.7）

独立复审补修五项 P2：不更换 provider 的配置保存恢复已取消的读请求；GUI/IPC Stop 取消待执行和延迟 Play，旧成功/失败不能消费或覆盖新选择的重试标记；单词内标点保留 AND 查询语义；旧库 NULL 或未知缺失值与 Present 查询一致；小 ID 和升级后的 epoch ID 采用完整覆盖的两段位图交集。原八项审查修复及对应正式回归继续保留，详见 [审查修复](Rust_Review_Fixes.md)。

最终冻结源码基于 9889baf 加本地修复；138 个构建输入逐文件 SHA256 记录于 CR 最终验证数据，构建、回归和计时期间均未变化。格式检查与默认/ASIO 严格 Clippy 通过；默认配置 42 个顶层目标、620 passed、0 failed、36 ignored；ASIO 配置 42 个顶层目标、620 passed、0 failed、36 ignored，子进程汇总只累计一次。真实 Windows 关闭及 runtime、review-fixes、library-management、playback-ipc、access-denial 发布回归均通过。构建使用已验证 Steinberg ASIO SDK 2.3.4，版本 0.3.7。

主指标为 **P95 latency <500ms for 1M+ records**。三套隔离合成库各 1,000,000 条（999,999 可用 + 1 缺失），包括 20,001 个实际数据库目录和小 ID/新 epoch ID 混合库；扩容目录库保留旧 ANALYZE。每种库的三类首轮请求各 10 个新进程，共 90 次，测量正常启动后首次 metal 搜索到结果页与实际目录模型完成发布。全部首轮低于 500ms，最大 425.696 ms。

| 合成库 | 无筛选 P95 ms | 48kHz P95 ms | 评分≥4 P95 ms |
| --- | ---: | ---: | ---: |
| 连续 ID，1 目录 | 387.625 | 419.812 | 391.109 |
| 连续 ID，20,001 目录 | 405.600 | 425.696 | 401.116 |
| 旧小 ID + 新 epoch ID，1 目录 | 389.925 | 421.805 | 387.970 |

混合 ID 的修复前 48kHz 首轮有 4/10 次超过 500ms，最高 656.350ms；完整失败样本也保留在 JSON。修复后的两段位图不改变精确 BM25 排序、SQL 筛选及分页，容量含 word 取整不超过 1MiB，密度或覆盖条件不满足时保留 HashSet，两个发现阶段均可取消。

| 原生 DataProvider 复测 | 1 目录 | 20,001 目录 |
| --- | ---: | ---: |
| 新 provider 首次搜索 P95 ms（15 类各一次） | 400.016 | 410.628 |
| 新 provider 首次目录统计 P95 ms | 175.668 | 246.117 |
| 串行搜索 + 目录统计 P95 ms（单独指标） | 568.149 | 649.520 |
| 搜索 + 目录统计重复阶段 P95 ms（150 请求） | 286.727 | 340.850 |

标准 100 请求及边缘 150 请求的重复阶段 P95 分别为 86.293ms、154.118ms。Metadata 与计数 oracle 在全部 GUI 计时后运行，所有首轮结果和目录模型均校验正确。AMD Ryzen 7 9800X3D、约 93.5GiB 可见内存、Predator GM7 4TB NVMe，Rust 1.97.1 MSVC、bundled SQLite 3.53.2。OS 缓存未清除，计时无并行编译；SQLite 每 reader 64MiB cache、1GiB mmap，保留池上限四个，排名 ID payload 上限 32MiB，均不代表整个进程内存。

GUI 使用 Slint testing backend，立即 Enter/搜索提交不计既有 160ms 输入防抖；不包含库初始化、原生渲染、物理显示或指针延迟。新 provider 的打开耗时单列，首次查询没有提前复用同 provider 排名缓存。串行搜索加统计的总耗时与 GUI 两个固定 worker 并行发布分别报告，不能互相替代；本次不声称生产服务器、网络或物理音频输出验收。便携包及固定 local_release 的 EXE 身份、隔离启动和运行时数据保护另按 AGENTS.md 的安装验证流程执行。

## 首次 GUI 搜索与目录统计优化（2026-10-11，0.3.7）

本轮保留精确 BM25 排序、当前事务 Metadata 与目录计数，首次关键词结果页和目录模型由两个固定工作线程并行计算，各只保留一个最新请求。共享取消标志、provider 身份及 generation 防止旧请求发布；目录先完成时等结果页成功，实际目录模型发布后才显示 Ready。facet cache 使用弱 provider 身份与数据库 revision 防止跨库命中。只读连接由独占 ReadLease 或 observer mutex 保护，采用 rusqlite 默认的 NO_MUTEX 模式；rank 映射逐请求固定为默认 bm25()。稀疏缺失文件在同一事务内扣除，避免范围筛选失去覆盖索引；129 条及以上保留原 SQL 路径。稠密 ranking ID 范围的筛选交集使用最多 1MiB 的临时 bitmap，稀疏或极端 i64 域保留有界 HashSet；SQL 行预算和取消检查独立于表示。

扩容后的旧 SQLite ANALYZE 统计会导致目录闭包 JOIN 或 EXISTS 平方级扫描。现在使用 direct→descendant index 查找、物化汇总及主键 scalar hydration；缺目录 ancestor 保持跳过。确定性回归验证 256→2048 目录的 VM 工作预算、精确祖先计数/排序及中途取消后的连接恢复。基础目录索引缺失时，只读原库通过 owned copy 修复；远程 owned cache 在打开前修复，原文件字节保留。

主指标为 **P95 latency <500ms for 1M+ records**。两种只读隔离合成库均为 1,000,000 条（999,999 可用 + 1 缺失），分别含 1 和 20,001 个实际数据库目录，后一种保留原 1 目录的旧统计。AMD Ryzen 7 9800X3D、约 93.5 GiB 可见内存、Predator GM7 4 TB NVMe，Rust 1.97.1 MSVC、bundled SQLite 3.53.2；OS 页缓存未清除，计时无并行编译。

| 首轮验证 | 1 个目录 | 20,001 个目录 |
| --- | ---: | ---: |
| GUI 首次关键词 + 实际目录模型发布 P95 ms（各 10 个新进程） | 389.179 | 418.199 |
| GUI 首轮最大 ms | 389.179 | 418.199 |
| GUI 首次关键词 + 48kHz 筛选 P95 ms（各 10 个新进程） | 418.926 | 423.401 |
| GUI 首次关键词 + 评分≥4 筛选 P95 ms（各 10 个新进程） | 420.225 | 413.303 |
| 新 provider 首次搜索 P95 ms（15 类各一次） | 443.859 | 411.363 |
| 新 provider 首次目录统计 P95 ms | 179.615 | 256.255 |
| 串行 DataProvider 搜索 + 目录统计 P95 ms（另报） | 611.090 | 659.486 |
| 搜索 + 目录统计重复阶段 P95 ms（150 请求） | 320.882 | 380.617 |

GUI 60 次首轮全部小于 500ms，涵盖两套库的无筛选、48kHz 和评分≥4 三类首次请求。测量的是正常启动后第一个 metal 关键词通过 Enter/搜索按钮立即提交到实际模型发布，oracle 在全部计时后使用另一 provider；测试后续还验证取消宽查询、过期结果抑制及目录展开。Slint testing backend 不包含原生渲染、物理显示/指针延迟，立即提交也不计输入框既有的 160ms 自动搜索防抖。新 provider 未提前执行同查询，但打开库与 GUI 启动耗时单独报告；串行调用的合计不是 GUI 并行延迟，不能互相替代或当作物理冷盘结果。

格式检查、默认/ASIO 严格 Clippy 和全部 workspace/all-targets 测试通过：各 41 个顶层目标、597 passed、0 failed、28 ignored。真实 Windows 关闭及 runtime、review-fixes、library-management、playback-ipc、access-denial 发布回归通过。最新默认含已验证 ASIO SDK 2.3.4 的 build-release 构建基于 9889baf 加本地未提交修复，版本 0.3.7；完整逐请求样本、源码 SHA256、构建与验证身份见 首次搜索性能记录。便携包与固定 local_release 安装由 portable validator 独立验证。

## 数据库、关键词与 GUI 八项审查修复（2026-10-11，0.3.7）

八项问题全部修复，P1 包括旧连接 Metadata 排空前发布新服务器配置、删除后重复分配音频 ID，以及保存失败仍替换服务器 snapshot 丢失编辑草稿。P2 包括 Unicode 关键词拆分、Remote Ready 的 Waveform 身份与原始格式、连续选择堆积线程、关联表外键索引及大范围 FTS5 排序性能。实现及逐项回归映射见 [审查修复](Rust_Review_Fixes.md)。同 schema v3 的 additive feature 修订支持原库与只读 owned snapshot 升级；未来已知修订拒绝降级。

最终源码基于 `9889baf` 加本地未提交修复，版本 0.3.7。格式检查、默认与已校验 Steinberg ASIO SDK 2.3.4 的严格 Clippy、workspace/all-targets 测试全部通过：每种配置各 **39 个顶层目标、579 passed、0 failed、26 ignored**，子进程汇总只累计一次。显式真实 Windows 关闭测试另有 1 passed。新增 benchmark 回归确认已有库的总记录数包括缺失行，且缺失标记、注释和源数据库字节不变。

最新 ASIO release 构建及其运行时 8 项、审查回归 10 项、资料库管理 10 项、播放 IPC 16 项和真实 Windows ACL 回归均通过。原始库及 WAV 保留；播放回归使用静音或零增益，未测量物理音频输出延迟。便携包与固定安装的独立验收由 `tools/validate-portable.ps1` 记录。

主指标为 **P95 latency <500ms for 1M+ records**。本轮使用新建隔离合成库：1,000,000 条（999,999 可用 + 1 缺失），数据库含 1 个目录，200 行结果页；AMD Ryzen 7 9800X3D、约 93.5 GiB 操作系统可见内存、Predator GM7 4 TB NVMe，Rust 1.97.1 MSVC。真实 DataProvider 串行调用，reader 上限 4、每 reader SQLite cache 64 MiB、mmap 1 GiB，OS 缓存已暖且未受控；最终计时没有并行编译。

| 复测 | 重复请求数 | P50 ms | P95 ms | P99 ms | 首轮 P95 ms | 重复阶段排名缓存命中 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| 标准搜索（10 类） | 100 | 1.920 | 111.143 | 118.069 | 462.897 | 80 |
| 含边缘查询（15 类） | 150 | 5.150 | 165.211 | 171.935 | 447.238 | 120 |
| 边缘查询 + 目录统计（15 类） | 150 | 77.450 | 310.184 | 333.294 | 595.342 | 120 |

边缘查询覆盖同词目录范围、采样率筛选、offset 200,000、缺失可见性及文件名排序。重复阶段在每类请求执行一遍后开始，复用有界 exact BM25 排名 ID；Metadata、筛选与总数仍从当前固定读 snapshot 获取。首轮各类请求按顺序执行，后面的同词变体可能命中已建立的排名缓存；JSON 保留每类首次耗时与命中标志，不能将首轮称为完全冷启动。以上三个重复阶段 P95 达标，首次建立缓存或同时计算目录统计仍可能超过 500ms；不代表任意冷请求或生产服务器验收。

Slint testing backend 的真实 Controller 复测：单次首次 `metal` 发布 615.791ms，取消宽查询后替换请求 6.663ms；20,001 个合成目录展示模型的展开/折叠共 20 次，P95 30.767ms。它测量请求到事件循环发布，不包含原生渲染、物理显示或指针延迟，也不声称数据库中存在 20,001 个目录。

完整请求、每类样本、硬件、源码输入 SHA256、测试及发布构建身份见 本轮性能记录。原始日志和临时库位于本机 `.rust-validation/review-fixes-20261011/`；工作资料库、设置及 SQLite sidecar 保留原位置。

## 分段 Waveform 与退出流程 CR（2026-10-10，0.3.7）

最终源码通过 `cargo fmt --all -- --check`，默认和已校验 Steinberg ASIO SDK 2.3.4 配置的严格 Clippy 与 workspace/all-targets 测试；每种配置各 33 个测试目标合计 541 passed、0 failed、20 ignored，不重复累计子进程输出。真实 Windows 关闭测试另行显式执行：1 passed，覆盖连续关闭、未保存 Metadata 落盘、窗口隐藏与源 WAV 保留。

新增回归覆盖错位服务器响应、损坏缓存的无条件重新请求、同一 revision 重试恢复、缺失素材拒绝排队及延迟 Waveform、混合采样率与不足一预览帧的尾段。关闭线程最终唤醒使用谓词锁；平台事件循环错误仍经过清理路径，但未注入平台错误。日志保存在本机 `.rust-validation/cr-fix/`；使用隔离临时库，未使用用户工作库作为测试库。

ASIO 发布构建及 `validate-runtime.ps1`、`validate-review-fixes.ps1`、`validate-library-management.ps1`、`validate-playback-ipc.ps1` 均通过。原始库及源 WAV 保留；播放回归使用静音合成音频及零增益实际素材，未测量物理输出延迟。

## 退出窗口收尾（2026-10-10，0.3.7 本地修复）

关闭请求仍先排空 Metadata 和扫描，成功后显式隐藏窗口并退出消息循环，异常恢复编辑界面并记录日志。默认配置格式检查、严格 Clippy 及 workspace/all-targets 测试通过：33 个测试目标合计 537 passed、0 failed、18 ignored（不重复累计子进程结果）。其中真实 Windows 关闭回归另行单独执行通过，覆盖连续两次原生关闭请求、窗口隐藏和事件循环结束；扫描收尾回归同时确认草稿落盘、等待期间 GUI 响应及 WAV 未改动。

测试与发布检查记录使用 `.rust-validation/close-*`；仅使用隔离临时库，保留工作库、设置及已有 Waveform 改动。

## 大库搜索性能复审（2026-10-10，0.3.7）

在搜索优化实现上修复目录缓存未检测外部写入、库统计完成乱序、非法输入未取消旧请求，以及短查询在取消后仍可能返回成功的问题。外部修改收藏的 GUI 回归在修复前稳定超时，修复后通过；新增数据库版本观察回归覆盖自身/外部提交、只读快照、索引维护和恢复。详细边界见 [GUI 搜索性能](Rust_GUI_Search_Performance.md)。

默认及已校验 ASIO SDK 2.3.4 的严格 Clippy、workspace/all-targets 测试通过，各 532 passed、0 failed、17 ignored（不重复累计子进程结果）；测试库均位于隔离临时目录。日志位于 `.rust-validation/gui-review/`。真实服务器搜索验收待用户配置服务器后执行，既有合成性能数字不是生产库测试结果。

同步远端 `main` 至 `c57a4e6` 后，最终合并源码（含 reader 获取后的取消检查）再次通过格式、默认/ASIO 严格 Clippy 与完整 workspace/all-targets 测试，各 532 passed、0 failed、17 ignored。4 项取消/版本定向回归通过。最新源码 ASIO release 构建通过，运行时 8 项、审查回归 10 项、音效库管理 10 项发布检查通过，原始数据库与源 WAV 保持不变。最终检查日志与源码身份位于 `.rust-validation/cr-push/`；两种配置的 33 个 Cargo 测试目标仅累计各自最终汇总。

## 左侧文件夹滚动条（2026-10-10，0.3.7 本地修复）

本轮基于 `d0c6c5d` 加 GUI 与回归测试改动。Fluent 的 14px 覆盖式滚动条预留 18px 间距，数量按自然宽度展示；深层目录缩进受限，保留名称至少 40px 展示空间。回归覆盖中英文、170/198/400px 侧栏、溢出与不溢出列表、5/7 位数量、深度 30，以及悬停、点击和滚轮。原布局因数量与滚动条之间间距为零而失败，修复后通过。

隔离源码的格式检查、默认/已校验 ASIO SDK 2.3.4 的 workspace/all-targets 严格 Clippy 与完整测试通过：各 520 passed、0 failed、16 ignored（排除 administration_isolation 子进程重复汇总）。日志位于 `.rust-validation/folder-scrollbar/`，数据库测试使用隔离临时目录。

同一隔离源码的 ASIO release 构建通过。24 个独立扫描根目录与合成静音 WAV 的中英文紧凑窗口截图已目视检查，数量与滚动条保持间距，无 binding loop 或崩溃，合成源 WAV 哈希不变。构建 EXE 已即时保全为打包和安装验收的 SHA256 基线，未使用并行任务的构建输出。

固定 `local_release/` 最终保留并行完成的搜索优化包，其中包含相同 GUI 修复；默认/ASIO workspace 顶层测试各 522 passed、0 failed、17 ignored，均含本轮滚动条回归。该包已有成功的打包及安装 7 项验收记录，全部 1228 个包文件与安装逐文件 SHA256 一致。本轮另以其实际安装 EXE 重测中英文紧凑窗口，数量与滚动条保持间距，无 binding loop 或崩溃，隔离源 WAV 哈希不变。安装身份及既有验收证据保存在 `.rust-validation/folder-scrollbar/completed.json`；工作资料库与设置保持原位置。共享 Cargo 输出随后被独立构建更新，不作为该安装包的新验证基线。

## v0.3.7 发布预检（2026-10-09）

workspace、lockfile 和 Windows manifest 已同步至 0.3.7。格式检查、普通及已校验 ASIO SDK 2.3.4 配置的 workspace/all-targets 严格 Clippy 与完整测试通过：两种配置各 520 passed、0 failed、16 ignored。第三方依赖版本保持不变。日志位于 `.rust-validation/release-v0.3.7/`，测试资料库均使用隔离临时目录。

最新源码的 ASIO release 构建通过，运行时 8 项、配置/Metadata 审查 10 项、音效库管理 10 项发布回归通过；原始数据库与源 WAV 保持不变。

发布 CI 按 `v0.3.7` 标签的确切提交重新检查、构建、验证并生成 `Rust_CI_Release.json`；最终发布包以其 ZIP 校验文件与报告中的两份 EXE SHA256 为身份依据。

## 自适应详情复审（2026-10-09，0.3.6）

格式检查、普通与已校验 ASIO SDK 2.3.4 配置的 workspace/all-targets 严格 Clippy、完整测试均通过：两种配置各 520 passed、0 failed、16 ignored。三项新增详情测试在移除修复时全部失败，恢复修复后通过，验证长标签/描述切换声音后的内层滚动和选区重置，以及 Ctrl+End、Ctrl+Home 与键盘选择保持可见；包含相同标签文本、中英文和 1080×700/1440×900。只读内容与标注草稿保持不变。四项分隔条输入复核覆盖方向键、宽度限制、模态禁用、拖动取消及非左键，无新增侧栏缺陷。

本轮仍基于 `15afa7b` 加工作区改动，版本为 0.3.6。复现、格式、Clippy 与全量测试日志保存在 `.rust-validation/responsive-review/`；首次恢复复现源码时保留了旧时间戳，Cargo 复用了旧 UI 生成物，刷新输入文件时间戳后重新运行上述完整检查并通过。所有数据库测试使用独立临时目录。

最新源码的 ASIO release 构建通过，运行时 8 项、配置/Metadata 审查 10 项发布回归通过，原始数据库保持不变。独立临时库和合成静音 WAV 的中英文宽/窄窗口四张实际 Windows 后端截图已检查，描述与提取标签可见，无 binding loop 或崩溃。便携包与 `local_release/` 的 EXE 身份、隔离首次启动及正常启动诊断由 `tools/validate-portable.ps1` 分别验收。

## 自适应侧栏与详情展示（2026-10-09，0.3.6）

格式检查、普通及已校验 ASIO SDK 2.3.4 配置的 workspace/all-targets 严格 Clippy 与完整测试均通过：各 513 passed、0 failed、16 ignored。新增 5 项中英文 UI 回归验证两侧分隔条连续拖动、宽度上下限及列表 520px 保留空间、缩小再放大窗口、隐藏再显示详情、列表标签列与筛选布局，以及原始 Metadata 默认折叠、展开、收起和切换声音后重置。1080×700 与 1440×900 的描述及提取标签均在默认详情视口内可见；只读字段输入不改变内容或标注草稿。

两项 core 回归验证规范化关键词/分类提取、去空值及大小写重复、保留原文与顺序、拒绝无关或畸形字段，以及不改变原始 Metadata 或用户标签。检查日志及源码身份位于 `.rust-validation/responsive-details/`。本次构建基于 `15afa7b` 加当前工作区改动，程序版本为 0.3.6；所有数据库检查使用隔离临时目录。

最新源码的 ASIO release 构建通过，运行时 8 项和配置/Metadata 审查 10 项发布回归通过，原始数据库不变。使用独立临时库和包含描述、关键词、分类的合成静音 WAV，生成中英文宽窗口及紧凑窗口四张实际 Windows 后端截图并目视检查，未出现 binding loop 或崩溃。紧凑标签区域改为可选择、可滚动的只读文本，减少标准 TextEdit 内边距造成的长标签裁切；便携包和固定安装目录的 EXE 身份及启动验证由 `tools/validate-portable.ps1` 单独记录。

## 数据源配置输入与保存（2026-10-09，0.3.6）

Windows 实际窗口确认模态焦点定时器反复把输入焦点拉回“关闭”按钮。新增实际 Windows 后端回归将点击和键盘输入分隔 100ms：原定时器下名称为空并失败，修复后名称正确并通过。实际窗口已验证文字选择及中文粘贴；保存与重载通过隔离配置验收，保留原有地址校验及异步保存流程。

格式检查、普通/ASIO 的 workspace/all-targets 严格 Clippy 和完整测试均通过：各 506 passed、0 failed、16 ignored。ASIO 使用已校验的 SDK 2.3.4。实际 Windows 后端回归需单独运行，普通 GUI 回归覆盖中英文、1080×700/1440×900、所有连接字段、滚动、延迟输入、忙碌时禁止编辑、保存回调和背景草稿保护。Controller 回归通过字段输入后异步保存并关闭，重载配置验证既有 WebDAV 设置保留。检查日志保存在 `.rust-validation/source-dialog-input/`，所有测试资料库位于独立临时目录。

```powershell
cargo test --locked -p audiolib-desktop ui_tests::real_windows_connection_editor_accepts_pointer_and_keyboard -- --exact --ignored --nocapture
```

普通与 ASIO 功能下的实际 Windows 后端回归均单独通过。最新源码的 ASIO release 构建成功，配置审查 10 项及音效库管理 10 项发布回归通过，原始数据库及源 WAV 保持不变。构建基于 `15afa7b` 加当前工作区修复，源码身份记录保存在上述验证目录。

## 取消单击播放后的双击回归（2026-10-09，0.3.5）

真实 Controller 回归使用独立临时库、3 秒全零 WAV、音量 0 和 Windows WASAPI 输出：默认关闭时双击首次对象播放，开启后单击播放，再关闭并在两次点击之间写入收藏 Metadata、调用生产搜索刷新后双击播放。修复前刷新约 8ms 后替换行模型，第二击没有试听回调，音频停留 Ready；修复后约 9ms 完成刷新并保留模型，第二击触发试听，实际状态进入 Playing。该测量验证控制流程，不测量模拟输出或声学延迟。

两项默认 GUI 回归覆盖变化的标签/评分不打断双击，以及 ID、顺序、数量或 missing 状态变化时不误播旧目标。实际输出回归需显式运行：

```powershell
cargo test --locked -p audiolib-desktop controller::click_preview_tests::real_pointer_preview_modes_play_after_checkbox_changes -- --exact --ignored --nocapture
```

格式检查、默认与 ASIO 配置的 workspace/all-targets 严格 Clippy 通过；两种配置各通过 503 项测试，另有 14 项按其要求默认忽略。上述真实指针播放回归在默认和 ASIO 功能构建中单独运行并通过，实际输出均使用静音 WASAPI。

## 单击播放偏好 CR（2026-10-09，0.3.5）

修复后台保存设置持有配置锁时，开关回调等待同一把锁造成的 GUI 阻塞。事件循环只更新最新偏好并唤醒单个后台线程；保存与其他设置共用配置锁，关闭时写入最新选择。后续真实 Controller 回归发现列表刷新会丢失原生双击状态，详见 [审查修复](Rust_Review_Fixes.md)。

新增隔离子进程回归覆盖正常运行时两种状态自动落盘、配置锁受阻期间快速切换 5 次及立即退出后最后选择、语言和音量保留。在合成 500ms 锁竞争下，修复前回调等待 501.0402ms 并失败，修复后 14.1µs 返回并通过；此诊断不测量实际保存或音频输出延迟。格式、默认与已校验 SDK 2.3.4 的 ASIO 配置的 workspace/all-targets 严格 Clippy 和完整测试通过。日志位于 `.rust-validation/single-click-play-cr/`。

最新源码 ASIO release 构建及运行时 8 项、配置审查 10 项和静音播放 IPC 16 项回归通过。六个截图场景覆盖启用／关闭、中英文紧凑窗口及空库提示，偏好在退出后保留且无 binding loop；主界面、英文紧凑窗口及中文空库的截图已目视检查。构建基于 `634f272` 加当前工作区改动，源码与发布 EXE 的 SHA256 身份记录保存在同一验证目录；原始数据库保持不变。

## 列表单击播放选项（2026-10-09，0.3.5）

声音列表底部新增“单击播放”勾选项，默认关闭；关闭时单击选中、双击试听，开启时普通单击选中并播放。旧设置文件兼容默认关闭，偏好保存后重启保留。Ctrl／Shift 多选、右键、拖出、缺失记录及方向键选择不触发自动播放；开启时双击回调不追加重复试听。Waveform 空状态提示随模式切换。

格式检查、默认与已校验 SDK 2.3.4 的 ASIO 配置的 workspace/all-targets 严格 Clippy 和完整测试通过。35 项 GUI 回归包含中英文、1080×700／1440×900 的开关可见性与操作、真实单双击事件、键盘、多选、缺失项及拖动；配置测试覆盖旧文件兼容和启用／禁用后的保存重载。检查日志位于 `.rust-validation/single-click-play/`，测试使用隔离资料库。

最新 ASIO release 构建的运行时、配置审查和静音播放 IPC 回归通过。六张软件渲染截图覆盖勾选／取消、中英文紧凑窗口以及空库提示，未发现遮挡或 binding loop；底部就绪文字去掉固定的“双击试听”说明。源代码身份、截图和安装 EXE 身份保存在同一验证目录，原始数据库及 WAV 保持不变。

## 紧凑列表与详情 CR（2026-10-08，0.3.5 ASIO 构建）

多选操作合并到结果工具栏，列表使用 32px 单行并把路径移到当前文件详情；源 Metadata 默认可见，备注默认折叠，收藏使用星形按钮。复审修复了隐藏颜色仍随详情草稿写回的问题：详情保存省略颜色，保留其他写入及遗留颜色值。详见 [审查修复](Rust_Review_Fixes.md)。

格式、默认/ASIO 的 workspace/all-targets 严格 Clippy 和完整测试通过。回归验证非标准遗留颜色不再阻止收藏草稿，以及外部颜色更新在详情草稿排空、批量标注后仍保留；超长标签拒绝切换库、纠正后重试和关闭排空继续通过。

自动滚动与行渲染统一使用 32px 行高，修复仍按旧 46px 定位导致键盘选中项移出视口的问题。新增紧凑/宽窗口连续上下选择的可见性回归，确认修复前失败并在修复后通过。

最新 ASIO release 构建及 10 项审查修复回归通过；原始数据库哈希保持不变。

本轮在与当前源代码内容一致的隔离工作区构建，避免覆盖正在运行的常规 `target/` 服务器。便携包与固定 `local_release/` 的验收使用该隔离 release 输出作 EXE 身份基准；日志及构建/安装身份记录保存在 `.rust-validation/compact-details-cr/`，测试使用隔离数据目录。

## 全工作区 CR 与修复验收（2026-10-08，0.3.5 ASIO 构建）

复审当前未提交的菜单/音效库流程、WAV Metadata、并行扫描、目录检索和分页改动，修复三项问题：XML 声明编码被正文非 UTF-8 字节干扰、异常提取版本导致增量扫描永久报错，以及 XML 深度/命名空间检查晚于昂贵操作。提取版本升至 3，旧整数版本与异常类型都在下一次增量扫描重新提取，已有用户标注和扩展 Metadata 保留。详见 [审查修复](Rust_Review_Fixes.md)。

格式、默认/ASIO workspace/all-targets 严格 Clippy 与完整测试均通过，各 **176 项通过、7 项直接发现时 ignored**，不重复计算嵌套子进程输出。5 个进程 helper 由父回归调用；真实 BOOM Metadata 的按需测试另行通过，读取 34 个源 WAV。最新 ASIO release 的运行时 8 项、审查回归 10 项、库管理 10 项、真实 Windows ACL 和静音播放 IPC 16 项均通过，检查使用隔离数据目录；旧库哈希及源 WAV 保持不变。

完成这些回归后，在同一已生成的自有合成数据库上只读复测 1,000,000 条记录、100 次查询：结果页 P50 **46.85ms**、P95 **419.95ms**，满足 **P95 latency <500ms for 1M+ records**；结果页加目录统计 P95 **561.05ms**，该组合口径仍超过 500ms。无并行 Cargo 构建、无结果缓存，OS 缓存未清空。目录统计与搜索共用后台线程，迟到结果会丢弃，但正在执行的旧目录统计仍可能延迟新查询；本轮没有改变这一调度限制。声学延迟未测量。

源码、EXE 身份及本轮检查摘要见 CR 验证数据。便携包与固定本地安装的验收日志保存在 `.rust-validation/cr-final/`，程序安装路径继续使用 `local_release/`。

## 扫描入库与查询性能（2026-10-08，本地 0.3.5 ASIO 构建）

扫描使用有界 Rust Metadata 线程池、单写入线程、复用 SQL、批内目录缓存及合并字段更新；普通 ID3 标签跳过封面等二进制帧。搜索先分页 ID 再载入 Metadata，FTS5 目录计数改为流式累计后汇总，保留同一读取快照、筛选语义和稳定排序。未增加数据库格式迁移或查询结果缓存。详见 [实现和复测说明](Rust_Scan_Search_Performance.md) 与 完整性能数据。

同机最终发布版：匿名实际 WAV 样本全扫描 **40.679 → 29.156 秒**，减少 **28.3%**；增量 **1.249 → 0.991 秒**。全部专业字段、五组来源、全部样本的库名召回及源文件大小/修改时间一致，0 错误、0 警告。2,000 个本地微型合成 WAV 的完整扫描 **0.430 → 0.249 秒**；其 8,045 files/s 不代表大型 Metadata 或网络存储吞吐。

1,000,000 条合成记录、100 次查询、同一数据库顺序前后复测：结果页 P95 **411.056 → 401.902ms**，满足 **P95 latency <500ms for 1M+ records**；加上目录命中统计的 P95 **621.454 → 536.618ms**，减少 **13.7%**，但该组合口径仍超过 500ms。GUI 先发布结果页再更新目录。测试没有清空系统文件缓存，不能视为冷盘保证。

默认/ASIO 各 **172 项测试通过、7 项按需测试忽略**，不重复计算一个子进程测试；另行通过 34 个真实 BOOM Metadata 样本。格式、严格 Clippy、release 构建、运行时、审查修复、库管理及真实 Windows ACL 拒绝访问回归均通过。新回归覆盖并行/串行结果一致、每种排序和可见性与直接 SQL 对照，以及 ID3 跳读与旧解码器一致。验证使用隔离数据库。

## 专业 WAV Metadata 扫描（2026-10-08，本地 0.3.5 ASIO 构建）

补齐 LIST/INFO、iXML USER/ASWG/vendor 字段、aXML/XMP、ID3v2 文本及 Soundminer SMED。SMED 支持已验证的 Blowfish/ECB + UTF-16 XML 包装，封面及 Waveform 缓存不进入数据库或 FTS5。旧记录在下次增量扫描时按提取版本自动补扫，保留用户标注和未知扩展字段。试听和 Waveform 只读音频头，不重复提取大型 Metadata。

匿名商业 WAV 样本全部扫描成功，**0 错误、0 Metadata 警告**。每条记录均保留 Description、Category、SubCategory、CatID、Library、Manufacturer、VendorCategory，以及 SMED、iXML、INFO、ID3、XMP 五组字段。库名查询召回全部样本，二次增量扫描跳过全部未变化样本。源 WAV 大小和修改时间保持不变；实际路径、记录数和库容量不在公开报告中列出。发布版全扫描耗时 45.16 秒，包含 CLI 启动并与其他验证并行；这是带大型嵌入封面的网络路径实测，不代表 SSD 扫描目标或 1M+ 搜索性能。原 34 个 P-51 Mustang 样本也通过 SMED 分类、子分类、话筒及库名验证。详见 Metadata 验证数据 和 [格式说明](Rust_Wav_Metadata.md)。

最终默认与 ASIO 配置各 **169 项测试通过、7 项按需测试忽略**（不重复计算子进程输出）；34 个 BOOM 样本的按需测试单独运行通过。格式检查、workspace/all-targets 严格 Clippy、release 构建、运行时、审查修复、库管理及静音播放 IPC 回归全部通过。构建基于 `137bfde` 加当前工作区改动；新回归覆盖尾部块、XML namespaces/CDATA/entities、UTF-16/旧编码、ID3 三个版本、含大封面的 SMED、错误/超限块、重扫补齐、索引重建和用户标注保护。

## Waveform 点击播放与列表选择（2026-10-08，本地 0.3.5 ASIO 构建）

播放头改为 1px 细线并移除顶部粗标记；单击 Waveform 或时间尺按显示范围定位并开始播放。`SeekAndPlay` 在同一音频控制操作中先定位，失败时不执行播放。列表移除选择框、收藏星形及对应表头，整行支持右键收藏；Ctrl 点选、Shift 连选、Ctrl+Shift 追加区间及 Shift 方向键保留批量操作入口。

回归覆盖 Ready/Playing/Paused/Stopped/Ended 的目标位置、播放历史会话、定位失败、放大后的时间映射、缺失文件与管理操作禁用、整行左边缘点击、修饰键不误触试听，以及筛选/重排后按文件 ID 重新解析区间锚点。普通和 ASIO 配置的格式、严格 Clippy、workspace/all-targets 测试通过；音频控制 IPC、运行时、审查修复、素材库管理回归通过。中英文主界面及小窗口软件渲染截图已检查，日志和截图保存在 `.rust-validation/pointer-selection/`。测试使用隔离资料库和静音输出，不测量实际扬声器延迟。

## 大库扫描进度与暂停控制（2026-10-08，本地 0.3.5 ASIO 构建）

主界面增加持续可见的扫描阶段、计数、当前路径和暂停/继续/取消按钮，扫描菜单与音效库管理窗口同步提供控制。工作线程确认安全边界后暂停，取消可唤醒暂停线程；UI 进度最多排队一个事件。收尾统计改为先按目录聚合音频，再沿目录层级汇总，避免对每个祖先反复读取所有音频。

默认和已校验 Steinberg SDK 2.3.4 的 ASIO 配置通过格式检查、workspace/all-targets 严格 Clippy 与完整测试。新增回归覆盖两次暂停/继续保持扫描会话和计数、暂停期间 Metadata 写入与扫描互斥、暂停取消后释放锁、预暂停空目录取消、源 WAV 不变、中英文按钮/菜单及校验/收尾禁用状态；目录汇总与独立直接查询逐项比较。

最终工作区默认/ASIO 各 **159 项测试通过**（不重复计算子进程输出）。当前源文件 SHA256 清单与最终构建保持一致。发布版运行时回归、审查修复 9 项和资料库管理 10 项通过；中英文扫描中/暂停中 4 个软件渲染截图通过并检查，无 binding loop，截图使用隔离空库和明确的模拟进度。原始数据库和源 WAV 保持完整。

额外运行 `cargo test -p audiolib-db --lib million_record_scan_statistics --release --locked -- --ignored --nocapture`：AMD Ryzen 7 9800X3D、Windows x64、Rust release、内存 SQLite、1,000,000 条合成记录、256 个目录、9 层层级，含缺失记录及空值。单次新汇总 **225.27ms**，用于逐项校对的直接查询 **5.55s**，计数/时长/大小一致。这是收尾目录统计测量，不是磁盘 WAV 全流程扫描、UI 延迟或 FTS5 搜索基准；搜索目标仍为 **P95 latency <500ms for 1M+ records**。

暂停/取消需要当前文件系统调用或批次事务返回；进入最终原子协调事务后禁用控制并显示整理阶段。本轮不实现跨进程断点续扫，也未在用户工作库上复现完整扫描卡顿。检查和构建日志、源文件身份及扫描界面截图保存在 `.rust-validation/scan-controls/`。

## 目录交叉检索（2026-10-08，本地 0.3.5 ASIO 构建）

左侧目录改为使用当前关键词和全部筛选条件的匹配数，包含匹配子目录并隐藏零结果分支。目录分面不受当前目录范围、排序和分页限制，可在其他命中分支间切换；当前目录零命中时保留面包屑范围，清空条件后恢复符合剩余筛选的目录。目录匹配由已有防抖搜索线程加载，旧请求不能覆盖新结果，折叠/展开复用匹配目录数据。

默认及经校验 Steinberg SDK 2.3.4 的 ASIO 配置均通过格式、严格 Clippy 与 workspace/all-targets 测试，各 **159 项通过**，另有 5 项隔离子进程 helper 和 1 项百万记录扫描统计基准在直接发现时 ignored。新增 3 项数据库回归覆盖祖先累计、分页/范围独立、全部筛选与文件可见性、中文标注更新和输入校验；新增 1 项实际 Slint 控制器回归覆盖零命中当前目录、展开/折叠、收藏、清空及快速改词。首次 UI 检查在完成操作后遇到临时库仍被后台线程持有，补齐窗口、timer 和 worker 释放后的清理，随后两套完整检查通过。

最新 ASIO release 构建成功，发布版运行时 7 项、审查修复 9 项及库管理 10 项回归通过，测试原库和 WAV 保持不变。本轮源码身份、测试与构建日志位于 `.rust-validation/search-navigation/`；保留工作区原有改动，未发布远端版本。
百万检索基准使用 `search-benchmark --records 1000000 --queries 100 --folder-facets`：Windows x64、AMD Ryzen 7 9800X3D、系统可见内存约 93.5 GiB、ASIO release、临时磁盘 SQLite、单根目录 1,000,000 条合成记录、100 次查询，无结果缓存。列表服务 P50 **50.65ms**、P95 **445.01ms**；列表和目录统计全部完成的 P95 **693.97ms**、P99 **729.95ms**。列表服务达到 **P95 latency <500ms for 1M+ records**，完整目录更新尚未达到 500ms，宽泛全库命中仍有额外统计开销。两者分步发布，先显示列表，再更新目录；这些服务计时不包含输入防抖、工作线程排队及 Slint 绘制。原始结果见 `.rust-validation/search-navigation/benchmark-final.json`。

## 音效库弹窗与扫描取消 CR 修复（2026-10-08，本地 0.3.5 ASIO 构建）

修复两项 P2：原生菜单打开扫描或音效库管理窗口后，弹窗接管输入焦点并屏蔽背景 Metadata 编辑及试听；提交扫描后同步显示路径校验状态，校验期间的取消或 Esc 取消当前请求，后台校验成功还须获得事件循环确认才能启动扫描。过期或已取消的准入回调不会关闭后来打开的扫描窗口。嵌套确认窗口默认聚焦“取消”，扫描及音效库窗口的 Tab / Shift+Tab 保持在窗口内，高级维护展开后的控件仍可访问。

默认和经校验 Steinberg SDK 2.3.4 的 ASIO 配置均通过格式检查、workspace/all-targets 严格 Clippy 及 **151 项测试**，计数排除嵌套子进程重复输出。直接发现时另有 4 个 ignored 进程辅助测试，由父回归在隔离子进程调用。新增 4 项 UI 回归通过中英文实际菜单验证路径输入、背景标签草稿及试听保护、双向 Tab、取消 / Esc 与嵌套确认；新增控制器回归用可阻塞校验器验证取消、重复请求拒绝、排队准入取消、旧结果屏蔽及成功重试，原有扫描历史、缺失状态和用户标注保持。

首次定向 UI 检查有一项确认窗口用例失败：直接更新可见状态时，焦点等待延迟回调及下一次 timer 才转移。改为显示状态变化时立即聚焦“取消”，并保留原生弹窗关闭后的 timer 接管；该定向用例及随后两套完整检查均通过。临时日志、源码冻结身份和安装 EXE 身份记录位于 `.rust-validation/ux-cr-fix/`；修复说明见 [代码审查修复](Rust_Review_Fixes.md)。

最新源码 ASIO release 构建成功；运行时回归 7 项、审查修复回归 9 项和音效库管理回归 10 项通过。8 个隔离合成 WAV 场景截图检查通过，并查看最终扫描和音效库管理布局；无 binding loop，合成音频字节保持不变。本轮构建版本为 0.3.5，固定本地安装目录为 `local_release/`，程序文件与 `%LOCALAPPDATA%/AudioLibExplorer/v1` 的用户数据分别保留。

## 音效库管理交互与帮助焦点修复（2026-10-07，本地 0.3.5 ASIO 构建）

主界面与菜单改以音效库日常操作为中心，数据库新建/打开、备份/恢复、校验、优化、FTS5 和数据交换收在默认折叠的“高级维护”中。管理窗口提供添加文件夹、增量扫描、全量扫描、缺失引用修复与历史；扫描对话框支持原生文件夹选择、本地/网络路径、方式说明和原位错误反馈。当前目录及右键扫描先确认范围，避免上一轮全量模式意外复用。全量扫描仅覆盖确认文件夹及其子目录，完整成功且无错误才协调缺失；标签、评分、收藏和备注保留。

默认和经校验 Steinberg SDK 2.3.4 的 ASIO 配置均通过格式检查、workspace/all-targets 严格 Clippy 及 **146 项测试**。直接发现时另有 3 个 ignored 进程辅助测试，由父回归在隔离子进程调用。新增或调整的回归覆盖中英文日常入口、技术按钮默认不可见与滚动展开、扫描路径/方式/取消/Enter/忙碌限制、无效路径恢复、真实增量/全量扫描及标注保护、缺失视图清除旧筛选、可读历史和错误详情。扫描在原生文件对话框期间结束也会发布最终状态，取消对话框后刷新结果，并可再次扫描。

同时保留并验证帮助面板的独立焦点与键盘捕获修复：两项中英文回归覆盖列表方向键、试听/播放、上下文菜单、编辑器输入与草稿保护、Tab/Shift+Tab、Esc/关闭后的正常操作，防止帮助弹窗下的键盘穿透。

最新源码 ASIO release 构建成功，两份 Windows EXE 版本为 **0.3.5**。发布版运行时回归、审查修复 9 项及资料库管理 10 项通过。8 个隔离合成 WAV 场景截图通过并检查：中英文主界面、音效库管理、扫描对话框，以及中文帮助和 1080×700 紧凑布局；无 binding loop，合成 WAV 字节未变。源码冻结身份、构建日志和截图在 `.rust-validation/library-ux/`。本轮未发布远端版本，未重复百万记录搜索或按钮到实际音频输出延迟测量。

## 基础菜单栏（2026-10-07，本地 0.3.5 构建）

增加常驻的文件、编辑、数据库、扫描、视图、播放和帮助菜单，中英文同步切换。菜单直接调用现有 DataProvider 管理服务，提供新建/打开、添加文件夹扫描、导入导出、备份恢复、校验优化、FTS5 重建、批量标注及记录/目录移除；移除仍只影响库内记录，保留源 WAV。菜单和快捷键按选择、扫描、弹窗、维护及关闭状态启用。切换目录时同步禁用旧目标，右键菜单坐标适配菜单栏，退出在保存 Metadata 后等待取消扫描释放数据库锁；失败保存恢复真实扫描状态。

默认和 ASIO 配置格式检查、workspace/all-targets 严格 Clippy 及 **139 项测试通过**。另有 2 个独立进程辅助测试在直接发现时 ignored，由父回归调用。新增 6 项菜单 UI 回归及 1 项扫描排空退出回归，覆盖中英文入口、稳定 ID/目录路径、扫描模式与禁用状态、快捷键单次调用、模态保护、已有播放控制、详情/帮助及右键弹窗坐标。已校验 Steinberg SDK 2.3.4，最新 ASIO release 构建成功。

发布版资料库管理回归 10 项、审查修复回归 9 项通过；CLI 哈希在最后 GUI 调整和重建前后相同。最终发布 EXE 的中英文主界面、紧凑布局和帮助窗口 4 张隔离合成 WAV 截图通过并检查，无 binding loop，源 WAV 不变。computer-use 检查实际 Windows 窗口的 7 个原生菜单以及文件/数据库菜单条目；原生菜单位于非客户区，软件截图不包含这些菜单。临时日志及截图在 `.rust-validation/menu-bar/`。本轮没有发布远端版本，也未重测百万记录搜索或按钮到输出延迟。

## 0.3.5 CR 修复与发布（2026-10-07）

本轮复审修复两个 P2：快速滚轮时改用当前已显示范围计算源时间锚点，同时累计待处理缩放倍数；播放引擎增加独立 `transport_revision`，任意 Seek、循环及确认的时钟重建都会重置播放头插值，保持加载 generation 与播放历史 session 语义。进一步复审发现 Slint 延迟处理可合并平滑布尔值的 false→true，新增积压快照回归先复现失败，再将时钟身份直接传入面板修复，最终通过。

- 默认/ASIO 配置严格 Clippy、格式检查和 workspace/all-targets 测试通过，每种配置 **132 项通过**，另有 1 个 ignored 进程辅助测试由父回归调用。新增 4 项引擎、1 项视口及 3 项控制器/UI 回归，覆盖小幅与同值 Seek、实际 EOF 循环、传输中断与历史身份、失败命令、显示范围滞后和 UI 合并更新。
- 使用校验后的 Steinberg SDK 2.3.4 构建 **0.3.5 ASIO release**；Windows EXE FileVersion/ProductVersion 均为 0.3.5，manifest 为 0.3.5.0。
- 发布版播放 IPC **16 项通过**。真实大 WAV 静音播放采用 WASAPI 96 kHz / 960 帧，历史身份、暂停/跳转、循环和独立 Pitch/Rate 行为通过。源文件为 168,464,078 字节，未测量声学延迟。
- 中英文、普通 Waveform 和 1080×700 布局 3 个播放截图通过并检查，无 binding loop；原数据库与所读 WAV 哈希保持不变。
- 本地便携包的隔离空库/合成 WAV 和旧库导入两种验收各 **7 项通过**，核对 EXE 身份、CLI、中文窗口与正常退出、损坏偏好诊断、许可及源文件保护。固定输出为 `dist/latest/portable` 和最新 ZIP。

版本说明见 [v0.3.5](Rust_Release_Notes.md)。标签发布由 CI 对精确提交再执行默认/ASIO 检查和 clean-checkout 便携验收；只在成功后公开 ZIP、SHA-256 和构建报告。临时日志位于 `.rust-validation/ui-release/`，截图位于 `.rust-validation/waveform-interaction/`。逐帧测试使用模拟时钟，不代表实机帧率；本轮没有重测百万记录搜索或按钮到模拟输出延迟。

CI 构建第 3 次运行成功，正式发布 v0.3.5。回下载的 ZIP 校验和、两份 EXE 及包内报告均匹配提交 `4163614d1ff6e52923f55bd2ba862050f0b2c190`；随后将相同的 CI 包同步到本地 release/portable/latest ZIP，并再次通过便携版 7 项验收。历史 0.3.4 验收记录保留；本次结果见 0.3.5 发布验收。

## Waveform 播放进度与滚轮缩放（2026-10-07）

试听区域增加从时间轴左端填充的已播放遮罩、底部进度线和带顶部标记的播放头。播放头通过 Slint 逐帧时钟按确认 Rate 补齐两次引擎位置之间的移动，预测限制为 100ms，并平滑校正小幅误差；暂停、停止、循环回头、换源和明显跳转复位。时间读数与辅助功能仍使用引擎确认的位置。Waveform 与时间尺接收滚轮/触控板增量，向上放大、向下缩小，以鼠标时间为锚点保持比例，限制在 1～128 倍，保留点击定位和已有按钮/滚动条。

默认配置格式检查、workspace/all-targets 严格 Clippy、124 项测试通过（独立发现时另有 1 个 ignored 进程辅助测试由父回归调用）。新增 3 项视口数值回归及 4 项 UI 回归，覆盖锚点、边界、无效值、滚轮方向/连续增量、不触发定位、遮罩左端/高度/夹取、16ms 连续帧、快照连续校正、确认 Rate 0.25/4、重复位置与停滞上限及暂停/停止/跳转。ASIO release 使用已校验 SDK 2.3.4 构建成功。

发布版隔离资料库静音播放真实 192 kHz / 24 bit 双声道素材，中英文/普通 Waveform/1080×700 布局 3 个截图通过并检查，实际 WASAPI 输出 96 kHz。原始数据库与所读 WAV 哈希不变。测试日志、截图与脚本为 `.rust-validation/waveform-interaction*` 下的临时产物；逐帧回归使用模拟时钟，不等同于实机帧率或声学延迟测量。

## 列表工具栏与详情面板紧凑布局（2026-10-07）

默认列表顶部由三行操作收拢为单行 32px 工具栏；目录导航和批量操作按上下文出现，勾选本页移入分页栏。无目录导航、未勾选且筛选收起时，列表起点上移 76 个逻辑像素。详情面板从 286/258px 缩为 260/240px，空选中状态隐藏编辑表单，短窗口缩小间距和备注高度，源文件信息折叠，保存状态与操作固定在滚动区外。Metadata 保存和身份绑定逻辑未改。

默认配置格式检查、workspace/all-targets 严格 Clippy、117 项测试通过（另一个进程辅助测试独立发现时 ignored，由父回归调用）；使用校验后的 SDK 2.3.4 构建 ASIO release 成功。发布版审查回归 9 项通过，原始数据库哈希未变。隔离资料库的中文/英文主窗口、1080×700 英文展开筛选及中文空库共 4 个软件渲染截图通过并检查，无 binding loop。临时截图与测试日志位于 `.rust-validation/compact-layout/`。

本轮交付 release 目录中的 EXE；运行中的 `dist/latest/portable` 未替换，也未发布新版本。本轮布局改动仅涉及 `app-window.slint`，构建保留工作区已有的 Waveform/主题改动；未重测声学延迟或百万记录搜索。

## 工作区清理（2026-10-07）

Rust 迁移验收后，移除旧 Python 源码、入口、依赖和测试，以及临时验证脚本、测试数据库、缓存、旧日志和阶段性总结。当前 Rust 测试、发布验收工具及构建 SDK 保留；旧库和 `config/audiolib_config.yaml` 继续作为只读导入输入。历史 Python 实现可从已提交版本查阅。

历史测量的正式报告仍保留，报告中旧 `.rust-validation` 日志/截图路径仅记录当时的位置，临时文件已清除。0.3.4 的界面截图未随公开仓库发布。清理检查记录核对原库、34 个 WAV、Rust 源码与 EXE，以及清理后的旧库导入和空库便携验收。

## 0.3.4 GUI 审查与 CI 发布（2026-10-07）

复核近期共享主题、控件交互、Waveform 配色及发布脚本。选中复选框只有绿色底而缺少勾号，改为固定尺寸 SVG，并在发布版批量标注截图确认勾号可见。补齐 Git 忽略规则，数据库、测试 WAV、运行日志和本机设置留在工作区。此前目录无 Git 元数据，本次不声称具有历史差异基线。

格式、默认/ASIO 严格 Clippy、两套各 117 项测试通过。控件鼠标/键盘/辅助功能回归、7 个界面场景及两种便携验收通过；传统模式导入 34 条，新增 CleanCheckout 模式从空库启动并扫描 1 个合成 WAV。源库哈希不变，波形算法与音频处理本轮未改。详见 审查检查记录。

新增 `.github/workflows/release.yml`：版本标签触发或手动指定已有标签，验证标签与 Cargo 版本一致，执行默认/ASIO 检查和便携包验收，上传 ZIP、SHA-256 与构建报告后才公开 Release。使用仓库专属 Windows Runner；发布不依赖本机音频素材。

CI 第 2 次运行完整通过，自动发布 v0.3.4。回下载 3 个附件，ZIP 的 SHA-256、内含两份 EXE 的哈希和包内构建报告均与发布记录一致；见 CI 记录。首次运行暴露的 MSIX AppData 路径重定向已通过独立 Runner 目录修复。Runner 由登录计划任务启动，机器开启且用户已登录时才能构建；凭据及独立 PowerShell 运行时均保存在仓库外。

## 0.3.3 恢复深色层次（2026-10-07）

根据用户对 0.3.2“太灰”的反馈，恢复原版深蓝黑背景、深色侧栏/列表/播放器控制区和薄荷绿强调色。彩色 Waveform 画布仍为 `#849094`，用于承托黑色非音调峰值；波形算法、普通波形模式与交互逻辑不变。保留 0.3.2 的控件统一强调色、键盘/辅助功能和窄输入框边界修复。

默认/ASIO 各 117 项测试、两种配置严格 Clippy 与格式检查通过；8 个发布版界面场景与便携版 7 项验收通过。原数据库和参考 WAV 哈希未变。本轮发布检查与截图记录见 深色配色验证。

## 0.3.2 GUI 统一配色（2026-10-07）

主界面、Metadata 详情、播放器和弹层使用共享 `ui/theme.slint`：石墨灰背景、雾灰播放器、青灰列表层次、低饱和青绿操作/选中态。常用按钮与 SVG 图标采用相同语义色；音量/缩放、复选框和输入焦点使用应用强调色。原生 Windows 上下文菜单仍由系统绘制，不属于 Slint 软件快照。

- 彩色 Waveform 继续使用 v4 算法、`#849094` 底色、黑色非音调峰值与原有频率色谱；普通模式保持深底绿色 Waveform。此次没有修改频谱分析、PCM 或 Metadata 数据。
- 新增控件交互回归验证音量滑块的鼠标与方向键、辅助功能设值、收藏切换，以及 Pitch 输入后回车；标准 Slint 控件继续负责输入和辅助功能，覆盖层只绘制颜色。
- 主要文字/面板对比度 11.03:1，播放器次级文字 5.00:1，主操作文字 6.96:1，黑色峰值/灰底 5.88:1。
- 格式检查、默认/ASIO 严格 Clippy 通过；两种配置各 117 项测试通过。8 个发布版界面场景退出 0，包含中英文、1080×700、音频输出、批量标注、波形设置、普通波形、频率参考样本与用户提供的示例 WAV。便携版 7 项启动/身份/许可/源库保护检查通过。
- 本轮检查、发布 EXE 哈希及最终窗口截图见 GUI 配色验证。

## 0.3.1 数据库与播放审查修复（2026-10-07）

本轮修复管理回退与跨实例写入隔离、普通 CLI 库打开边界、不同页大小备份恢复、同配置目录的第二桌面实例、同文件重播历史和重链实际路径验证，共 6 项。修复和回归对应关系见 [审查修复说明](Rust_Review_Fixes.md)；机器可读结果与本轮发布 EXE 的 SHA-256 见 本轮报告。数据库仍为 schema v3。

- 当前工作区默认及 ASIO 配置的 workspace/all-targets 测试各 **116 项通过**：音频 31、CLI 5、领域/配置 8、数据库 43、桌面 27、IPC 1、Windows 1，包含同时完成的频谱回归。另有 1 个桌面子进程 helper 标为 ignored，由异常退出回归显式启动。两种配置的严格 Clippy（`-D warnings`）及格式检查通过，默认 dev 和 ASIO release 构建通过。ASIO SDK 2.3.4 使用已校验的本地归档。
- 管理隔离测试覆盖失败维护、恢复窗口、全部写入口及跨进程普通写入；扫描依然允许标注和播放历史写入。1024/8192 字节页的官方备份恢复至 4096 字节 WAL 库，恢复后热读取、FTS5 和写入有效，源备份不变。只读检查/导出/备份不创建管理 sidecar。管理租约保护参与当前协议的 Rust 客户端，外部 SQL 工具及旧客户端不参与。
- 发布版审查回归 **9 项**、库管理 **10 组**、旧库导入/搜索/扫描 **7 项**及真实 Windows ACL 回归通过。含 2,000 文件跨进程扫描互斥、旧库/缺失路径拒绝、实际符号链接重链边界和原用户标注保留；不可访问子目录的记录保留，恢复访问后才协调缺失。
- 发布版播放 IPC **16 项通过**。实际静音 WASAPI 输出为 96 kHz、960 帧缓冲；暂停恢复和 seek 保持历史计数 1，停止重播变为 2，自然结束重播变为 3。同配置目录的第二桌面实例及运行中的 CLI 切库/恢复明确拒绝，设置未变化。真实 192 kHz 大 WAV 使用增益 0 播放，读取与 PCM 缓冲维持有界；未测量声学延迟，本轮也未重测 Zen Go 路由、断开和占用恢复。
- 源文件核对确认原数据库及全部 34 个 WAV 的 SHA-256 与修复前基线相同。本轮未修改查询 SQL，也未重新运行百万搜索基准；性能继续引用下方 schema v3 的实测结果，目标为 **P95 latency <500ms for 1M+ records**。
- 便携目录中的 EXE 与报告内 release 哈希相同；隔离首次启动导入 34 条、CLI 统计、中文截图和正常退出、损坏设置诊断、Slint/SoundTouch/ASIO 许可及原库保护共 **7 项验收通过**。已查看最终中文截图，启动入口和 ZIP 固定输出至 `dist/latest`。

## 0.3.1 彩色波形噪声修正（2026-10-07）

根据用户的 REAPER 最终效果纠正“噪声混为亮灰且仍带随机颜色”的实现。非音调内容淡化到近黑色普通峰值；彩色模式使用灰底以保留轮廓。短窗解析中高频瞬态，长窗辅助低频，避免把挤压声的短促共振全部抹黑。公式与边界见 [试听与 Spectral Peaks](Rust_Spectral_Audition.md)。

- 构建与修正检查：默认和 ASIO 配置各 **116 项通过**，格式、两种配置的 workspace/all-targets Clippy `-D warnings` 通过。计数排除嵌套子进程重复输出；一个独立发现时忽略的进程辅助测试由父回归调用。工作区同时包含另一任务完成的数据库/播放历史修复，本节只记录波形修正的新增验证。
- 新增白噪声/冲击、多采样率和幅度、纯音＋噪声单调显色、40 ms 短促共振、缩放/缓存失效及显示增益/强度不漂白噪声回归。缓存版本升级为 **v4**，旧 v3 结果自动重算。
- 发布版截图五项通过并查看：中文主界面、英文小窗口、显示设置、七纯音＋白噪声/混合信号，以及用户提供的 `Example_Impact_1.wav`。实际示例波形大部分为黑色，局部共振显色；没有读取 REAPER 工程或声称逐像素复刻其内部算法。
- 用户 WAV 使用隔离副本进行 GUI 验证，原文件 SHA-256 保持 `6CEB9366A29A8672BD9E405B0CF73D4761380CF579C286B08BD58647B500C454`。本轮不更改 PCM 或播放 Pitch/Rate 行为，也没有重测声学延迟或百万记录搜索性能。

## 0.3.0 REAPER 风格试听与 Spectral Peaks（2026-10-07）

底部改为上方播放控制、彩色 Waveform/时间尺、下方缩放滚动及源时间信息。实现独立 Pitch（±24 半音）与 Rate（0.25～4 倍），以及 dB 音量、Mono、整段循环。行为和算法见 [试听与频谱峰值说明](Rust_Spectral_Audition.md)。此前保存/退出及数据库管理实现一并保留。

- 默认与 ASIO 配置的 workspace/all-targets 测试各 **83 项通过**：音频 23、领域/配置 6、数据库 34、桌面 18、IPC 1、Windows 1。格式及两种配置的严格 Clippy 检查通过。新增紧凑布局和控件回归，覆盖 1080×700 展开筛选、空结果时底部控件仍在窗口内。
- SoundTouch 2.3.2 的流式处理位于控制线程；数值回归核对变调后的频率、独立变速后的长度、定位尾长、参数极限和 Mono 抵消。默认 Pitch 0 / Rate 1 绕过处理器，音频输出回调继续只消费有界 PCM。
- 色相使用用户截图的七个对数频率锚点，饱和度按主频附近能量集中程度计算。44.1/48/192 kHz 纯音与白噪声回归通过；缓存升级 v3，避免复用旧重心着色结果。实现参考 REAPER 公开原理，不宣称复刻其内部公式。
- 发布版播放 IPC **14 项通过**，新增暂停定位下修改 Pitch/Rate/Mono、非法参数不更改状态、4 倍速整段循环不重复历史身份、退出后保存已确认的试听设置。真实大 WAV 静音播放仍使用有界内存；未测量按钮到模拟输出的声学延迟。
- 配置及既有修复回归 **7 项通过**，包含 2,000 文件跨进程扫描互斥、原始 Metadata 刷新及注释保留、首次偏好继承。数据库管理的后续独立代码审查不在本轮试听改动的修复范围内。
- 发布版界面截图覆盖中文主界面、英文 1080×700 展开筛选、中文显示设置、七频率＋噪声参考样本。传输按钮使用 SVG；小窗口高级筛选可滚动，源时间与缩放保持可见。
- 构建与 EXE 身份已核对 0.3.0 ASIO release；便携版验收 **7 项通过**，涵盖 release/包内哈希、隔离首次启动导入 34 条、CLI、中文界面及正常退出、损坏设置诊断与第三方许可。`dist/latest` 的便携目录和 ZIP 已更新。
- 源文件核对：原库 SHA-256 与全部 34 个 WAV 的 SHA-256 均与修改前基线相同。本轮没有重跑百万搜索基准，数据库性能继续参考下方 schema v3 记录，目标为 **P95 latency <500ms for 1M+ records**。

## 数据库功能补全（2026-10-06）

已完成数据库管理、多库切换、缺失视图/手动重链、库内移除、多选批量标注、扫描/播放历史和全库 JSONL/CSV 数据交换，操作说明见 [资料库管理](Rust_Library_Management.md)。数据库升级为 schema v3；原 Python、数据库和源 WAV 保留。

- 默认和 ASIO 两种配置的工作区全部 targets 测试各 **77 项通过**：音频 20、领域/配置 6、数据库 34、桌面 15、IPC 1、Windows 1。格式检查及两种配置的 Clippy `-D warnings` 通过；数据层不启用 scanner 的 library Clippy 也通过。
- 修复 Unicode 非递归完整扫描未标记缺失、removed 计数未保存、错误明细缺失路径，以及 extensible WAV 转普通 PCM 后 valid bits 残留。错误明细保留最多 100 条，总数和截断数量不丢失；错误或取消时不协调缺失。
- 管理回归覆盖已提交 WAL 备份、自动回退备份、恢复后热读取连接、FTS5 external-content/表定义/触发器检查及修复、只读源保持不变、拒绝普通/空/未来版本 SQLite、原子批量/标注导入、JSONL/CSV 往返、重链冲突和库内移除后 WAV 保留。
- 桌面回归使用真实 Slint 测试事件循环和隔离库，覆盖保存 FIFO barrier、备份包含最新草稿、A→B→A 库切换、无效草稿拒绝切换、管理时关闭等待和缺失记录禁止试听。切库保留单调的 Metadata 完成序号，旧选择任务可结束等待；有超时保护的 Condvar 回归通过。Win32 文件选择使用系统 common-dialog FFI，无新增运行依赖；未宣称逐个原生文件对话框均已人工点击验收。
- 播放历史按音频引擎实际路径查库记录，旧库计数保留而不虚构历史事件。CLI 改变所选库及恢复要求无正在运行的桌面实例；运行中通过桌面管理器保存草稿并切换。
- 已构建无 ASIO dev 工作区和 ASIO release。发布版管理验收的 10 组检查通过；播放 IPC的 11 项检查通过，另实测运行中的桌面拒绝 CLI 切库/恢复，且播放历史只记实际播放的库内文件。合成音频全零，真实 WAV 使用增益 0。本轮没有重新调整 Zen Go 的 ASIO 配置或测量声学延迟。
- 34 个文件的旧库导入/中文搜索/扫描、真实 ACL 拒绝读取和 2,000 文件跨进程扫描回归均重新通过。完整扫描约 **77.1962ms / 440.44 files/sec**，含 CLI 启动，为本机热缓存的小样本结果。schema v3 的百万记录复测 P50 **46.5378ms**、P95 **423.6306ms**、P99 **429.1078ms**，满足两项搜索目标；详见下方测量条件及 原始结果。
- 发布版界面检查核对中文/英文数据库管理和中文批量标注三张截图，批量面板显示 34 条勾选，三个进程均退出 0。便携版启动、34 条导入、CLI、中文截图和正常退出、损坏设置诊断及许可检查再次通过。源文件保护记录核对原库 SHA-256 和发布验证前后全部 34 个真实 WAV 的哈希，均未变化。

## 代码审查修复（2026-10-06）

审查中的全部 12 项问题已修复，具体对应关系见 [修复说明](Rust_Review_Fixes.md)。Python、旧数据库和源 WAV 保留。

- `cargo fmt --all -- --check` 通过；默认和 ASIO 两种配置的 workspace/all-targets Clippy（`-D warnings`）均通过，两种配置各 **56 项测试通过**：音频 20、领域/配置 4、数据库 19、桌面 11、IPC 1、Windows 1。
- 回归覆盖 μ-law/A-law/IMA/MS ADPCM Seek、区间和尾长；非首 ASIO 面板使用当前租约；实际通道和设备采样率回退；Unicode full case folding；移除 BWF/iXML；child→parent→child 目录关系；扫描完成、取消、进程强杀后的排他锁释放。
- Metadata 回归覆盖文件身份、A→B→A 草稿、晚到保存确认、新编辑、FIFO 关闭 barrier、失败保留草稿和重试。真实窗口正常关闭已通过 UI smoke；保存失败使用状态机和 Slint 测试后端合成 busy 错误，尚未执行真实 SQLite 锁竞争下点击系统关闭按钮的端到端失败测试。
- All sounds 的旧目录请求在后台及事件循环发布前检查 generation，检查位于目录选择、面包屑与状态写回之前；该修复经代码复核，未宣称单独的端到端竞态计时验收。
- 本轮 ASIO 面板故障回归使用模拟驱动租约，未再次改变 Zen Go 的采样率或缓冲。下方实机记录是首版静音流证据，声学延迟、模拟端口路由及断开/占用限制仍适用。
- 构建检查记录核对最终 release EXE 的哈希。发布版审查回归的 7 项检查通过：两个独立 CLI 同时扫描 2,000 个 WAV，一个完成、一个明确 Busy，随后增量扫描全部 unchanged；另外核对目录、Unicode 标签、源字段清除和首次偏好继承。脚本不打开音频输出。
- 本轮重新运行旧库导入/搜索/扫描、真实 ACL 拒绝读取及静音播放 IPC，全部通过。百万条记录的 100 次真实 DataProvider 查询 P50 **45.6899ms**、P95 **406.2398ms**、P99 **413.5784ms**，满足目标。下方性能、扫描及内存数字更新为本轮证据，首版硬件记录保持历史标注。
- `dist/latest/portable` 已替换为本轮 ASIO release。便携版检查再次通过 EXE 哈希、首次导入 34 条记录、CLI、中文截图、保存完成后退出、错误设置诊断及许可材料检查；最终中文截图已查看。原数据库 SHA-256 保持不变。

## 此前 0.2.0 GUI 迭代（2026-10-06）

- 更新紧凑搜索工作台、可折叠高级筛选、可隐藏 Metadata 详情、文件夹导入对话框与更多菜单。文件/文件夹右键菜单支持试听、Metadata、收藏、评分、资源管理器、复制及重新扫描，中英文均有对应文案。
- `cargo fmt --all -- --check`、默认及 ASIO 工作区 Clippy（`-D warnings`）通过；两种配置的工作区测试各 **40 项通过**。已通过准备脚本验证 Steinberg SDK 2.3.4，并构建 ASIO release。
- 新增 Slint 无窗口回归：打开菜单后替换结果模型，点击收藏仍提交原文件 ID；Esc 折叠筛选后仍保留条件。另覆盖快速标注的局部 patch 和保存期间继续编辑的比较逻辑。
- IPC 单元测试改用带进程 ID 的独立测试管道，不与正在运行的桌面程序冲突；正式版管道名称保持原有契约。
- 已检查中英文主界面、英文导入对话框与 1080×700 展开筛选的软件渲染截图。使用隔离资料库实测 Windows 右键菜单弹出、收藏目标文件、Ctrl+I 切换详情。其余原生菜单项及完整键盘遍历尚未逐项人工验收。
- `tools/validate-portable.ps1` 通过：打包 EXE 与 release 哈希一致，隔离首次启动导入 34 条记录、CLI 统计、中文界面截图与退出、错误设置的启动诊断、许可文件及原始数据库哈希均通过。
- 本轮未重跑百万记录基准或硬件音频延迟测量；下方保留首版证据，性能目标继续为 **P95 latency <500ms for 1M+ records**。

## 首版验证记录

验证日期：2026-10-06。交付范围为 Windows x64、Rust 1.97.1 MSVC、Slint 1.17.1、rusqlite 0.40.2、CPAL 0.18.2、Symphonia 0.6.1 和 Rubato 5.0.1。Python 源码、旧配置、原数据库和源 WAV 保留用于对照与回退。

## 实现与构建

实现目录浏览、中文/英文搜索、分页虚拟化结果表、筛选排序、Metadata 展示与数据库内编辑、收藏、Waveform、播放、音频设置及本机 CLI 控制。播放列表、DAW 工程扫描、独立频谱、插件和远程服务的界面暂缓，旧库相关表和数据保留。

| 检查 | 结果 |
| --- | --- |
| `cargo fmt --all -- --check` | 通过 |
| 无 ASIO：workspace Clippy，所有 targets，`-D warnings` | 通过 |
| 无 ASIO：workspace 单元及集成检查 | 37 项通过 |
| 启用 ASIO：workspace Clippy，所有 targets，`-D warnings` | 通过 |
| 启用 ASIO：workspace 单元及集成检查 | 同样 37 项通过 |
| MSVC release，桌面与 CLI，启用 ASIO | 构建通过 |

37 项分布：音频 16、领域 2、数据库 15、桌面 2、IPC 1、Windows 1。覆盖率百分比尚未统计；此处不宣称达到旧文档的 70% 指标。音频输出回调只消费有界 PCM、处理路由与增益；文件读取、解码、重采样、Waveform 和 SQLite 操作位于后台线程。

ASIO SDK 来源和 SHA-256 固定于 `tools/prepare-asio.ps1`。Cargo 默认指定本地 SDK 路径，未准备 SDK 的 ASIO 构建明确失败，避免 asio-sys 编译时下载其他版本。便携版包含启动入口、两份 EXE、配置示例、音频术语、验证记录和第三方许可材料；Slint 署名入口位于“关于”。此交付按个人本机使用准备。

便携版冒烟结果直接运行 `dist/latest/portable` 的 EXE，核对与 release 的 SHA-256 相同；从包目录首次启动导入 34 条记录，CLI 统计正确，中文窗口截图及退出成功。故意损坏隔离 settings.json 后，程序返回失败码 1 并同步写入带启动上下文的诊断日志。原数据库哈希保持不变。最终中文截图保存在项目 `.rust-validation/portable-smoke/chinese.png`，已人工检查。

## 数据迁移与扫描

运行脚本结果验证旧库 34 个文件的备份导入、中文实际召回、筛选与数量、Metadata/收藏持久化、更新后旧 FTS5 词项消失、无修改重扫和 Windows 路径去重。旧库目录关系为 3 个目录、6 条闭包关系，导入保留文件主键及目录关系。

数据库集成测试另构造旧库，核对用户编辑、历史、播放列表、工程引用、缓存和额外字段/BLOB 的保留；覆盖已提交 WAL 的 backup、重复打开、迁移失败不发布目标、FTS5 增删改、并发修改时数量与页面的一致性。重新扫描保留用户注释，指纹变化时失效 Waveform 缓存。

原始 `data/audiolib.db` 的 SHA-256 在验证前后均为：

```text
76884EE7340326C5796F6BD85B0B2CEA5C66006B11CED7374782D045D29228B6
```

真实测试目录 `test_audiolib/P-51 Mustang` 的 34 个 PCM24/192kHz/立体声文件全量扫描耗时 **77.1962ms，约 440.44 files/sec**，包含 CLI 启动时间。本次扫描脚本单独运行；这是本机热缓存、小样本基础 Metadata 扫描，不代表百万真实文件的持续吞吐量。Waveform/FFT 不计入基础扫描。

真实 Windows ACL 测试仅在测试专属目录复制两个 WAV 并临时拒绝读取。一个可访问文件删除、另一子目录不可访问时，扫描记录 1 个错误并保留 2 条记录；恢复 ACL 后成功扫描才将缺失文件标记为不可见，剩余 1 条可见记录。ACL 在 finally 中恢复，源 WAV 未修改。取消、损坏文件和跳过符号链接的边界另由集成测试覆盖。

当前协调策略偏保守：一轮目录扫描存在错误、取消或跳过子树时，不执行该轮缺失协调。成功完整枚举后才标记缺失，不物理删除旧文件记录。

## 百万记录搜索性能（数据库功能补全后复测）

原始结果与测量条件、本机环境。使用 release 版本的真实 `SqliteProvider::search`，包含输入验证、分词、同一读取快照中的准确总数、排序、分页和拥有数据的 Metadata DTO 转换；没有搜索结果缓存。

| 项目 | 结果 |
| --- | --- |
| 数据量 | 1,000,000 条合成记录 |
| 查询 | 10 种请求，共 100 次；每页 200 条 |
| P50 | **46.5378ms**，通过 <100ms |
| P95 | **423.6306ms**，通过 **P95 latency <500ms for 1M+ records** |
| P99 | 429.1078ms |
| 单项广泛命中 `metal` 的 P95 | 429.1078ms |
| 中文 `爆炸` / `发动机` 单项 P95 | 47.8182ms / 89.5706ms |
| 首次数据生成含索引维护 | 289.376 秒；本次复用同一数据集 |
| 数据库大小 | 609,857,536 bytes |

硬件为 Ryzen 7 9800X3D、约 96GB RAM、Predator GM7 4TB NVMe SSD，Windows 11，SQLite 3.53.2。测量期间停止并行 Cargo 构建和截图渲染。

修复前结果、审查修复后结果和本轮原始结果保留供对照。本轮仅将本任务生成的 benchmark 库升级为 schema v3 后只读复用，未修改真实资料库。此前额外诊断 Unicode 标签性能使用 `--tag METAL --limit 1`，命中 1,000,000 条记录，单次 DataProvider 用时 **207.5781ms**；这是准确计数/单条页面的单次测量，不是该筛选的 P95，本轮未单独重复该诊断。

使用最多 4 个空闲读取连接、每连接 64MiB SQLite page cache、1GiB mmap 上限；这是缓存预算而非固定分配的内存用量。纯 FTS5 默认相关度查询在确认无缺失行后，使用准确 BM25 的有界 ID 选择，再加载 Metadata。涉及过滤或缺失记录时保留完整谓词，不截断候选造成错误结果。

这些结果使用 OS 热缓存及合成数据。未测量清空 OS 缓存后的磁盘冷查询，也不能保证所有真实注释分布、深分页或缺失/过滤组合均有相同延迟。额外索引增加了生成时间及数据库体积；初始测量留作优化前的对照，最终验收采用本节的结果。

## 音频与本机控制

播放 IPC 结果通过隔离桌面实例验证：无实例时明确失败、192kHz 浮点 WAV 播放、暂停位置冻结、原位恢复且 generation 不变、seek、实时音量、停止归零及 CLI 音量退出后持久化。测试合成文件为全零样本；真实 WAV 内存检查使用增益 0，避免非必要试听。

最大真实文件为 **168,464,078 bytes / 146.133333 秒**。桌面 working set 在加载前为 94,081,024 bytes，播放该文件时为 93,376,512 bytes，差值 -704,512 bytes。该单次观察与有界流式实现相符，不能替代所有文件时长和长期运行的内存压力测试。

音频单元测试覆盖整数/浮点 WAV、不同位深度和采样率、RF64、短文件/末尾、重采样长度与音高、声道路由、增益渐变、Waveform 缓存失效，以及加载失败、结束后 seek 和暂停时设备失败的状态处理。设备重置和占用的真实硬件故障仍需下述实机验收。

## Zen Go ASIO 首版实机记录（修复前）

本机两个 Zen Go 注册名称按 CLSID 合并为一个 x64 驱动；驱动报告 16 个输出通道，缓冲范围 16–4096 frames，步进 -1（2 的幂）。推荐缓冲随驱动/采样率状态变化，设置值 0 在打开当前配置时查询驱动推荐值。

下表运行 0.5 秒全零音频，通过真实 CPAL 输出流。首次/复用时间表示控制线程确认 `Playing` 的软件时间，**不是按钮到实际音频输出的测量**。

| 模式 | 源→设备采样率 | 请求/实际 frames | 首次命令确认 | 已打开流复用确认 | 结果 |
| --- | --- | --- | --- | --- | --- |
| ASIO 原生，默认 | 192k→192k | 0 / 256 | 379.117ms | 0.238ms | 自然结束，0 underruns |
| ASIO 原生，128 | 192k→192k | 128 / 128 | 446.695ms | 0.140ms | 自然结束，0 underruns |
| ASIO 原生，256 | 192k→192k | 256 / 256 | 479.022ms | 0.310ms | 自然结束，0 underruns |
| WASAPI 设备采样率 | 192k→96k | 0 / 960 | 38.584ms | 0.023ms | 自然结束，0 underruns |

原生 192kHz 可以成功打开本机 Zen Go；当前 f32、默认 0.8 增益通路不显示 bit-perfect。测试后将驱动恢复至最初观察的 96kHz / 1024 frames，见恢复记录。以上是短时冒烟，未进行长时间 ASIO 压力测试。

**尚未完成的实机验收**：通过线缆/回环测量预加载与首次打开时的按钮到输出延迟；验证模拟监听端口的实际声道路由；真实设备断开/重置及被其他 DAW 占用后的恢复。不能以软件确认、驱动报告延迟或静音流结束替代这些测量。目标 <50ms 的实际音频输出延迟尚无验收结论。

## 界面和可复现命令

中文、英文、音频设置和关于界面的 Slint 软件渲染截图已检查；结果表、筛选、Metadata 和底部播放区可见。UI 更新在事件循环，搜索/扫描/Waveform 在后台。尚未对真实交互做 P95 <100ms 的计时验收。

在项目根目录运行：

```powershell
cargo fmt --all -- --check
cargo clippy --workspace --all-targets --locked -- -D warnings
cargo test --workspace --all-targets --locked
. ./tools/prepare-asio.ps1
cargo clippy --workspace --all-targets --locked --features audiolib-desktop/asio,audiolib-cli/asio -- -D warnings
cargo test --workspace --all-targets --locked --features audiolib-desktop/asio,audiolib-cli/asio
./tools/build-release.ps1
./tools/validate-runtime.ps1
./tools/validate-playback-ipc.ps1
./tools/validate-access-denial.ps1
./tools/validate-review-fixes.ps1
./tools/validate-library-management.ps1
cargo run --release --locked -p audiolib-db --bin search-benchmark -- --records 1000000 --queries 100
./tools/package-portable.ps1 -SkipBuild
./tools/validate-portable.ps1
```

性能程序拒绝覆盖已有数据库；`--db <new-path>` 保留生成库，`--existing-db <migrated-path>` 使用已有库只读复测。硬件冒烟程序为 `crates/audiolib-audio/examples/audio-smoke.rs`，`--open-silence` 才打开静音输出流；运行会改变设备当前采样率/缓冲设置，应保存并恢复原配置。


## 2026-10-10 大库 GUI 搜索与目录刷新

参见 [GUI 搜索性能报告](Rust_GUI_Search_Performance.md)：增加 SQLite 过期查询取消、目录 facet 复用和按可见行转换的 Slint 模型，移除展开目录时的全库统计。默认/ASIO Clippy 与工作区测试、发布版 runtime/review-fixes/library-management 回归及独立 release GUI 性能测试通过。百万记录模拟库和 20,001 个目录模型的测量不等同于真实服务器快照或物理显示响应；宽泛查询的完整交互仍超过 500 ms。

## 2026-10-10 远程彩色 Waveform 分段显示

新增 5 项回归，验证真实本机 HTTP 范围响应在第二次请求前已发布第一段、固定时间轴上的空白后缀、双声道与非整桶尾段拼接、瞬态峰值保留、取消后的请求及发布抑制、异常返回拒绝。一小时模拟范围在 24 次以内完成请求规划。默认及 ASIO 配置的工作区 Clippy（`-D warnings`）和 `cargo test --workspace --all-targets --locked` 均通过；格式检查通过。17 项原有显式忽略测试没有作为通过项计入。

运行日志位于本机生成目录 `.rust-validation/progressive-waveform/`。显示行为及缓存、FFT 分段边缘限制见 [Spectral Peaks](Rust_Spectral_Audition.md)。500 ms 是有新结果时的 UI 发布节奏，不是首屏、单次 HTTP 响应或真实外网延迟保证；本轮未进行实际公网带宽及按钮到音频输出测量。
## v0.4.0 收尾验证（2026-10-11，构建机，分支 feature/remote-mode，worktree AudioLib_Explorer_validate）

版本：程序 0.4.0 | API /api/v1/ | schema 5 | 快照兼容 3..=5。以下为 pwsh + UTF-8 输出下的如实结果。

| 项目 | 结果 | 说明 |
| --- | --- | --- |
| cargo fmt --check | 通过 | |
| cargo clippy --workspace --all-targets -D warnings | 通过 | |
| tools/check-release.ps1 -Tag v0.4.0 | 通过 | base=v0.3.7 schemaChanged=True |
| validate-library-management | 通过 | UTF-8 重跑 exit 0 |
| validate-review-fixes | 通过 | UTF-8 重跑 exit 0 |
| validate-runtime | 默认环境失败；改用主工作区 fixture 路径后通过 | 见下 |
| validate-playback-ipc | 未通过（未能重跑确认） | 见下 |

validate-runtime 失败根因（环境，非产品缺陷）：脚本通过 `db import data/audiolib.db` 导入旧库，该旧库记录的是主工作区 `test_audiolib\...` 路径；在 `_validate` worktree 中扫描 `_validate\test_audiolib` 会产生 34 条路径不同的新记录（共 68 条），`search` 的第一条是旧路径记录（无 wav_metadata），因而报 "Real BOOM SMED Metadata was not decoded."。手工验证：新路径记录的 SMED 字段（Vehicles/Aircraft/BOOM Library）解码正常。将脚本的 fixture 目录临时指向主工作区路径（临时副本，已删除，未改动仓库脚本）后，全部 8 项检查通过，records=34。

validate-playback-ipc：第一次运行（无桌面实例）在 tools/validate-playback-ipc.ps1:140 失败："Playback history did not resolve the actual IPC source or recorded the GUI-selected/unindexed file."。推断根因（未经重跑确认）：桌面进程以 worktree 为工作目录，启动时导入相对路径 `data/audiolib.db`（路径指向主工作区），而脚本播放的是 worktree 下 test_audiolib 的最大 WAV，该路径未被索引，history 无法解析，与 validate-runtime 同一环境原因。本次重跑时用户的桌面实例（主工作区 local_release，PID 42712）正在运行，脚本在第 21 行按设计中止（"Close the existing desktop instance..."），为不打扰用户未关闭该实例，故未能验证。

产物 SHA256（dist/latest，由 15:5x 构建/打包；target 下同名文件哈希一致）：

- portable/AudioLibExplorer.exe: F51AB208B5C388EF5311B654F0BEC8371BFD7008B894A8BB54007B3ECF945ECB
- portable/AudioLibCli.exe: D38DFFB8A79A36353C5232CBFFB127D3DE8EF4E46831912B0CB366AD0018676E
- AudioLibExplorer-latest-win-x64-portable.zip: B79D5DA35320C8B40E1493E448AA46802833C24D0F22E2B1342FCDA7352FEA72

## 2026-10-13 v0.4.4 远程资源路径管理与同期修复

本轮覆盖服务器音效库根目录新增、修改资源路径、删除、远程目录选择器，以及同工作区的 Debug 报告、快照刷新与关闭取消修复。基础提交为 `4f4d8ab03e209d0fedad7d297494044fc6b267be`，发布构建包含当前未提交工作区源码。检查与构建前后比较全部应用、crate、服务端和资源文件的 SHA256，确认源码保持一致；本机构建检查点清单的 SHA256 为 `0A4F58A5736CFFAB92B59B7E5A20E466A5E7C59D3753739E32F979F324153558`。

环境：Windows x64、Rust 1.97.1 MSVC；ASIO 使用 preparation 工具校验的 Steinberg SDK 2.3.4。共享盘编译缓存出现覆盖拒绝后，使用本机 Cargo 缓存；发布 EXE 复制回标准 release 输出目录并逐一核对 SHA256。

| 检查 | 实际结果 |
| --- | --- |
| `cargo fmt --all -- --check` | 通过 |
| 默认及 ASIO 工作区、全部 targets 的严格 Clippy | 均通过，`-D warnings` |
| 默认及 ASIO 工作区、全部 targets 的 tests | 各 752 passed、58 ignored；忽略项不计入通过数，隔离 GUI 子测试由对应父回归调用 |
| 全工作区 ASIO release build | 通过 |
| `validate-review-fixes.ps1 -CleanCheckout` | 通过，2,000 条重叠扫描合成记录，源音频不变 |
| `validate-library-management.ps1` | 通过，备份/恢复、批量标注、导入导出、重定位及数据库删除；源 WAV 字节不变 |
| `validate-playback-ipc.ps1 -CleanCheckout` | 通过，静音合成 WAV、播放会话、变换、重复和设置保留；没有声学延迟测量 |
| `validate-desktop-close.ps1 -Cycles 3` | 通过，WM_CLOSE 和 SC_CLOSE 各三轮，重复关闭请求、正常退出和库重新打开 |
| 发布版中文及英文 UI | 服务器根目录页、远程目录选择器共四张软件渲染截图，已检查布局 |

服务器回归覆盖管理权限与库身份保护、实际目标 WAV 校验、路径事务的 ID/Metadata/标注保留、源文件不删除、提交前后恢复、跨实例设置锁、旧实例读取最新根配置，以及提交后设置落盘失败时的正确根监控。客户端回归覆盖 Metadata 排空、延迟目录回复丢弃、精确路径字符、状态更新保留草稿及结构性根变化使旧表单失效。集成 HTTP 与 SQLite 均使用本机 loopback 和独立临时数据。

本轮没有导入或打开用户工作库，也未部署实际远程服务器。当前检出没有旧库/WAV fixture，因此 release 回归使用显式 `CleanCheckout` 的合成数据；没有执行要求真实旧 fixture 的 runtime 和 ACL 脚本，不能将其计为通过。上述测试不替代实际公网、百万记录生产库性能或按钮到音频输出延迟验收；性能目标仍为 **P95 latency <500ms for 1M+ records**。

发布 EXE SHA256：

- AudioLibExplorer.exe：`AB92F195C4DD59BC35069326EE66B1B668FB1656AF6055EFAC1ACB5EBBE9A19F`
- AudioLibCli.exe：`00F9605946D68ECE808DC1F47FF5CCEFB3E4779E4BC2AC53EDD1FA74F87A58C9`
- audiolib-server.exe：`152DF3E350071FF70A7BDFA5B63F4A184B36E8BB3759FECFF6190734044AE9A1`

## 2026-10-13 v0.4.4 Debug、快照刷新与资源路径管理集成 review

分支为 `codex/debug-snapshot-reports`，基于 `2950dc9` 整合最新主线。以下是完成 review 修复后的重新验证，前一节保留修复前的构建记录。检查、构建和 release 回归前后核对 205 个应用、crate、服务端及资源文件，源码清单 SHA256 为 `DA14076A62FC4A8AA35AAD97882B2FAF511FA71E9E4000CF7815FAA293780060`。环境仍为 Windows x64、Rust 1.97.1 MSVC、经 preparation 工具校验的 Steinberg SDK 2.3.4。

本次修复六项 review 问题：诊断区分下载同步与快照应用；延迟写回不能降低已知 revision；根目录身份按平台原生路径规则判定；已发送的播放历史请求完成后才切换配置、provider 或关闭；跨实例扫描准入重新读取根配置且锁交接无空隙；跨实例管理请求在同一 settings lease 内读取最新鉴权和管理权限。具体原因和回归见 [review 修复记录](Rust_Review_Fixes.md)。

| 检查 | 实际结果 |
| --- | --- |
| `cargo fmt --all -- --check` | 通过 |
| 默认及 ASIO 工作区、全部 targets 的严格 Clippy | 均通过，`--locked -- -D warnings` |
| 默认及 ASIO 工作区、全部 targets 的 tests | 各 774 passed、69 ignored、0 failed；只汇总没有 filtered 项的顶层结果，子测试不重复计数 |
| 最新源码全工作区 ASIO release build | 通过，发布输出与本机编译缓存的三个 EXE 逐一核对 SHA256 |
| `validate-review-fixes.ps1 -CleanCheckout` | 通过，2,000 条合成记录及重叠扫描 |
| `validate-library-management.ps1` | 通过，数据库维护及源 WAV 保留回归 |
| `validate-desktop-close.ps1 -Cycles 3` | 通过，WM_CLOSE 和 SC_CLOSE 各三轮 |
| `validate-playback-ipc.ps1 -CleanCheckout` | 通过，独立临时库和静音合成 WAV |
| `package-portable.ps1 -SkipBuild` 与便携包隐私边界 | 通过，清单允许文件且没有工作数据库、日志、缓存或本机构建路径 |
| `validate-portable.ps1 -BinaryDirectory dist/latest/portable -CleanCheckout` | 通过，EXE 身份、隔离首次启动及 CLI/UI 检查 |
| 发布版 Debug 中文及英文 UI/report smoke | 均通过，报告版本 0.4.4、ASIO build true，两张截图已检查布局 |

延迟 HTTP 回归覆盖配置切换、活动 endpoint 编辑、provider 替换和关闭；验证原 provider 在排空时保持有效，旧响应不能覆盖新快照。两实例服务端回归覆盖保留旧 WAV 后重定位不重复入库、Metadata/标注保留，以及鉴权/管理权限收紧和放宽时的首个请求。settings lease 争用时管理请求先返回 `409 BUSY` 且不执行；普通库读取和 WAV stream 不等待该租约。

本机没有 Linux 运行环境。区分大小写文件系统上的实际重命名和恢复测试包含条件跳过，因此没有把 Windows 上的通过结果视为 Linux 实测；Windows 路径别名和完整工作区回归已通过。本轮没有打开用户工作库、部署实际远程服务器，或进行公网、百万记录生产库及声学延迟测量。缺少旧 fixture 的 runtime 和 ACL 脚本未执行。性能目标仍为 **P95 latency <500ms for 1M+ records**。

最终发布 EXE SHA256：

- AudioLibExplorer.exe：`C9F7EA923AA596E28935FE4868222A399E553E9041552DE577EF787E8C3E02A5`
- AudioLibCli.exe：`3666599595F355E688364904F5A403E0132B25D1A859DD76AF295030E98D826E`
- audiolib-server.exe：`F99E708B39DA2AAB623AF194D53848AE75FBE582AD6EC065ED5EDE7D996DECC0`

本机日志与源码身份清单位于 `.rust-validation/debug-review/`，Debug 界面截图与报告位于 `.rust-validation/debug-feedback/`；均为忽略的验证产物，不随 Git 或便携包上传。此验证记录更新只改变文档，随后使用相同 EXE 重新打包和验证。固定 `local_release/` 安装使用经验证的包文件、核对两个 EXE 的 SHA256，并以独立临时数据运行 portable validator，保留正常工作数据目录与配置。

## 2026-10-13 v0.4.4 客户端与服务端发布准备

发布准备基于 `a0a1733`，应用 Rust/Slint 源码与上述默认及 ASIO 工作区检查保持一致。新增独立 server 文件清单、原生 Unix 构建、server 归档边界回归和解压产物健康验证；发布 workflow 等 Windows 与 Linux 构建均通过后，核对固定资产、SHA256、平台及标签/提交身份，再统一创建 Release。Linux GNU 构建基线固定为 Ubuntu 22.04。

Windows 本机预检通过：server 新建 staging、运行数据排除、依赖许可证闭包、私有路径及目录链接拒绝回归；`v0.4.4` 版本门禁；最新 ASIO workspace release build；真实 server ZIP 的 SHA256、报告格式、解压后二进制版本/哈希，以及独立一条记录测试库的 `/api/v1/health`（status、version、API v1、schema 5、实际短提交）和 `/api/v1/library`。测试只启动自己的 loopback server；Windows 子进程终止不作为 graceful drain 验证。本机未执行原生 Linux 构建，Linux 结果由发布 workflow 的实际检查和报告记录。

portable validator 的新发布报告模式拒绝错误提交身份和 EXE 哈希；匹配报告下的独立首次启动、CLI、中文 UI 和启动错误诊断通过。该模式要求 `pwsh` 7.3 以上、显式标签/完整提交及 `CleanCheckout`，先核验下载的归档校验和，再以公开 CI 报告中的 EXE 哈希作为安装基准；原有默认模式继续核对本机 release 输出，不覆盖或伪装本机构建来满足身份检查。发布成功后，固定 `local_release/` 按已发布资产核验并安装，正常数据目录和配置保持原位。

本轮准备日志位于忽略的 `.rust-validation/release-v0.4.4/`，不随发布资产上传。最终发布身份及平台执行结果以对应标签的公开 CI 报告和 GitHub Actions 为准。

## 2026-10-13 v0.4.5 原生发布检查补修

`v0.4.4` 的 [Release 检查](https://github.com/Freedragonlancer/AudioLib-Explorer/actions/runs/38368502269) 失败，未创建 GitHub Release；该标签保留，新的发布目标为 `v0.4.5`。Linux 原生回归发现根目录的空 suffix 经 `join("")` 产生末尾分隔符，被字符串比较误判为目录链接。现在按原生路径组件比较，保留 POSIX 大小写及真实链接校验；新增 Unix 回归验证链接拒绝后数据不变、移除测试链接后正常迁移并保留 WAV、ID 和 Metadata。

Windows 检查中的预取消断言失败；确定性回归进一步复现同目录、未索引目录以及 Windows `audio/../audio` 源别名的入口缺口。重定位在获取 OS lease 前检查预取消，Windows 现有源路径按扫描所用的 canonical 身份查找，只有 `NotFound` 回退到已物理移走的旧路径，其他 I/O 错误保持可见。规范源和目标仍拒绝磁盘根目录。回归覆盖锁争用时预取消、目标冲突拒绝、实际迁移和第二次物理改名，确认源 WAV、文件及目录 ID、标注、播放记录和未知扩展 Metadata 保留；派生 `modified_at` 允许随成功迁移更新。

Windows server 包按实际 workspace ASIO features 生成 normal/build 依赖闭包，并包含 `asio-sys` 与固定 SDK 2.3.4 通知；Unix 不启用 ASIO。打包核验已准备 SDK 的固定 ZIP 校验和及精确许可证内容，无 SDK 下载或校验绕过接口。独立 validator 校验官方通知 SHA256。隔离 fake 回归覆盖参数、SDK 缺失/篡改、feature 模式错误、通知清单及失败保留原归档；假 ZIP 校验和仅在测试夹具中模拟，实际 SDK ZIP 和许可证亦独立核验。

`asio-sys 0.4.0` 的上游 crate 没有独立许可证文件，引用同仓库的 CPAL 根许可证。真实包包含 `cpal 0.18.2` 的该文件；validator 仅在两者版本、仓库和 `Apache-2.0` 声明匹配，且 CPAL LICENSE 的固定 SHA256 匹配时接受此来源。独立通知路径与 SDK 的固定 SHA256 校验继续保留，不提供运行参数绕过。

本机最终 `cargo fmt --all -- --check`、默认及 ASIO 严格 Clippy、两种配置的完整 workspace/all-targets 测试通过。两份测试日志各汇总 777 passed、69 ignored（包含子进程测试的结果汇总）；检查期间应用源码身份保持一致。版本门禁确认 program 0.4.5、API v1、schema 5、snapshot 3..=5。

Windows 最新源码的全工作区 ASIO release build、review-fixes（CleanCheckout）、library-management、desktop-close（三轮）和 playback-ipc（CleanCheckout）均通过。客户端打包及 `dist/latest/portable` 的隔离验收通过；真实 ASIO server ZIP 的归档校验和、通知来源、解压 EXE 版本/哈希、health API v1/schema 5/实际提交，以及一条记录测试库读取亦通过。所有测试使用独立临时数据，没有打开工作库；Windows 测试进程终止不计为服务端 graceful drain 验证。本机未执行原生 Linux，最终发布的两个平台结果及提交/资产身份由对应标签 workflow 和公开报告记录。本机日志位于忽略的 `.rust-validation/release-v0.4.5/`，不随发布上传。

## 2026-10-13 v0.4.6 Unix 验证进程清理修复

`v0.4.5` 的 [Release 检查](https://github.com/Freedragonlancer/AudioLib-Explorer/actions/runs/38374086093) 中，原生 Linux Clippy、服务器和数据库测试、release 构建、归档及 health/library 验证已通过，但 validator 的进程清理失败，未发布该版本。Ubuntu 的 PATH 同时解析到 `/usr/bin/kill` 和 `/bin/kill`，原写法把 `.Source` 数组作为一个命令路径传入。validator 现在对 native kill 和 Cargo 都先取首个应用命令再读取路径；继续只停止该次验证启动的进程，保留有界终止 fallback。

同轮 Windows 检查还发现远程 raw route 测试的路径前提错误：测试根目录使用原始临时路径，扫描记录则使用规范路径；机器临时目录采用别名时两者无法匹配，提前选用了 server raw route。该测试现在显式使用 `sounds/../sounds` 扫描输入，确认旧根身份无法匹配，再从扫描记录的父目录构造服务器根，并在播放前核验根身份与精确 WebDAV 映射。原注册身份、路由替换、失败回滚、共享缓冲与 Stop 取消断言保留；这不改变应用路由行为。

已推送的标签保留，发布目标改为 `v0.4.6`。程序版本统一更新，API v1、schema 5 与 snapshot 3..=5 不变。此前 `v0.4.5` 本机最终提交的客户端与服务器打包、隔离 portable 和健康验收通过；新标签将执行完整 Windows/ASIO 与原生 Linux 发布检查，最终身份和结果见该标签的公开 workflow/报告。本机续验日志位于忽略的 `.rust-validation/release-v0.4.6/`。

## 2026-10-13 v0.4.7 扫描失败回信与取消耗时检查

`v0.4.6` 的 [Release 检查](https://github.com/Freedragonlancer/AudioLib-Explorer/actions/runs/38376629548) 中，原生 Linux 严格 Clippy、服务器和数据库测试、构建、打包、health/library 验证及临时进程清理全部通过；Windows 检查失败，未创建 Release。该标签保留，新的发布目标为 `v0.4.7`，API v1、schema 5 和 snapshot 3..=5 保持不变。

Windows 主分支 CI 暴露扫描启动失败的回信竞态：目录解析失败先发送错误，外层清理稍后才释放设置 lease 与扫描 slot，紧接着的管理请求可能收到 409 BUSY。`workers` 上限固定为 16，并非硬件差异。修复统一在启动失败完成资源释放后才回信，覆盖目录解析、revision hold、scanner 启动及 panic 路径；保留成功扫描的数据库 lease 交接顺序。回归继续检查无效请求的原状态码、空扫描历史、空活动 slot 及 revision 不变。

Windows 发布检查的快照回归已正确返回 `Cancelled`，失败的是 `<1s` 总耗时断言：计时包含发出取消前的复制和 SQLite 验证。回归改为在阶段回调实际请求取消时开始测量，仍要求取消到返回小于一秒，并确认回调到达、原始缓存及状态字节、已有 reader 和 staging 清理不变；没有放大超时或跳过取消断言。

两处修改经独立复核，无阻断问题。本机扫描模块六项单元回归、七项 HTTP 扫描集成回归及服务端严格 Clippy 通过；远程取消 filter 的三项回归在默认配置连续三轮通过。完整工作区、ASIO、重建打包及各平台发布检查继续由本次流水线和公开报告记录。

此前 `v0.4.6` 本机 fmt、默认及 ASIO 严格 Clippy、两种完整 workspace/all-targets 测试、最新 ASIO release 构建、review-fixes、library-management、desktop-close（三轮）、playback-ipc、客户端打包及隔离 portable 验收通过。替换旧 server 生成目录时，本机 SMB 文件系统的递归删除报告目录非空；续验先将已核验的生成输出移动到仓库内私有备份，再重新打包，不涉及工作库或固定安装。`v0.4.7` 的续验日志在忽略的 `.rust-validation/release-v0.4.7/`；最终平台检查、提交与资产身份以新标签的公开 workflow 和报告为准。

## 2026-10-14 v0.4.8 服务器模式启动与关闭后续修复

本版基于已发布的 `v0.4.7`。缓存准备的 Busy/Locked 备份步骤有 5 秒上限，未知步骤结果直接报错；关窗等待远端缓存任务最多 15 秒；服务器模式启动清理超过 1 小时的 staging；服务器配置无效时本次会话回退本地，保存时保留原服务器选择（用户显式选择数据源除外），无可用本地库时保持服务器模式；管理器切回本地前检查本地库存在。

本机 Windows MSVC 1.97.1：`cargo fmt --all -- --check`、严格 Clippy、`cargo test --workspace --all-targets --locked`（786 passed）通过；validate-desktop-close、validate-review-fixes、validate-library-management 通过。validate-runtime 在 BOOM SMED Metadata 解码处失败，为既有问题，与本版改动无关。API v1、schema 5、snapshot 3..=5 不变；最终平台检查与资产身份以 `v0.4.8` 标签的公开 workflow 和报告为准。

## 2026-10-21 v0.4.11 服务器同步期间切回本地

服务器启动同步、后台同步及已保存服务器选择的同步阶段均保留本地切换入口。切换取消旧同步并清理其 UI 进度，以 source/remote generation 拒绝晚到结果和排队重试；缓存 worker 仍自行排空并释放 busy。预占服务器选择时复用已完成的 Metadata barrier，保留原 provider 的 rollback 设置，避免用待同步服务器的凭据重新捕获旧草稿。实际 provider 打开、设置写入和回滚仍保留互斥门禁。

本机 Rust 1.97.1 MSVC：格式检查、桌面包全部 targets 的严格 Clippy、`cargo test -p audiolib-desktop --locked` 通过（221 passed、0 failed、71 ignored；隔离 child helper 由 parent 调用，不重复计数）。新增回归通过真实 Slint 指针操作覆盖无缓存启动的挂起/失败 HTTP、切入服务器后返回本地及 Metadata 保留、等待旧 worker 的重试失效、中英文入口与正常 busy 门禁。测试仅使用 owned 临时目录和 loopback 服务，没有访问工作库或实际服务器。

补充修复当前服务器连接“关闭→保存”在 resync 时隐藏管理窗口的路径，保留同步期间的本地入口。独立本机构建缓存中的严格 Clippy 和管理器专项复验通过（15 passed、0 failed、4 ignored，包含新增关闭保存回归及原普通保存关闭回归）；共享盘 debug 缓存的两项 rmeta 写入拒绝没有通过修改权限或工作数据规避。`validate-review-fixes.ps1 -CleanCheckout` 和 `validate-library-management.ps1` 通过，包含 2,000 条合成记录的跨进程扫描保护、标注保留和库管理回归；真实 legacy fixture 不可用的检查明确跳过。

CR 补充修复同步门禁吞掉键盘输入及方向键停在中间服务器的问题，并保留“关闭→保存”的关闭意图，成功提交 provider 后关闭，导航或失败时取消。切回本地失败时先恢复原设置，等待旧同步缓存发布结束后再恢复 active cache；等待期间的原生关窗会进入既有的限时关闭流程，重启仍校验缓存端点。交叉复核未发现新的阻断问题。最终格式检查、桌面全部 targets 严格 Clippy 和桌面包测试通过（226 passed、0 failed、75 ignored；隔离 helper 由 parent 执行），覆盖上述键盘、晚到缓存发布、关闭意图及等待回滚时的原生关窗。此次复验使用原共享盘 target 的 UNC 路径，两个辅助 crate 采用命令行 `profile.dev.package.<crate>.opt-level=1`，未复制新的整份临时构建缓存。

本轮构建、便携验收和固定 `local_release/` 安装的本机记录保存在忽略目录 `.rust-validation/sync-local-recovery/`；安装成功以 `installation.json` 中的文件身份和隔离启动结果为准。本次未申请发布 GitHub Release，未进行公网、百万条性能或物理音频延迟验收。

## 2026-10-28 v0.8.1 后续客户端交叉索引修复

复现顺序为共同关键词 → 选择音效库 → 全部声音。旧入口仅清除目录范围，留下 Album 筛选，因此结果和文件夹索引仍限于旧音效库，按钮却显示全库状态。修复同步清除请求、UI 和搜索任务的目录/Album 范围，保留关键词及其他过滤条件；全库按钮高亮同时检查 Album 范围。

新增本地可写库及实际只读 SQLite 快照两项真实 Controller 回归，旧代码均失败于残留 Album 断言，修复后均通过。覆盖目录与 Album 双向交叉、关键词和收藏条件保留、失效任务绑定清除及旧 generation 的目录成功/错误发布拒绝。测试使用 owned 临时 WAV、SQLite 和 Slint 事件循环，未访问工作库或真实 HTTP 服务。

Rust 1.97.1 MSVC：格式、桌面全部 targets 严格 Clippy、54 项搜索任务测试、3 项目录检索测试和 1 项收藏 UI 入口测试通过（隔离 child 由 parent 执行，不重复计数）。此次没有数据库格式、SQL 查询或服务端协议变更；未重新执行百万条基准或宣称新的网络/物理音频延迟结果。本地构建、便携校验及固定安装结果另记录于忽略目录 `.rust-validation/cross-index-fix/`。
